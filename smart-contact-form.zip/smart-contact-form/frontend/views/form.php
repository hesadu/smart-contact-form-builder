<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// $settings and $form_id are passed from SCF_Shortcode::render()
$fields   = $settings['fields'] ?? array();
$cur_form_id = isset($form_id) ? (int)$form_id : (int)($settings['_form_id'] ?? 1);

// Colors & styles from settings
$pc  = sanitize_hex_color( $settings['primary_color']     ?? '#1e3a5f' );
$sc  = sanitize_hex_color( $settings['secondary_color']   ?? '#2563eb' );
$bc  = sanitize_hex_color( $settings['button_color']      ?? '#1e3a5f' );
$bt  = sanitize_hex_color( $settings['button_text_color'] ?? '#ffffff' );
$bg  = sanitize_hex_color( $settings['bg_color']          ?? '#f8fafc' );
$tc  = sanitize_hex_color( $settings['text_color']        ?? '#64748b' );
$hc  = sanitize_hex_color( $settings['heading_color']     ?? '#1e293b' );
$ff  = esc_attr( $settings['font_family'] ?? 'Inter' );
$fz  = absint( $settings['font_size'] ?? 15 ) . 'px';
$bg_type  = $settings['bg_type'] ?? 'color';
$show_info = ! isset( $settings['show_info_panel'] ) || ! empty( $settings['show_info_panel'] );

// Build background CSS
if ( $bg_type === 'gradient' ) {
    $grad_from = sanitize_hex_color( $settings['bg_gradient_from'] ?? '#1e3a5f' );
    $grad_to   = sanitize_hex_color( $settings['bg_gradient_to']   ?? '#2563eb' );
    $grad_dir  = esc_attr( $settings['bg_gradient_dir'] ?? 'to bottom right' );
    $bg_css    = "linear-gradient({$grad_dir},{$grad_from},{$grad_to})";
    $bg_prop   = "background-image:{$bg_css};";
} elseif ( $bg_type === 'image' && ! empty( $settings['bg_image'] ) ) {
    $bg_img_url  = esc_url( $settings['bg_image'] );
    $bg_img_pos  = esc_attr( $settings['bg_image_pos']  ?? 'center center' );
    $bg_img_size = esc_attr( $settings['bg_image_size'] ?? 'cover' );
    $bg_prop     = "background-image:url('{$bg_img_url}');background-size:{$bg_img_size};background-position:{$bg_img_pos};";
} elseif ( $bg_type === 'none' ) {
    $bg_prop = "background:transparent;";
} else {
    $bg_prop = "background-color:{$bg};";
}

// Layout
$form_max_w  = absint( $settings['form_max_width']  ?? 960 );
$form_min_h  = absint( $settings['form_min_height'] ?? 0 );
$form_pad    = absint( $settings['form_padding']     ?? 60 );
$min_h_css   = $form_min_h > 0 ? "min-height:{$form_min_h}px;" : '';
$has_overlay = ! empty( $settings['bg_overlay'] ) && $bg_type === 'image';

$bgimg = ! empty( $settings['bg_image'] ) ? "url('" . esc_url( $settings['bg_image'] ) . "')" : 'none';

// Pair half-width fields into rows
$rows = array();
$i    = 0;
while ( $i < count( $fields ) ) {
    $f = $fields[$i];
    if ( ( $f['type'] ?? '' ) === 'heading' ) {
        $rows[] = array( 'heading' => true, 'field' => $f );
        $i++;
    } elseif ( ! empty( $f['halfWidth'] ) && isset( $fields[$i+1] ) && ! empty( $fields[$i+1]['halfWidth'] ) && ( $fields[$i+1]['type'] ?? '' ) !== 'heading' ) {
        $rows[] = array( $f, $fields[$i+1] );
        $i += 2;
    } else {
        $rows[] = array( $f );
        $i++;
    }
}

// Inline style helpers
// Input styles handled by scoped <style> block above
$input_style  = "";
$label_style  = "display:block;font-size:12px;font-weight:600;color:{$hc};margin-bottom:6px;letter-spacing:0.2px;font-family:'{$ff}',sans-serif;";
$uid = 'scf-' . substr( md5( uniqid() ), 0, 6 );
?>

<style>
/* === SCF Reset — neutralise ALL theme styles inside our widget === */
#<?php echo esc_attr($uid); ?>,
#<?php echo esc_attr($uid); ?> * {
    box-sizing: border-box !important;
    line-height: normal !important;
}
/* Block-level resets — only p/span/h, NOT div (divs use inline styles) */
#<?php echo esc_attr($uid); ?> p,
#<?php echo esc_attr($uid); ?> span {
    float: none !important;
    clear: none !important;
}
#<?php echo esc_attr($uid); ?> h2,
#<?php echo esc_attr($uid); ?> h3 {
    float: none !important;
    clear: none !important;
    border: none !important;
    background: none !important;
}
/* Label reset — themes often float/inline labels */
#<?php echo esc_attr($uid); ?> label {
    display: block !important;
    float: none !important;
    width: auto !important;
    margin: 0 0 6px 0 !important;
    padding: 0 !important;
    font-weight: 600 !important;
    font-size: 12px !important;
    color: <?php echo esc_attr($hc); ?> !important;
    letter-spacing: 0.2px !important;
    font-family: '<?php echo esc_attr($ff); ?>', sans-serif !important;
    text-align: left !important;
    vertical-align: baseline !important;
    line-height: 1.4 !important;
    cursor: default !important;
}
/* Input/textarea/select reset */
#<?php echo esc_attr($uid); ?> input:not([type="checkbox"]):not([type="submit"]),
#<?php echo esc_attr($uid); ?> textarea,
#<?php echo esc_attr($uid); ?> select {
    display: block !important;
    width: 100% !important;
    float: none !important;
    margin: 0 !important;
    padding: 11px 14px !important;
    border: 1.5px solid #e2e8f0 !important;
    border-radius: 8px !important;
    background: #fff !important;
    font-size: 14px !important;
    font-family: '<?php echo esc_attr($ff); ?>', sans-serif !important;
    color: <?php echo esc_attr($hc); ?> !important;
    outline: none !important;
    box-shadow: none !important;
    vertical-align: baseline !important;
    line-height: 1.4 !important;
    appearance: none !important;
    -webkit-appearance: none !important;
    -moz-appearance: none !important;
    height: auto !important;
    max-width: 100% !important;
    transition: border-color .15s, box-shadow .15s !important;
}
#<?php echo esc_attr($uid); ?> select {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='%2364748b'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E") !important;
    background-repeat: no-repeat !important;
    background-position: right 13px center !important;
    padding-right: 36px !important;
    cursor: pointer !important;
}
#<?php echo esc_attr($uid); ?> textarea {
    resize: vertical !important;
    min-height: 110px !important;
}
/* Focus states */
#<?php echo esc_attr($uid); ?> input:focus,
#<?php echo esc_attr($uid); ?> textarea:focus,
#<?php echo esc_attr($uid); ?> select:focus {
    border-color: <?php echo esc_attr($sc); ?> !important;
    box-shadow: 0 0 0 3px <?php echo esc_attr($sc); ?>33 !important;
    outline: none !important;
}
/* Error states */
#<?php echo esc_attr($uid); ?> input.scf-err,
#<?php echo esc_attr($uid); ?> textarea.scf-err,
#<?php echo esc_attr($uid); ?> select.scf-err { border-color: #ef4444 !important; }
/* Checkbox hidden */
#<?php echo esc_attr($uid); ?> input[type="checkbox"] {
    position: absolute !important;
    opacity: 0 !important;
    width: 0 !important;
    height: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
}
/* Checkbox label override */
#<?php echo esc_attr($uid); ?> .scf-cb-lbl {
    display: flex !important;
    align-items: flex-start !important;
    gap: 10px !important;
    cursor: pointer !important;
    margin: 0 !important;
    padding: 0 !important;
    float: none !important;
    width: 100% !important;
    font-weight: 400 !important;
    font-size: 13px !important;
    color: <?php echo esc_attr($tc); ?> !important;
}
#<?php echo esc_attr($uid); ?> .scf-cb-lbl .scf-cb-visual {
    flex-shrink: 0 !important;
    width: 18px !important; height: 18px !important;
    margin-top: 2px !important;
    border: 1.5px solid #e2e8f0 !important;
    border-radius: 5px !important;
    background: #fff !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
}
#<?php echo esc_attr($uid); ?> input[type="checkbox"]:checked + .scf-cb-visual {
    background: <?php echo esc_attr($sc); ?> !important;
    border-color: <?php echo esc_attr($sc); ?> !important;
}
/* Button reset */
#<?php echo esc_attr($uid); ?> button[type="submit"] {
    display: block !important;
    width: 100% !important;
    float: none !important;
    margin: 8px 0 0 !important;
    padding: 14px 20px !important;
    background: <?php echo esc_attr($bc); ?> !important;
    color: <?php echo esc_attr($bt); ?> !important;
    border: none !important;
    border-radius: 9px !important;
    font-size: 13px !important;
    font-family: '<?php echo esc_attr($ff); ?>', sans-serif !important;
    font-weight: 700 !important;
    letter-spacing: .8px !important;
    text-transform: uppercase !important;
    cursor: pointer !important;
    line-height: 1.4 !important;
    box-shadow: none !important;
    outline: none !important;
    height: auto !important;
    transition: opacity .15s !important;
}
#<?php echo esc_attr($uid); ?> button[type="submit"]:hover { opacity: 0.88 !important; }
#<?php echo esc_attr($uid); ?> button[type="submit"]:disabled { opacity: 0.6 !important; cursor: not-allowed !important; }
/* Select option */
#<?php echo esc_attr($uid); ?> select option { color: #1e293b; background: #fff; }
/* Grid rows */
#<?php echo esc_attr($uid); ?> .scf-row-half {
    display: grid !important;
    grid-template-columns: 1fr 1fr !important;
    gap: 14px !important;
    float: none !important;
}
</style>

<div id="<?php echo esc_attr($uid); ?>" style="all:initial;display:block;position:relative;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;font-size:<?php echo esc_attr($fz); ?>;<?php echo $bg_prop; ?>color:<?php echo esc_attr($tc); ?>;padding:<?php echo esc_attr($form_pad); ?>px 20px;line-height:1.5;width:100%;box-sizing:border-box;<?php echo $min_h_css; ?>"><?php if($has_overlay): ?><div style="position:absolute;inset:0;background:rgba(0,0,0,0.45);z-index:0;"></div><?php endif; ?><div style="position:relative;z-index:1;">

    <?php
    $info_max_w  = $form_max_w > 0 ? $form_max_w : 960;
    $form_only_w = $form_max_w > 0 ? $form_max_w : 960;
    $container_style = $show_info
        ? "max-width:{$info_max_w}px;margin:0 auto !important;display:grid;grid-template-columns:1fr 1.5fr;gap:40px;align-items:start;width:100%;box-sizing:border-box;"
        : "max-width:{$form_only_w}px;margin:0 auto !important;width:100%;box-sizing:border-box;";
    ?>
    <div style="<?php echo esc_attr($container_style); ?>">

    <?php if ( $show_info ) : ?>
    <!-- LEFT: Info Panel -->
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:36px 28px;box-shadow:0 2px 12px rgba(0,0,0,.06);">
        <div style="width:44px;height:4px;background:linear-gradient(90deg,<?php echo esc_attr($pc); ?>,<?php echo esc_attr($sc); ?>);border-radius:2px;margin-bottom:20px;"></div>
        <h2 style="color:<?php echo esc_attr($hc); ?>;font-size:1.8em;font-weight:700;line-height:1.2;margin:0 0 12px;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"><?php echo esc_html( $settings['company_name'] ?? '' ); ?></h2>
        <p style="color:<?php echo esc_attr($tc); ?>;font-size:.9em;line-height:1.75;margin:0 0 28px;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"><?php echo esc_html( $settings['company_tagline'] ?? '' ); ?></p>

        <div style="display:flex;flex-direction:column;gap:18px;">
            <?php if ( ! empty( $settings['address'] ) ) : ?>
            <div style="display:flex;gap:12px;align-items:flex-start;">
                <div style="flex-shrink:0;width:40px;height:40px;background:<?php echo esc_attr($pc); ?>1a;border-radius:10px;display:flex;align-items:center;justify-content:center;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="<?php echo esc_attr($pc); ?>"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
                </div>
                <div>
                    <span style="display:block;font-size:.72em;font-weight:700;text-transform:uppercase;letter-spacing:.7px;color:<?php echo esc_attr($pc); ?>;margin-bottom:3px;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;">Address</span>
                    <span style="display:block;font-size:.88em;color:<?php echo esc_attr($tc); ?>;line-height:1.5;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"><?php echo esc_html( $settings['address'] ); ?></span>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( ! empty( $settings['phone'] ) ) : ?>
            <div style="display:flex;gap:12px;align-items:center;">
                <div style="flex-shrink:0;width:40px;height:40px;background:<?php echo esc_attr($pc); ?>1a;border-radius:10px;display:flex;align-items:center;justify-content:center;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="<?php echo esc_attr($pc); ?>"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                </div>
                <div>
                    <span style="display:block;font-size:.72em;font-weight:700;text-transform:uppercase;letter-spacing:.7px;color:<?php echo esc_attr($pc); ?>;margin-bottom:3px;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;">Phone</span>
                    <a href="tel:<?php echo esc_attr( $settings['phone'] ); ?>" style="display:block;font-size:.88em;color:<?php echo esc_attr($sc); ?>;text-decoration:none;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"><?php echo esc_html( $settings['phone'] ); ?></a>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( ! empty( $settings['email_display'] ) ) : ?>
            <div style="display:flex;gap:12px;align-items:center;">
                <div style="flex-shrink:0;width:40px;height:40px;background:<?php echo esc_attr($pc); ?>1a;border-radius:10px;display:flex;align-items:center;justify-content:center;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="<?php echo esc_attr($pc); ?>"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                </div>
                <div>
                    <span style="display:block;font-size:.72em;font-weight:700;text-transform:uppercase;letter-spacing:.7px;color:<?php echo esc_attr($pc); ?>;margin-bottom:3px;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;">Email</span>
                    <a href="mailto:<?php echo esc_attr( $settings['email_display'] ); ?>" style="display:block;font-size:.88em;color:<?php echo esc_attr($sc); ?>;text-decoration:none;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"><?php echo esc_html( $settings['email_display'] ); ?></a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- RIGHT: Form -->
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:36px 32px;box-shadow:0 2px 12px rgba(0,0,0,.06);">
        <h3 style="color:<?php echo esc_attr($hc); ?>;font-size:1.18em;font-weight:700;margin:0 0 24px;line-height:1.3;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"><?php echo esc_html( $settings['form_title'] ?? 'Schreiben Sie uns' ); ?></h3>

        <div id="scf-response-<?php echo esc_attr($uid); ?>" style="display:none;padding:12px 16px;border-radius:8px;font-size:13px;margin-bottom:16px;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"></div>

        <form id="scf-form-<?php echo esc_attr($uid); ?>" novalidate>
            <?php wp_nonce_field( 'scf_submit_nonce', 'scf_nonce_field' ); ?>
            <input type="hidden" name="form_id" value="<?php echo esc_attr( $cur_form_id ); ?>">
            <input type="hidden" name="scf_time_on_page" id="scf-top-<?php echo esc_attr($uid); ?>" value="0">
            <div style="position:absolute;left:-9999px;" aria-hidden="true">
                <input type="text" name="scf_hp" tabindex="-1" autocomplete="off">
            </div>

            <?php foreach ( $rows as $row ) :
                // ── Heading row ──
                if ( ! empty( $row['heading'] ) ) :
                    $hf = $row['field'];
                    $hs = esc_attr( $hf['headingStyle'] ?? 'h3' );
                    $hl = esc_html( $hf['label'] ?? '' );
                    if ( $hs === 'divider' ) : ?>
                        <div style="margin:8px 0 20px;border-bottom:2px solid <?php echo esc_attr($pc); ?>30;"></div>
                    <?php else :
                        $sz = array( 'h2' => '1.3em', 'h3' => '1.08em', 'h4' => '.9em' )[$hs] ?? '1.08em';
                    ?>
                        <div style="margin:6px 0 16px;padding-bottom:10px;border-bottom:2px solid <?php echo esc_attr($pc); ?>20;">
                            <span style="font-size:<?php echo esc_attr($sz); ?>;font-weight:700;color:<?php echo esc_attr($hc); ?>;letter-spacing:.01em;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"><?php echo $hl; ?></span>
                        </div>
                    <?php endif; ?>
                <?php continue; endif; ?>

                <?php
                $is_half = count($row) === 2;
                $row_style = $is_half
                    ? "display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px;float:none;clear:both;"
                    : "display:block;margin-bottom:16px;float:none;clear:both;";
            ?>
            <div style="<?php echo esc_attr($row_style); ?>">
                <?php foreach ( $row as $field ) :
                    $fid  = esc_attr( $field['id'] );
                    $lbl  = esc_html( $field['label'] );
                    $ph   = esc_attr( $field['placeholder'] ?? $field['label'] );
                    $req  = ! empty( $field['required'] );
                    $type = $field['type'];
                ?>
                <div style="display:block;float:none;clear:both;">
                    <?php if ( $type !== 'checkbox' ) : ?>
                    <label for="scf-f-<?php echo $fid; ?>" style="<?php echo esc_attr($label_style); ?>">
                        <?php echo $lbl; ?><?php if ($req) : ?><span style="color:#ef4444;margin-left:2px;">*</span><?php endif; ?>
                    </label>
                    <?php endif; ?>

                    <?php if ( $type === 'textarea' ) : ?>
                        <textarea
                            id="scf-f-<?php echo $fid; ?>"
                            name="<?php echo $fid; ?>"
                            placeholder="<?php echo $ph; ?>"
                            rows="5"
                            <?php echo $req ? 'required' : ''; ?>
                            style="<?php echo esc_attr($input_style); ?>min-height:110px;resize:vertical;"
                        ></textarea>

                    <?php elseif ( $type === 'select' ) : ?>
                        <select
                            id="scf-f-<?php echo $fid; ?>"
                            name="<?php echo $fid; ?>"
                            <?php echo $req ? 'required' : ''; ?>
                            style="<?php echo esc_attr($input_style); ?>cursor:pointer;appearance:none;-webkit-appearance:none;background-image:url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2212%22 height=%2212%22 viewBox=%220 0 24 24%22 fill=%22%2364748b%22%3E%3Cpath d=%22M7 10l5 5 5-5z%22/%3E%3C/svg%3E');background-repeat:no-repeat;background-position:right 13px center;padding-right:36px;"
                        >
                            <option value=""><?php echo $lbl; ?></option>
                            <?php foreach ( $field['options'] ?? array() as $opt ) : ?>
                                <option value="<?php echo esc_attr( $opt['label'] ); ?>" data-redirect="<?php echo esc_attr( $opt['redirect'] ?? '' ); ?>"><?php echo esc_html( $opt['label'] ); ?></option>
                            <?php endforeach; ?>
                        </select>

                    <?php elseif ( $type === 'checkbox' ) : ?>
                        <label class="scf-cb-lbl" style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;margin:0;">
                            <input type="checkbox" id="scf-f-<?php echo $fid; ?>" name="<?php echo $fid; ?>" value="1" <?php echo $req ? 'required' : ''; ?>>
                            <span class="scf-cb-visual" style="flex-shrink:0;width:18px;height:18px;margin-top:2px;border:1.5px solid #e2e8f0;border-radius:5px;background:#fff;display:flex;align-items:center;justify-content:center;transition:all .15s;"></span>
                            <span style="font-size:13px;color:<?php echo esc_attr($tc); ?>;line-height:1.55;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;"><?php echo $lbl; ?><?php if ($req) : ?> <span style="color:#ef4444;">*</span><?php endif; ?></span>
                        </label>

                    <?php else : ?>
                        <input
                            type="<?php echo esc_attr( $type === 'phone' ? 'tel' : $type ); ?>"
                            id="scf-f-<?php echo $fid; ?>"
                            name="<?php echo $fid; ?>"
                            placeholder="<?php echo $ph; ?>"
                            <?php echo $req ? 'required' : ''; ?>
                            style="<?php echo esc_attr($input_style); ?>"
                        >
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>

            <button type="submit" id="scf-submit-<?php echo esc_attr($uid); ?>" class="scf-submit-btn"
                style="display:block;width:100%;padding:14px 20px;margin-top:8px;background:<?php echo esc_attr($bc); ?>;color:<?php echo esc_attr($bt); ?>;border:none;border-radius:9px;font-size:13px;font-family:'<?php echo esc_attr($ff); ?>',sans-serif;font-weight:700;letter-spacing:.8px;text-transform:uppercase;cursor:pointer;transition:opacity .15s;line-height:1.4;">
                <?php echo esc_html( $settings['button_text'] ?? 'JETZT KONTAKTIEREN' ); ?>
            </button>
        </form>
    </div>

    </div>
</div></div>

<script>
(function() {
    var uid          = '<?php echo esc_js($uid); ?>';
    var pageLoadTime = Math.floor(Date.now() / 1000);
    var form         = document.getElementById('scf-form-' + uid);
    var response     = document.getElementById('scf-response-' + uid);
    var btn          = document.getElementById('scf-submit-' + uid);
    if (!form) return;

    // Checkbox visual toggle
    form.querySelectorAll('input[type="checkbox"]').forEach(function(cb) {
        cb.addEventListener('change', function() {
            var visual = cb.nextElementSibling;
            if (!visual) return;
            if (cb.checked) {
                visual.style.background = '<?php echo esc_js($sc); ?>';
                visual.style.borderColor = '<?php echo esc_js($sc); ?>';
                visual.innerHTML = '<svg width="10" height="10" viewBox="0 0 12 12"><polyline points="1,6 4,9 11,2" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>';
            } else {
                visual.style.background = '#fff';
                visual.style.borderColor = '#e2e8f0';
                visual.innerHTML = '';
            }
        });
    });

    // Focus styles
    form.querySelectorAll('input:not([type=checkbox]), textarea, select').forEach(function(el) {
        el.addEventListener('focus', function() {
            el.style.borderColor = '<?php echo esc_js($sc); ?>';
            el.style.boxShadow   = '0 0 0 3px <?php echo esc_js($sc); ?>22';
            el.style.outline     = 'none';
        });
        el.addEventListener('blur', function() {
            if (!el.classList.contains('scf-err')) {
                el.style.borderColor = '#e2e8f0';
                el.style.boxShadow   = 'none';
            }
        });
        el.addEventListener('input', function() {
            el.classList.remove('scf-err');
            el.style.borderColor = '#e2e8f0';
            el.style.boxShadow = 'none';
            var errSpan = document.getElementById('scf-err-' + el.id);
            if (errSpan) errSpan.remove();
        });
    });

    // Submit
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        // ── Validation helpers ──────────────────────────────────────────
        var isValidPostcode = function(v) {
            v = v.trim();
            if (!/^\d{5}$/.test(v)) return false;          // exactly 5 digits
            if (/^(\d)\1{4}$/.test(v)) return false;       // 00000–99999
            var asc = '0123456789', desc = '9876543210';
            if (asc.indexOf(v) !== -1 || desc.indexOf(v) !== -1) return false; // 01234, 98765
            if (v.substring(0,2) === '00') return false;    // no German PLZ starts with 00
            return true;
        };
        var isValidAddress = function(v) {
            v = v.trim();
            if (v.length < 5) return false;
            var lower = v.toLowerCase();
            var fakes = ['muster','test','beispiel','sample','dummy','fake',
                         'asdf','qwert','qwerty','zxcv','abc','aaa','xxx'];
            for (var i=0; i<fakes.length; i++) {
                if (lower.indexOf(fakes[i]) !== -1) return false;
            }
            var stripped = lower.replace(/[\s\-\.]+/g,'');
            if (/^(.)+$/.test(stripped)) return false;    // aaaaaa
            var hasDigit = /\d/.test(v);
            var hasVowel = /[aeiouäöüAEIOUÄÖÜ]/.test(v);
            if (!hasDigit && !hasVowel) return false;       // pure consonants = keyboard mash
            return true;
        };
        var showFieldError = function(el, msg) {
            el.style.borderColor = '#ef4444';
            el.style.boxShadow   = '0 0 0 3px rgba(239,68,68,.1)';
            // Show inline error message below field
            var errId = 'scf-err-' + el.id;
            var existing = document.getElementById(errId);
            if (!existing) {
                var err = document.createElement('span');
                err.id = errId;
                err.style.cssText = 'display:block;color:#ef4444;font-size:11px;margin-top:4px;font-family:inherit;';
                err.textContent = msg;
                el.parentNode.appendChild(err);
            }
        };
        var clearFieldError = function(el) {
            el.style.borderColor = '#e2e8f0';
            el.style.boxShadow   = 'none';
            var existing = document.getElementById('scf-err-' + el.id);
            if (existing) existing.remove();
        };

        // ── Run validation ───────────────────────────────────────────────
        var ok = true;
        // Clear all previous errors first
        form.querySelectorAll('input,textarea,select').forEach(function(el) {
            clearFieldError(el);
        });

        form.querySelectorAll('[required], [data-scf-validate]').forEach(function(el) {
            var bad = false;
            var msg = '';
            var labelEl = form.querySelector('label[for="' + el.id + '"]');
            var labelText = (labelEl ? labelEl.textContent : el.name).toLowerCase();

            if (el.type === 'checkbox') {
                bad = !el.checked;
                if (bad && el.nextElementSibling) {
                    el.nextElementSibling.style.borderColor = '#ef4444';
                }
            } else {
                var val = el.value.trim();
                // Empty required field
                if (!val && el.hasAttribute('required')) {
                    bad = true; msg = '';
                }
                if (!bad && val) {
                    // Email
                    if (el.type === 'email') {
                        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
                            bad = true; msg = 'Bitte gültige E-Mail-Adresse eingeben.';
                        }
                    }
                    // PLZ / Postcode
                    if (!bad && (labelText.indexOf('plz') !== -1 || labelText.indexOf('postleitzahl') !== -1 ||
                                 labelText.indexOf('postcode') !== -1 || labelText.indexOf('zip') !== -1)) {
                        if (!isValidPostcode(val)) {
                            bad = true; msg = 'Bitte gültige Postleitzahl eingeben.';
                        }
                    }
                    // Address / Straße
                    if (!bad && (labelText.indexOf('adresse') !== -1 || labelText.indexOf('straße') !== -1 ||
                                 labelText.indexOf('strasse') !== -1 || labelText.indexOf('address') !== -1 ||
                                 labelText.indexOf('street') !== -1)) {
                        if (!isValidAddress(val)) {
                            bad = true; msg = 'Bitte gültige Adresse eingeben.';
                        }
                    }
                }
                if (bad) showFieldError(el, msg);
            }
            if (bad) ok = false;
        });
        if (!ok) return;

                // Build payload with fresh nonce (bypasses page cache expiry)
        var ajaxUrl    = '<?php echo esc_js( admin_url("admin-ajax.php") ); ?>';
        var cachedNonce = (typeof scfFront !== 'undefined' && scfFront.nonce) ? scfFront.nonce : '';

        // Get redirect from selected option
        var redirect = '';
        form.querySelectorAll('select').forEach(function(sel) {
            var opt = sel.options[sel.selectedIndex];
            if (opt && opt.dataset.redirect) redirect = opt.dataset.redirect;
        });

        btn.disabled = true;
        btn.style.opacity = '0.7';
        response.style.display = 'none';

        var doSubmit = function(fd) {
            fetch(ajaxUrl, {
                method: 'POST',
                body: fd,
                credentials: 'same-origin'
            })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                btn.disabled = false;
                btn.style.opacity = '1';
                if (res.success) {
                    form.style.display = 'none';
                    response.style.cssText = 'display:block;padding:24px;border-radius:12px;background:#ecfdf5;border:1px solid #bbf7d0;text-align:center;font-family:\'<?php echo esc_js($ff); ?>\',sans-serif;';
                    response.innerHTML = '<div style="font-size:2em;margin-bottom:8px;">✅</div><div style="font-weight:700;color:#065f46;font-size:1.05em;margin-bottom:6px;">Message Sent!</div><div style="color:#047857;font-size:.9em;">' + (res.data.message || '') + '</div>';
                    var redir = res.data.redirect || redirect;
                    if (redir) setTimeout(function() { window.location.href = redir; }, 1800);
                } else {
                    response.style.cssText = 'display:block;padding:12px 16px;border-radius:8px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;font-size:13px;margin-bottom:16px;font-family:\'<?php echo esc_js($ff); ?>\',sans-serif;';
                    response.innerHTML = res.data && res.data.message ? res.data.message : 'Bitte prüfen Sie Ihre Eingaben und versuchen Sie es noch einmal.';
                }
            })
            .catch(function() {
                btn.disabled = false;
                btn.style.opacity = '1';
                response.style.cssText = 'display:block;padding:12px 16px;border-radius:8px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;font-size:13px;margin-bottom:16px;';
                response.innerHTML = 'Netzwerkfehler. Bitte versuchen Sie es noch einmal.';
            });
        };

        var buildPayload = function(freshNonce) {
            // Set time BEFORE FormData snapshot
            var timeEl = form.querySelector('[name="scf_time_on_page"]');
            var timeVal = Math.floor(Date.now() / 1000) - pageLoadTime;
            if (timeEl) { timeEl.value = timeVal; }

            var payload = new FormData(form);
            payload.append('action', 'scf_submit');
            payload.append('nonce',  freshNonce || cachedNonce);
            // Ensure time is in payload (belt+suspenders)
            payload.set('scf_time_on_page', timeVal);
            <?php if ( ! empty( $settings['recaptcha_enabled'] ) && ! empty( $settings['recaptcha_site_key'] ) ) : ?>
            if (typeof grecaptcha !== 'undefined') {
                grecaptcha.ready(function() {
                    grecaptcha.execute('<?php echo esc_js( $settings['recaptcha_site_key'] ); ?>', { action: 'scf_submit' }).then(function(token) {
                        payload.append('recaptcha_token', token);
                        doSubmit(payload);
                    });
                });
            } else { doSubmit(payload); }
            <?php else : ?>
            doSubmit(payload);
            <?php endif; ?>
        };

        // Always fetch a live nonce — bypasses cached page nonce expiry
        fetch(ajaxUrl + '?action=scf_refresh_nonce', { credentials: 'same-origin' })
            .then(function(r) { return r.json(); })
            .then(function(r) { buildPayload(r && r.success ? r.data.nonce : cachedNonce); })
            .catch(function()  { buildPayload(cachedNonce); });
    });
})();
</script>
