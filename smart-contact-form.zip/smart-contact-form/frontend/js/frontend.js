/* Smart Contact Form – Frontend JS v2.4.8
 * NOTE: Form submit is handled by inline JS in form.php (per-form, with correct form_id + nonce).
 * This file handles only: focus styles cleanup, checkbox visuals, field error clearing.
 * DO NOT add a submit handler here — it will conflict with form.php's handler.
 */
(function ($) {
    'use strict';

    // Clear field errors on input (jQuery helper for any jQuery-enhanced fields)
    $(document).on('input change', '[id^="scf-form-"] .scf-input, [id^="scf-form-"] input, [id^="scf-form-"] textarea, [id^="scf-form-"] select', function () {
        $(this).removeClass('scf-err');
        var id = $(this).attr('id');
        if (id) { $('#scf-err-' + id).remove(); }
    });

}(jQuery));
