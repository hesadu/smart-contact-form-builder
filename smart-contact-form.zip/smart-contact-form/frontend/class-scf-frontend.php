<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCF_Frontend {

    public function __construct() {
        add_action( 'wp_ajax_scf_submit',           array( $this, 'handle_submit' ) );
        add_action( 'wp_ajax_nopriv_scf_submit',    array( $this, 'handle_submit' ) );
        add_action( 'wp_ajax_scf_refresh_nonce',    array( $this, 'handle_refresh_nonce' ) );
        add_action( 'wp_ajax_nopriv_scf_refresh_nonce', array( $this, 'handle_refresh_nonce' ) );
    }

    public function enqueue_for_form( $form_id, $settings ) {
        $font = urlencode( $settings['font_family'] ?? 'Inter' );
        wp_enqueue_style( 'scf-google-fonts', "https://fonts.googleapis.com/css2?family={$font}:wght@400;500;600;700&display=swap", array(), null );
        wp_enqueue_style( 'scf-frontend', SCF_PLUGIN_URL . 'frontend/css/frontend.css', array(), SCF_VERSION );
        wp_enqueue_script( 'scf-frontend', SCF_PLUGIN_URL . 'frontend/js/frontend.js', array( 'jquery' ), SCF_VERSION, true );

        if ( ! empty( $settings['recaptcha_enabled'] ) && ! empty( $settings['recaptcha_site_key'] ) ) {
            wp_enqueue_script( 'google-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . esc_attr( $settings['recaptcha_site_key'] ), array(), null, true );
        }

        // Localize per-form data (support multiple forms on same page)
        $existing = wp_scripts()->get_data( 'scf-frontend', 'data' );
        $new_form_data = array(
            'form_id'          => $form_id,
            'settings'         => $settings,
            'recaptchaSiteKey' => ! empty( $settings['recaptcha_enabled'] ) ? $settings['recaptcha_site_key'] : '',
        );

        if ( $existing ) {
            // Already localized — inject additional form data via inline script
            wp_add_inline_script( 'scf-frontend',
                'if(typeof scfForms==="undefined") window.scfForms={};' .
                'scfForms[' . (int)$form_id . ']=' . wp_json_encode($new_form_data) . ';'
            );
        } else {
            wp_localize_script( 'scf-frontend', 'scfFront', array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'scf_submit_nonce' ),
            ) );
            wp_add_inline_script( 'scf-frontend',
                'if(typeof scfForms==="undefined") window.scfForms={};' .
                'scfForms[' . (int)$form_id . ']=' . wp_json_encode($new_form_data) . ';'
            );
        }

        wp_add_inline_style( 'scf-frontend', $this->generate_css( $settings, $form_id ) );
    }

    // Legacy support
    public function enqueue() {
        $forms = SCF_Database::get_all_forms();
        if ( ! empty( $forms ) ) {
            $settings = SCF_Database::get_form( $forms[0]['id'] );
            $this->enqueue_for_form( $forms[0]['id'], $settings );
        }
    }

    private function generate_css( $s, $form_id ) {
        $pc  = sanitize_hex_color( $s['primary_color']     ?? '#1e3a5f' );
        $sc  = sanitize_hex_color( $s['secondary_color']   ?? '#2563eb' );
        $bc  = sanitize_hex_color( $s['button_color']      ?? '#1e3a5f' );
        $bt  = sanitize_hex_color( $s['button_text_color'] ?? '#ffffff' );
        $bg  = sanitize_hex_color( $s['bg_color']          ?? '#f8fafc' );
        $tc  = sanitize_hex_color( $s['text_color']        ?? '#64748b' );
        $hc  = sanitize_hex_color( $s['heading_color']     ?? '#1e293b' );
        $ff  = esc_attr( $s['font_family'] ?? 'Inter' );
        $fz  = absint( $s['font_size'] ?? 15 );
        $img = ! empty( $s['bg_image'] ) ? "url('" . esc_url( $s['bg_image'] ) . "')" : 'none';
        $id  = (int) $form_id;
        return ".scf-section[data-form-id='{$id}']{--scf-pc:{$pc};--scf-sc:{$sc};--scf-bc:{$bc};--scf-bt:{$bt};--scf-bg:{$bg};--scf-tc:{$tc};--scf-hc:{$hc};--scf-ff:'{$ff}';--scf-fz:{$fz}px;--scf-bg-img:{$img};}";
    }

    public function handle_refresh_nonce() {
        wp_send_json_success( array( 'nonce' => wp_create_nonce( 'scf_submit_nonce' ) ) );
    }

    public function handle_submit() {
        $dbg = '[SCF submit] ';

        // Step 1: nonce
        if ( ! check_ajax_referer( 'scf_submit_nonce', 'nonce', false ) ) {
            error_log( $dbg . 'FAIL nonce. POST nonce=' . ( $_POST['nonce'] ?? 'missing' ) );
            wp_send_json_error( array( 'message' => 'Sicherheitsprüfung fehlgeschlagen. Bitte laden Sie die Seite neu und versuchen Sie es erneut.' ) );
        }

        // Step 2: form_id
        $form_id  = absint( isset( $_POST['form_id'] ) ? $_POST['form_id'] : 0 );
        $settings = $form_id ? SCF_Database::get_form( $form_id ) : null;
        error_log( $dbg . 'form_id=' . $form_id . ' settings=' . ( $settings ? 'found' : 'null' ) );

        if ( ! $settings ) {
            $forms    = SCF_Database::get_all_forms();
            $settings = ! empty( $forms ) ? SCF_Database::get_form( (int) $forms[0]['id'] ) : null;
            $form_id  = ! empty( $forms ) ? (int) $forms[0]['id'] : 0;
            error_log( $dbg . 'fallback form_id=' . $form_id );
        }

        if ( ! $settings || ! $form_id ) {
            error_log( $dbg . 'FAIL form not found' );
            wp_send_json_error( array( 'message' => 'Formular nicht gefunden.' ) );
        }

        // Step 3: honeypot
        if ( ! empty( $_POST['scf_hp'] ) ) {
            error_log( $dbg . 'honeypot triggered' );
            wp_send_json_success( array( 'message' => esc_html( $settings['success_message'] ), 'redirect' => '' ) );
        }

        // Step 4: spam guard
        $fields = $settings['fields'] ?? array();
        if ( ! empty( $fields ) ) {
            $spam_check = SCF_Spam_Guard::check_submission( $fields, $_POST, $settings );
            error_log( $dbg . 'spam_check=' . json_encode( $spam_check ) . ' time_on_page=' . ( $_POST['scf_time_on_page'] ?? 'missing' ) );
            if ( ! $spam_check['passed'] ) {
                $bot_reasons = array( 'bot_too_fast' );
                if ( in_array( $spam_check['reason'], $bot_reasons, true ) ) {
                    error_log( $dbg . 'SILENT FAIL bot_too_fast' );
                    wp_send_json_success( array( 'message' => esc_html( $settings['success_message'] ), 'redirect' => '' ) );
                }
                $messages = array(
                    'invalid_email'    => 'Bitte geben Sie eine gültige E-Mail-Adresse ein.',
                    'invalid_phone'    => 'Bitte geben Sie eine gültige Telefonnummer ein.',
                    'invalid_name'     => 'Bitte geben Sie Ihren richtigen Namen ein.',
                    'invalid_postcode' => 'Bitte gültige Postleitzahl eingeben.',
                    'invalid_address'  => 'Bitte geben Sie eine gültige Adresse ein.',
                    'same_name'        => 'Vor- und Nachname dürfen nicht identisch sein.',
                    'spam_message'     => 'Bitte prüfen Sie Ihre Eingaben und versuchen Sie es noch einmal.',
                    'spam_domain'      => 'Bitte geben Sie eine gültige E-Mail-Adresse ein.',
                );
                $msg = isset( $messages[ $spam_check['reason'] ] ) ? $messages[ $spam_check['reason'] ] : 'Bitte prüfen Sie Ihre Eingaben und versuchen Sie es noch einmal.';
                error_log( $dbg . 'FAIL spam: ' . $spam_check['reason'] );
                wp_send_json_error( array( 'message' => $msg ) );
            }
        }

        // Rate Limiting
        if ( ! empty( $settings['rate_limit_enabled'] ) ) {
            $allowed = SCF_Rate_Limiter::check( (int)$settings['rate_limit_attempts'], (int)$settings['rate_limit_window'] );
            if ( ! $allowed ) {
                wp_send_json_error( array( 'message' => 'Zu viele Anfragen. Bitte versuchen Sie es später erneut.' ) );
            }
        }

        // reCAPTCHA
        if ( ! empty( $settings['recaptcha_enabled'] ) && ! empty( $settings['recaptcha_secret_key'] ) ) {
            $token = isset( $_POST['recaptcha_token'] ) ? sanitize_text_field( wp_unslash( $_POST['recaptcha_token'] ) ) : '';
            if ( ! SCF_Recaptcha::verify( $token, $settings['recaptcha_secret_key'], (float)$settings['recaptcha_score'] ) ) {
                wp_send_json_error( array( 'message' => __( 'Security verification failed.', 'smart-contact-form-builder' ) ) );
            }
        }

        $fields    = $settings['fields'] ?? array();
        $form_data = array();
        $redirect  = '';
        $errors    = array();

        foreach ( $fields as $field ) {
            $key      = sanitize_key( $field['id'] );
            $type     = $field['type'];
            $label    = sanitize_text_field( $field['label'] );
            $required = ! empty( $field['required'] );

            if ( $type === 'heading' ) continue;

            if ( $type === 'checkbox' ) {
                $checked = ! empty( $_POST[ $key ] );
                if ( $required && ! $checked ) $errors[] = sprintf( __('%s is required.','smart-contact-form-builder'), $label );
                $form_data[$label] = $checked ? __('Yes','smart-contact-form-builder') : __('No','smart-contact-form-builder');
                continue;
            }

            $raw = isset( $_POST[$key] ) ? wp_unslash( $_POST[$key] ) : '';
            if ( $type === 'textarea' )    $raw = sanitize_textarea_field( $raw );
            elseif ( $type === 'email' )   { $raw = sanitize_email($raw); if($raw && !is_email($raw)) $errors[] = sprintf('%s muss eine gültige E-Mail-Adresse sein.', $label); }
            else                           $raw = sanitize_text_field( $raw );

            if ( $required && '' === $raw ) $errors[] = sprintf( __('%s is required.','smart-contact-form-builder'), $label );
            $form_data[$label] = $raw;

            if ( $type === 'select' && ! empty($field['options']) ) {
                foreach ( $field['options'] as $opt ) {
                    if ( $opt['label'] === $raw && ! empty($opt['redirect']) ) $redirect = esc_url_raw($opt['redirect']);
                }
            }
        }

        if ( ! empty( $errors ) ) wp_send_json_error( array( 'message' => implode(' ', $errors) ) );

        error_log( '[SCF submit] save_submissions=' . ( $settings['save_submissions'] ?? 0 ) . ' send_email=' . ( $settings['send_email'] ?? 0 ) . ' form_data_keys=' . implode(',', array_keys($form_data)) . ' errors=' . implode('|', $errors) );

        if ( ! empty( $settings['save_submissions'] ) ) {
            $saved_id = SCF_Database::save_submission( $form_data, $form_id );
            error_log( '[SCF submit] saved submission id=' . $saved_id );
        } else {
            error_log( '[SCF submit] save_submissions is OFF — not saving' );
        }

        if ( ! empty( $settings['send_email'] ) ) {
            $mail_result = SCF_Mailer::send( $form_data, $settings );
            error_log( '[SCF submit] mail result=' . ( $mail_result ? 'sent' : 'FAILED' ) . ' to=' . ( $settings['admin_email'] ?? 'unknown' ) );
        }

        wp_send_json_success( array( 'message' => esc_html($settings['success_message']), 'redirect' => $redirect ) );
    }
}
