<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCF_Admin {

    public function __construct() {
        add_action( 'admin_menu',                        array( $this, 'add_menu' ) );
        add_action( 'admin_enqueue_scripts',             array( $this, 'enqueue' ) );
        add_action( 'wp_ajax_scf_save_settings',         array( $this, 'ajax_save_settings' ) );
        add_action( 'wp_ajax_scf_test_email',            array( $this, 'ajax_test_email' ) );
        add_action( 'wp_ajax_scf_delete_submission',     array( $this, 'ajax_delete_submission' ) );
        add_action( 'wp_ajax_scf_create_form',           array( $this, 'ajax_create_form' ) );
        add_action( 'wp_ajax_scf_delete_form',           array( $this, 'ajax_delete_form' ) );
        add_action( 'wp_ajax_scf_duplicate_form',        array( $this, 'ajax_duplicate_form' ) );
        add_action( 'wp_ajax_scf_layout_save',           array( $this, 'ajax_layout_save' ) );
        add_action( 'wp_ajax_scf_layout_preview',        array( $this, 'ajax_layout_preview' ) );
        add_filter( 'admin_body_class',                  array( $this, 'body_class' ) );
    }

    public function body_class( $classes ) {
        $screen = get_current_screen();
        $scf_pages = array(
            'toplevel_page_smart-contact-form',
            'contact-form_page_scf-builder',
            'contact-form_page_scf-submissions',
            'contact-form_page_scf-layout',
        );
        if ( $screen && in_array( $screen->id, $scf_pages, true ) ) {
            $classes .= ' scf-admin-page';
        }
        return $classes;
    }

    /* ── Menu ── */
    public function add_menu() {
        add_menu_page(
            __( 'Smart Contact Form', 'smart-contact-form-builder' ),
            __( 'Contact Form', 'smart-contact-form-builder' ),
            'manage_options',
            'smart-contact-form-builder',
            array( $this, 'page_forms_list' ),
            'dashicons-email-alt',
            58
        );
        add_submenu_page(
            'smart-contact-form-builder',
            __( 'All Forms', 'smart-contact-form-builder' ),
            __( 'All Forms', 'smart-contact-form-builder' ),
            'manage_options',
            'smart-contact-form-builder',
            array( $this, 'page_forms_list' )
        );
        add_submenu_page(
            'smart-contact-form-builder',
            __( 'Form Builder', 'smart-contact-form-builder' ),
            __( 'Form Builder', 'smart-contact-form-builder' ),
            'manage_options',
            'scf-builder',
            array( $this, 'page_builder' )
        );
        add_submenu_page(
            'smart-contact-form-builder',
            __( 'Submissions', 'smart-contact-form-builder' ),
            __( 'Submissions', 'smart-contact-form-builder' ),
            'manage_options',
            'scf-submissions',
            array( $this, 'page_submissions' )
        );
        add_submenu_page(
            'smart-contact-form-builder',
            __( 'Layout', 'smart-contact-form-builder' ),
            __( 'Layout', 'smart-contact-form-builder' ),
            'manage_options',
            'scf-layout',
            array( $this, 'page_layout' )
        );
    }

    /* ── Enqueue ── */
    public function enqueue( $hook ) {
        $pages = array(
            'toplevel_page_smart-contact-form',
            'contact-form_page_scf-builder',
            'contact-form_page_scf-submissions',
            'contact-form_page_scf-layout',
        );
        if ( ! in_array( $hook, $pages, true ) ) return;

        wp_enqueue_media();
        wp_enqueue_style(  'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_script( 'jquery-ui-sortable' );

        wp_enqueue_style( 'scf-admin', SCF_PLUGIN_URL . 'admin/css/admin.css', array( 'wp-color-picker' ), SCF_VERSION );
        wp_enqueue_script( 'scf-admin', SCF_PLUGIN_URL . 'admin/js/admin.js', array( 'jquery', 'jquery-ui-sortable', 'wp-color-picker' ), SCF_VERSION, true );

        // Get current form for builder page
        $form_id  = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
        $settings = $form_id ? SCF_Database::get_form( $form_id ) : array();

        wp_localize_script( 'scf-admin', 'scfAdmin', array(
            'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'scf_admin_nonce' ),
            'settings'   => $settings,
            'formId'     => $form_id,
            'builderUrl' => admin_url( 'admin.php?page=scf-builder' ),
            'formsUrl'   => admin_url( 'admin.php?page=smart-contact-form' ),
            'strings'    => array(
                'saved'        => __( 'Settings saved!', 'smart-contact-form-builder' ),
                'error'        => __( 'Error saving. Please try again.', 'smart-contact-form-builder' ),
                'confirmDel'   => __( 'Delete this submission?', 'smart-contact-form-builder' ),
                'confirmForm'  => __( 'Delete this form and all its submissions?', 'smart-contact-form-builder' ),
                'saving'       => __( 'Saving...', 'smart-contact-form-builder' ),
                'newFormName'  => __( 'Enter form name:', 'smart-contact-form-builder' ),
            ),
        ) );
    }

    /* ── Pages ── */
    public function page_forms_list() {
        $forms = SCF_Database::get_all_forms();
        // Attach submission counts
        foreach ( $forms as &$form ) {
            $form['submission_count'] = SCF_Database::count_submissions( $form['id'] );
        }
        include SCF_PLUGIN_DIR . 'admin/views/forms-list.php';
    }

    public function page_builder() {
        $form_id = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
        if ( ! $form_id ) {
            wp_redirect( admin_url( 'admin.php?page=smart-contact-form' ) );
            exit;
        }
        $settings = SCF_Database::get_form( $form_id );
        if ( ! $settings ) {
            wp_die( 'Form not found.' );
        }
        include SCF_PLUGIN_DIR . 'admin/views/settings.php';
    }

    public function page_layout() {
        $all_forms = SCF_Database::get_all_forms();
        $form_id   = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
        if ( ! $form_id && ! empty( $all_forms ) ) {
            $form_id = (int) $all_forms[0]['id'];
        }
        $settings = $form_id ? SCF_Database::get_form( $form_id ) : SCF_Admin::get_default_settings();
        if ( ! $settings ) $settings = SCF_Admin::get_default_settings();
        include SCF_PLUGIN_DIR . 'admin/views/layout.php';
    }

    public function page_submissions() {
        $form_id     = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
        $per_page    = 20;
        $page        = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
        $submissions = SCF_Database::get_submissions( $per_page, $page, $form_id );
        $total       = SCF_Database::count_submissions( $form_id );
        $forms       = SCF_Database::get_all_forms();
        include SCF_PLUGIN_DIR . 'admin/views/submissions.php';
    }

    /* ── AJAX: Save Settings ── */
    public function ajax_save_settings() {
        check_ajax_referer( 'scf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Unauthorized' ) );

        $form_id = absint( isset( $_POST['form_id'] ) ? $_POST['form_id'] : 0 );
        if ( ! $form_id ) {
            wp_send_json_error( array( 'message' => 'Form ID missing. Please reload the page and try again.' ) );
        }

        $raw_json = isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : '';
        $posted   = json_decode( $raw_json, true );
        if ( ! is_array( $posted ) ) wp_send_json_error( array( 'message' => 'Invalid data' ) );

        $current  = SCF_Database::get_form( $form_id );
        if ( ! $current ) wp_send_json_error( array( 'message' => 'Form not found' ) );

        $settings = $current;

        // Colors
        foreach ( array( 'primary_color','secondary_color','button_color','button_text_color','bg_color','text_color','heading_color' ) as $k ) {
            if ( isset( $posted[$k] ) ) { $v = sanitize_hex_color( $posted[$k] ); if($v) $settings[$k] = $v; }
        }
        // Strings
        foreach ( array( 'font_family','company_name','company_tagline','address','phone','email_display','admin_email','email_subject','success_message','form_title','button_text','recaptcha_site_key','recaptcha_secret_key' ) as $k ) {
            if ( isset( $posted[$k] ) ) $settings[$k] = sanitize_text_field( $posted[$k] );
        }
        if ( isset( $posted['font_size'] ) )             $settings['font_size']           = absint( $posted['font_size'] );
        if ( isset( $posted['bg_image'] ) )              $settings['bg_image']            = esc_url_raw( $posted['bg_image'] );
        // Layout fields
        foreach ( array('bg_type','bg_gradient_dir','bg_image_pos','bg_image_size','bg_gradient_from','bg_gradient_to') as $k ) {
            if ( isset( $posted[$k] ) ) $settings[$k] = sanitize_text_field( $posted[$k] );
        }
        if ( isset( $posted['form_max_width'] ) )  $settings['form_max_width']  = absint( $posted['form_max_width'] );
        if ( isset( $posted['form_min_height'] ) ) $settings['form_min_height'] = absint( $posted['form_min_height'] );
        if ( isset( $posted['form_padding'] ) )    $settings['form_padding']    = absint( $posted['form_padding'] );
        $settings['bg_overlay'] = ! empty( $posted['bg_overlay'] ) ? 1 : 0;
        if ( isset( $posted['recaptcha_score'] ) )       $settings['recaptcha_score']     = floatval( $posted['recaptcha_score'] );
        if ( isset( $posted['rate_limit_attempts'] ) )   $settings['rate_limit_attempts'] = absint( $posted['rate_limit_attempts'] );
        if ( isset( $posted['rate_limit_window'] ) )     $settings['rate_limit_window']   = absint( $posted['rate_limit_window'] );
        $settings['save_submissions']  = !empty($posted['save_submissions'])  ? 1:0;
        $settings['send_email']        = !empty($posted['send_email'])        ? 1:0;
        $settings['show_info_panel']   = !empty($posted['show_info_panel'])   ? 1:0;
        $settings['rate_limit_enabled']= !empty($posted['rate_limit_enabled'])? 1:0;
        $settings['recaptcha_enabled'] = !empty($posted['recaptcha_enabled']) ? 1:0;

        // Fields
        if ( isset( $posted['fields'] ) && is_array( $posted['fields'] ) ) {
            $fields = array();
            foreach ( $posted['fields'] as $field ) {
                if ( empty( $field['type'] ) ) continue;
                $f = array(
                    'id'          => sanitize_key( $field['id'] ?? 'field_'.uniqid() ),
                    'type'        => sanitize_key( $field['type'] ),
                    'label'       => sanitize_text_field( $field['label'] ?? '' ),
                    'placeholder' => sanitize_text_field( $field['placeholder'] ?? '' ),
                    'required'    => !empty($field['required']) ? 1:0,
                    'halfWidth'   => !empty($field['halfWidth']) ? 1:0,
                );
                if ( $f['type']==='heading' ) {
                    $allowed = array('h2','h3','h4','divider');
                    $hs = sanitize_key($field['headingStyle'] ?? 'h3');
                    $f['headingStyle'] = in_array($hs,$allowed,true)?$hs:'h3';
                }
                if ( $f['type']==='select' && !empty($field['options']) && is_array($field['options']) ) {
                    $opts=array();
                    foreach($field['options'] as $opt){
                        $opts[]=array('label'=>sanitize_text_field($opt['label']??''),'redirect'=>esc_url_raw($opt['redirect']??''));
                    }
                    $f['options']=$opts;
                }
                $fields[] = $f;
            }
            $settings['fields'] = $fields;
        }

        // Form name from form_title
        $form_name = sanitize_text_field( $settings['form_title'] ?? $current['_form_name'] );
        unset( $settings['_form_id'], $settings['_form_name'] );

        SCF_Database::update_form( $form_id, $form_name, $settings );
        wp_send_json_success( array( 'message' => __('Settings saved!','smart-contact-form-builder'), 'form_name' => $form_name ) );
    }

    /* ── AJAX: Create Form ── */
    public function ajax_create_form() {
        check_ajax_referer( 'scf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Unauthorized' ) );

        $name   = sanitize_text_field( ! empty( $_POST['name'] ) ? wp_unslash( $_POST['name'] ) : 'New Form' );
        $new_id = SCF_Database::create_form( $name );

        if ( ! $new_id ) {
            wp_send_json_error( array( 'message' => 'Failed to create form.' ) );
        }

        wp_send_json_success( array( 'id' => $new_id ) );
    }

    /* ── AJAX: Delete Form ── */
    public function ajax_delete_form() {
        check_ajax_referer( 'scf_admin_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error();
        $id = absint( $_POST['id'] ?? 0 );
        SCF_Database::delete_form( $id );
        wp_send_json_success();
    }

    /* ── AJAX: Duplicate Form ── */
    public function ajax_duplicate_form() {
        check_ajax_referer( 'scf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Unauthorized' ) );

        $id     = absint( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
        $new_id = SCF_Database::duplicate_form( $id );

        if ( ! $new_id ) {
            wp_send_json_error( array( 'message' => 'Failed to duplicate form.' ) );
        }

        wp_send_json_success( array( 'id' => $new_id ) );
    }

    /* ── AJAX: Layout Save ── */
    public function ajax_layout_save() {
        check_ajax_referer( 'scf_layout_save', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Unauthorized' ) );

        $form_id = absint( $_POST['form_id'] ?? 0 );
        $raw     = wp_unslash( $_POST['layout'] ?? '' );
        $layout  = json_decode( $raw, true );
        if ( ! $form_id || ! is_array( $layout ) ) wp_send_json_error( array( 'message' => 'Invalid data' ) );

        $settings = SCF_Database::get_form( $form_id );
        if ( ! $settings ) wp_send_json_error( array( 'message' => 'Form not found' ) );

        // Sanitize & merge layout fields only
        foreach ( array( 'bg_type','bg_gradient_dir','bg_image_pos','bg_image_size' ) as $k ) {
            if ( isset( $layout[$k] ) ) $settings[$k] = sanitize_text_field( $layout[$k] );
        }
        foreach ( array( 'bg_gradient_from','bg_gradient_to','bg_color' ) as $k ) {
            if ( isset( $layout[$k] ) ) { $v = sanitize_hex_color( $layout[$k] ); if($v) $settings[$k] = $v; }
        }
        if ( isset( $layout['bg_image'] ) )        $settings['bg_image']        = esc_url_raw( $layout['bg_image'] );
        if ( isset( $layout['form_max_width'] ) )  $settings['form_max_width']  = absint( $layout['form_max_width'] );
        if ( isset( $layout['form_min_height'] ) ) $settings['form_min_height'] = absint( $layout['form_min_height'] );
        if ( isset( $layout['form_padding'] ) )    $settings['form_padding']    = absint( $layout['form_padding'] );
        $settings['bg_overlay'] = ! empty( $layout['bg_overlay'] ) ? 1 : 0;

        $form_name = $settings['form_title'] ?? $settings['_form_name'] ?? 'Form';
        unset( $settings['_form_id'], $settings['_form_name'] );
        SCF_Database::update_form( $form_id, $form_name, $settings );
        wp_send_json_success( array( 'message' => 'Layout saved!' ) );
    }

    /* ── AJAX: Layout Preview ── */
    public function ajax_layout_preview() {
        if ( ! check_ajax_referer( 'scf_layout_preview', 'nonce', false ) ) wp_die('Nonce error');
        if ( ! current_user_can( 'manage_options' ) ) wp_die('Unauthorized');

        $form_id  = absint( $_GET['form_id'] ?? $_POST['form_id'] ?? 0 );
        $settings = $form_id ? SCF_Database::get_form( $form_id ) : SCF_Admin::get_default_settings();
        if ( ! $settings ) $settings = SCF_Admin::get_default_settings();

        // Merge live layout overrides from ?layout=JSON
        $raw_layout = wp_unslash( $_GET['layout'] ?? $_POST['layout'] ?? '' );
        if ( $raw_layout ) {
            $layout = json_decode( $raw_layout, true );
            if ( is_array( $layout ) ) {
                foreach ( array( 'bg_type','bg_gradient_dir','bg_image_pos','bg_image_size','bg_image' ) as $k ) {
                    if ( isset( $layout[$k] ) ) $settings[$k] = sanitize_text_field( $layout[$k] );
                }
                foreach ( array( 'bg_gradient_from','bg_gradient_to','bg_color' ) as $k ) {
                    if ( isset( $layout[$k] ) ) { $v = sanitize_hex_color( $layout[$k] ); if($v) $settings[$k] = $v; }
                }
                if ( isset( $layout['form_max_width'] ) )  $settings['form_max_width']  = absint( $layout['form_max_width'] );
                if ( isset( $layout['form_min_height'] ) ) $settings['form_min_height'] = absint( $layout['form_min_height'] );
                if ( isset( $layout['form_padding'] ) )    $settings['form_padding']    = absint( $layout['form_padding'] );
                $settings['bg_overlay'] = ! empty( $layout['bg_overlay'] ) ? 1 : 0;
                if ( isset( $layout['bg_image'] ) )        $settings['bg_image']        = esc_url_raw( $layout['bg_image'] );
            }
        }

        // Render standalone preview HTML
        $form_id_var = $form_id; // for form.php
        ?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=<?php echo urlencode( $settings['font_family'] ?? 'Inter' ); ?>:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo esc_url( SCF_PLUGIN_URL . 'frontend/css/frontend.css' ); ?>">
<style>
html,body{margin:0;padding:0;background:transparent;}
.scf-outer{padding:0!important;}
</style>
</head>
<body>
<?php
$settings_var = $settings;
$form_id      = $form_id_var;
// Pass to form.php
extract( array( 'settings' => $settings_var, 'form_id' => $form_id ) );
include SCF_PLUGIN_DIR . 'frontend/views/form.php';
?>
</body>
</html>
<?php
        wp_die();
    }


    /* ── AJAX: Delete Submission ── */
    public function ajax_delete_submission() {
        check_ajax_referer( 'scf_admin_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error();
        $id = absint( $_POST['id'] ?? 0 );
        SCF_Database::delete_submission( $id );
        wp_send_json_success();
    }

    /* ── AJAX: Test Email ── */
    public function ajax_test_email() {
        check_ajax_referer( 'scf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $to = sanitize_email( isset( $_POST['to'] ) ? wp_unslash( $_POST['to'] ) : get_option('admin_email') );

        // Temporarily hook PHPMailer to capture errors
        $mail_error = '';
        $error_hook = function( $wp_error ) use ( &$mail_error ) {
            $mail_error = $wp_error->get_error_message();
        };
        add_action( 'wp_mail_failed', $error_hook );

        $sent = wp_mail(
            $to,
            '[SCF Test] Email delivery test from ' . get_bloginfo('name'),
            '<html><body style="font-family:Arial;padding:24px;"><h2 style="color:#1e3a5f;">✅ Test Email</h2><p>If you received this, <strong>wp_mail is working correctly</strong> on your server.</p><p style="color:#64748b;font-size:12px;">Sent: ' . current_time('mysql') . '</p></body></html>',
            array( 'Content-Type: text/html; charset=UTF-8' )
        );
        remove_action( 'wp_mail_failed', $error_hook );

        if ( $sent ) {
            wp_send_json_success( array( 'message' => 'Test email sent to ' . $to . '. Check your inbox (and spam folder).' ) );
        } else {
            wp_send_json_error( array( 'message' => 'wp_mail() returned false. ' . ( $mail_error ? 'Error: ' . $mail_error : 'No SMTP error captured — check your server PHP mail() config or install WP Mail SMTP plugin.' ) ) );
        }
    }

    /* ── Default Settings ── */
    public static function get_default_settings() {
        return array(
            'primary_color'        => '#1e3a5f',
            'secondary_color'      => '#2563eb',
            'button_color'         => '#1e3a5f',
            'button_text_color'    => '#ffffff',
            'bg_color'             => '#f8fafc',
            'text_color'           => '#64748b',
            'heading_color'        => '#1e293b',
            'font_family'          => 'Inter',
            'font_size'            => 15,
            'bg_image'             => '',
            'company_name'         => 'Get In Touch',
            'company_tagline'      => "We'd love to hear from you.",
            'address'              => '',
            'phone'                => '',
            'email_display'        => '',
            'admin_email'          => get_option('admin_email'),
            'email_subject'        => 'New Contact Form Submission',
            'success_message'      => 'Thank you! Your message has been sent successfully.',
            'save_submissions'     => 1,
            'send_email'           => 1,
            'show_info_panel'      => 1,
            'form_title'           => 'Contact Us',
            'button_text'          => 'Send Message',
            'recaptcha_enabled'    => 0,
            'recaptcha_site_key'   => '',
            'recaptcha_secret_key' => '',
            'recaptcha_score'      => 0.5,
            'rate_limit_enabled'   => 0,
            'rate_limit_attempts'  => 5,
            'rate_limit_window'    => 300,
            'form_max_width'       => 960,
            'form_min_height'      => 0,
            'form_padding'         => 60,
            'bg_type'              => 'color',
            'bg_gradient_from'     => '#1e3a5f',
            'bg_gradient_to'       => '#2563eb',
            'bg_gradient_dir'      => 'to bottom right',
            'bg_image_pos'         => 'center center',
            'bg_image_size'        => 'cover',
            'bg_overlay'           => 0,
            'fields'               => array(
                array('id'=>'f_name',    'type'=>'text',     'label'=>'Name',    'placeholder'=>'Your name',    'required'=>1,'halfWidth'=>1),
                array('id'=>'f_email',   'type'=>'email',    'label'=>'Email',   'placeholder'=>'Your email',   'required'=>1,'halfWidth'=>1),
                array('id'=>'f_message', 'type'=>'textarea', 'label'=>'Message', 'placeholder'=>'Your message', 'required'=>1,'halfWidth'=>0),
            ),
        );
    }

    // Legacy support
    public static function get_settings() {
        return self::get_default_settings();
    }
}
