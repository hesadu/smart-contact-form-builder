/* Smart Contact Form – Admin JS */
(function ($) {
    'use strict';

    /* ── State ─────────────────────────────────────────────────────────────── */
    var SCF = {
        settings: JSON.parse(JSON.stringify(scfAdmin.settings)), // deep copy
        fieldIdx: 0, // counter for unique temp IDs

        init: function () {
            this.fieldIdx = $('#scf-fields-list .scf-field-row').length;
            this.fixWPLayout();
            this.bindTabs();
            this.bindSpamToggles();
            this.bindInfoToggle();
            this.bindSortable();
            this.bindFieldEdit();
            this.bindFieldRemove();
            this.bindAddField();
            this.bindOptionAdd();
            this.bindOptionRemove();
            this.bindPreviewDevices();
            this.bindSave();
            this.bindDeleteSubmission();
            this.bindMediaUpload();
            this.bindColorPickers();
            this.bindLivePreview();
            this.bindCopyShortcode();
            this.renderPreview(true);
        },

        /* ── Fix WordPress Admin Layout ───────────────────────────────────── */
        fixWPLayout: function () {
            var wrap = document.querySelector('.scf-wrap');

            function apply() {
                var bar  = document.getElementById('wpadminbar');
                var menu = document.getElementById('adminmenuwrap');
                var h = bar  ? bar.getBoundingClientRect().height : 32;
                var w = menu ? menu.getBoundingClientRect().width  : 0;
                if (wrap) {
                    wrap.style.setProperty('top',  h + 'px', 'important');
                    wrap.style.setProperty('left', w + 'px', 'important');
                }
            }
            apply();
            requestAnimationFrame(apply);
            setTimeout(apply, 200);
            setTimeout(apply, 600);
            window.addEventListener('resize', apply);
            // Watch WP menu fold/unfold
            var menuEl = document.getElementById('adminmenuwrap');
            if (window.MutationObserver && menuEl) {
                new MutationObserver(apply).observe(menuEl, {attributes: true, subtree: false});
            }
        },


        /* ── Info Panel Toggle ───────────────────────────────────────────── */
        bindInfoToggle: function () {
            var $toggle = $('#scf-info-toggle');
            var $fields = $('#scf-info-fields');
            function update() {
                var on = $toggle.is(':checked');
                $fields.toggle(on);
                // Update live preview container class
                var $stage = $('#scf-preview-inner .scf-container');
                if (on) {
                    $stage.removeClass('scf-no-info');
                } else {
                    $stage.addClass('scf-no-info');
                }
            }
            $toggle.on('change', function() { update(); SCF.renderPreview(); });
            update();
        },

        /* ── Spam / Security Toggles ──────────────────────────────────────── */
        bindSpamToggles: function () {
            // Rate limiting toggle
            var $rlEnabled = $('#scf-rl-enabled');
            var $rlFields  = $('#scf-rl-fields');
            function toggleRL() { $rlFields.toggle( $rlEnabled.is(':checked') ); }
            $rlEnabled.on('change', toggleRL);
            toggleRL();

            // reCAPTCHA toggle
            var $rcEnabled = $('#scf-rc-enabled');
            var $rcFields  = $('#scf-rc-fields');
            function toggleRC() { $rcFields.toggle( $rcEnabled.is(':checked') ); }
            $rcEnabled.on('change', toggleRC);
            toggleRC();

            // Score slider live display
            $('#scf-rc-score').on('input', function () {
                $('#scf-score-display').text( parseFloat($(this).val()).toFixed(1) );
            });
        },

        /* ── Tabs ─────────────────────────────────────────────────────────── */
        bindTabs: function () {
            $(document).on('click', '.scf-htab', function (e) {
                e.preventDefault();
                var tab = $(this).data('tab');
                if (!tab) return;
                $('.scf-htab').removeClass('active');
                $(this).addClass('active');
        
        // ── Layout Tab: Sliders ────────────────────────────────────────────
        function initSlider(id, valId, suffix, zeroLabel) {
            var slider = document.getElementById(id);
            var display = document.getElementById(valId);
            if (!slider || !display) return;
            slider.addEventListener('input', function() {
                var v = parseInt(this.value);
                display.textContent = (zeroLabel && v === 0) ? zeroLabel : v + suffix;
                SCF.triggerPreview && SCF.triggerPreview();
            });
        }
        initSlider('scf-form-width',      'scf-form-width-val',      'px', null);
        initSlider('scf-form-min-height', 'scf-form-min-height-val', 'px', 'Auto');
        initSlider('scf-form-padding',    'scf-form-padding-val',    'px', null);

        // ── BG Type Toggle ─────────────────────────────────────────────────
        $(document).on('change', 'input[name="bg_type"]', function() {
            var val = $(this).val();
            $('.scf-bg-panel').hide();
            $('#scf-bg-panel-' + val).show();
            $('.scf-bg-type-btn').removeClass('active');
            $(this).closest('.scf-bg-type-btn').addClass('active');
            SCF.triggerPreview && SCF.triggerPreview();
        });

        // ── BG Image upload (reuse existing media btn) ─────────────────────
        // Layout tab media upload
        $(document).on('click', '#scf-layout-media-btn', function() {
            if (typeof wp !== 'undefined' && wp.media) {
                var frame = wp.media({ title: 'Background Image', button: { text: 'Select' }, multiple: false });
                frame.on('select', function() {
                    var url = frame.state().get('selection').first().toJSON().url;
                    $('#scf-bg-image').val(url);
                    SCF.triggerPreview && SCF.triggerPreview();
                });
                frame.open();
            }
        });

        $('#scf-media-btn').on('click', function() {
            if (typeof wp !== 'undefined' && wp.media) {
                var frame = wp.media({ title: 'Background Image', button: { text: 'Select' }, multiple: false });
                frame.on('select', function() {
                    var url = frame.state().get('selection').first().toJSON().url;
                    $('#scf-bg-image').val(url).trigger('change');
                    SCF.triggerPreview && SCF.triggerPreview();
                });
                frame.open();
            }
        });

        // Gradient direction change
        $('#scf-bg-grad-dir').on('change', function() {
            SCF.triggerPreview && SCF.triggerPreview();
        });

        // Auto-open tab from URL param (?tab=layout etc.)
        (function() {
            var urlParams = new URLSearchParams(window.location.search);
            var tabParam  = urlParams.get('tab');
            if (tabParam && $('.scf-htab[data-tab="' + tabParam + '"]').length) {
                $('.scf-htab').removeClass('active');
                $('.scf-htab[data-tab="' + tabParam + '"]').addClass('active');
                $('.scf-tab-pane').removeClass('active');
                $('#tab-' + tabParam).addClass('active');
                return;
            }
        })();

        $('.scf-tab-pane').removeClass('active');
                $('#tab-' + tab).addClass('active');
                SCF.renderPreview();
            });
        },

        /* ── Sortable ─────────────────────────────────────────────────────── */
        bindSortable: function () {
            $('#scf-fields-list').sortable({
                handle: '.scf-drag-handle',
                axis: 'y',
                placeholder: 'scf-sortable-placeholder',
                update: function () { SCF.renderPreview(); }
            });
        },

        /* ── Field edit toggle ────────────────────────────────────────────── */
        bindFieldEdit: function () {
            $(document).on('click', '.scf-field-edit-btn', function () {
                var row  = $(this).closest('.scf-field-row');
                var body = row.find('.scf-field-row-body');
                if (body.is(':visible')) {
                    body.slideUp(150);
                    row.removeClass('scf-editing');
                } else {
                    body.slideDown(150);
                    row.addClass('scf-editing');
                }
            });
            // Live update label preview when label input changes
            $(document).on('input', '.scf-fld-label', function () {
                var row = $(this).closest('.scf-field-row');
                row.find('.scf-field-row-label').text($(this).val());
                SCF.renderPreview();
            });
            $(document).on('change', '.scf-fld-required', function () {
                var row = $(this).closest('.scf-field-row');
                if ($(this).is(':checked')) {
                    if (!row.find('.scf-badge-req').length) {
                        row.find('.scf-field-row-label').after('<span class="scf-badge-req">REQ</span>');
                    }
                } else {
                    row.find('.scf-badge-req').remove();
                }
                SCF.renderPreview();
            });
            $(document).on('change', '.scf-fld-half', function () {
                var row = $(this).closest('.scf-field-row');
                if ($(this).is(':checked')) {
                    if (!row.find('.scf-badge-half').length) {
                        row.find('.scf-badge-req').after('<span class="scf-badge-half">½</span>');
                    }
                } else {
                    row.find('.scf-badge-half').remove();
                }
                SCF.renderPreview();
            });
            $(document).on('input change', '.scf-fld-placeholder, .scf-opt-label, .scf-opt-redirect', function () {
                SCF.renderPreview();
            });
        },

        /* ── Remove field ─────────────────────────────────────────────────── */
        bindFieldRemove: function () {
            $(document).on('click', '.scf-field-remove-btn', function () {
                $(this).closest('.scf-field-row').fadeOut(200, function () {
                    $(this).remove();
                    SCF.renderPreview();
                });
            });
        },

        /* ── Add field ────────────────────────────────────────────────────── */
        bindAddField: function () {
            $(document).on('click', '.scf-add-field-btn', function () {
                var type  = $(this).data('type');
                var html  = SCF.buildFieldRowHTML(type);
                $('#scf-fields-list').append(html);
                SCF.fieldIdx++;
                // Open new row
                var newRow = $('#scf-fields-list .scf-field-row').last();
                newRow.find('.scf-field-row-body').show();
                newRow.addClass('scf-editing');
                SCF.renderPreview();
            });
        },

        /* ── Option add/remove ────────────────────────────────────────────── */
        bindOptionAdd: function () {
            $(document).on('click', '.scf-opt-add-btn', function () {
                var list = $(this).prev('.scf-opts-list');
                list.append(SCF.buildOptionRowHTML());
                SCF.renderPreview();
            });
        },
        bindOptionRemove: function () {
            $(document).on('click', '.scf-opt-remove', function () {
                $(this).closest('.scf-opt-row').remove();
                SCF.renderPreview();
            });
        },

        /* ── Preview devices ──────────────────────────────────────────────── */
        bindPreviewDevices: function () {
            $(document).on('click', '.scf-device', function () {
                var device = $(this).data('device');
                $('.scf-device').removeClass('active');
                $(this).addClass('active');
                $('#scf-preview-stage').removeClass('desktop tablet mobile').addClass(device);
            });
        },

        /* ── Color pickers ────────────────────────────────────────────────── */
        bindColorPickers: function () {
            $('.scf-colorpicker').wpColorPicker({
                change: function () {
                    setTimeout(function () { SCF.renderPreview(); }, 50);
                },
                clear: function () {
                    setTimeout(function () { SCF.renderPreview(); }, 50);
                }
            });

            // Fix: reposition picker popup to fixed so it escapes overflow:hidden parents
            $(document).on('click', '.wp-color-result', function () {
                var $btn    = $(this);
                var $holder = $btn.closest('.wp-picker-container').find('.wp-picker-holder');

                // Small delay — WP needs to open it first
                setTimeout(function () {
                    if ($holder.is(':visible')) {
                        var rect = $btn[0].getBoundingClientRect();
                        $holder.css({
                            position:  'fixed',
                            top:       (rect.bottom + 4) + 'px',
                            left:      rect.left + 'px',
                            zIndex:    999999,
                            width:     '260px',
                            maxWidth:  '260px'
                        });

                        // Make sure it stays within viewport right edge
                        var holderRect = $holder[0].getBoundingClientRect();
                        if (holderRect.right > window.innerWidth - 8) {
                            $holder.css('left', (window.innerWidth - holderRect.width - 8) + 'px');
                        }
                        // Stay within viewport bottom
                        if (holderRect.bottom > window.innerHeight - 8) {
                            $holder.css({
                                top:    'auto',
                                bottom: '8px'
                            });
                        }
                    }
                }, 20);
            });

            // Reset position when picker closes
            $(document).on('click', function (e) {
                if (!$(e.target).closest('.wp-picker-container').length) {
                    $('.wp-picker-holder').css({ position: '', top: '', left: '', bottom: '', zIndex: '' });
                }
            });
        },

        /* ── Live preview (throttled) ─────────────────────────────────────── */
        bindLivePreview: function () {
            var timer;
            $('body').on('input change', '#tab-design input, #tab-design select, #tab-info input, #tab-info textarea', function () {
                clearTimeout(timer);
                timer = setTimeout(function () { SCF.renderPreview(); }, 120);
            });
        },

        /* ── Save ─────────────────────────────────────────────────────────── */
        bindSave: function () {
            var saving = false;
            $('#scf-save-btn').on('click', function (e) {
                e.preventDefault();
                if (saving) return;

                var fid = parseInt(document.getElementById('scf-form-id').value, 10) || 0;
                if (!fid) {
                    alert('Cannot save: Form ID not found. Please reload.');
                    return;
                }

                saving = true;
                var btn = $(this).prop('disabled', true);
                $('#scf-save-text').text(scfAdmin.strings.saving);
                var data = SCF.collectAllData();

                $.ajax({
                    url:    scfAdmin.ajaxUrl,
                    method: 'POST',
                    data: {
                        action:  'scf_save_settings',
                        nonce:   scfAdmin.nonce,
                        form_id: fid,
                        data:    JSON.stringify(data)
                    },
                    success: function (res) {
                        saving = false;
                        btn.prop('disabled', false);
                        $('#scf-save-text').text('Save Settings');
                        var notice = $('#scf-notice');
                        if (res.success) {
                            notice.attr('class', 'scf-notice success').text(res.data.message).show();
                        } else {
                            notice.attr('class', 'scf-notice error').text(res.data && res.data.message ? res.data.message : scfAdmin.strings.error).show();
                        }
                        setTimeout(function () { notice.fadeOut(300); }, 3000);
                    },
                    error: function () {
                        saving = false;
                        btn.prop('disabled', false);
                        $('#scf-save-text').text('Save Settings');
                        $('#scf-notice').attr('class', 'scf-notice error').text(scfAdmin.strings.error).show();
                    }
                });
            });
        },

        /* ── Delete submission ────────────────────────────────────────────── */
        bindDeleteSubmission: function () {
            $(document).on('click', '.scf-delete-sub', function () {
                if (!confirm(scfAdmin.strings.confirmDel)) return;
                var btn = $(this);
                var id  = btn.data('id');
                $.post(scfAdmin.ajaxUrl, { action: 'scf_delete_submission', nonce: scfAdmin.nonce, id: id }, function (res) {
                    if (res.success) btn.closest('tr').fadeOut(300, function () { $(this).remove(); });
                });
            });
        },

        /* ── Media upload ─────────────────────────────────────────────────── */
        bindMediaUpload: function () {
            if (typeof wp === 'undefined' || !wp.media) return;
            var uploader;
            $('#scf-media-btn').on('click', function (e) {
                e.preventDefault();
                if (uploader) { uploader.open(); return; }
                uploader = wp.media({ title: 'Choose Background Image', button: { text: 'Use Image' }, multiple: false });
                uploader.on('select', function () {
                    var att = uploader.state().get('selection').first().toJSON();
                    $('#scf-bg-image').val(att.url);
                    SCF.renderPreview();
                });
                uploader.open();
            });
        },

        /* ── Collect ALL form data into a plain object ─────────────────────── */
        collectAllData: function () {
            var d = {};

            // Color pickers (use wpColorPicker val)
            $('.scf-colorpicker').each(function () {
                d[$(this).attr('name')] = $(this).val();
            });

            // Other settings inputs
            $('#tab-design input[type="text"], #tab-design input[type="number"], #tab-design select').each(function () {
                if (!$(this).hasClass('scf-colorpicker') && $(this).attr('name')) {
                    d[$(this).attr('name')] = $(this).val();
                }
            });
            $('#tab-info input, #tab-info textarea').each(function () {
                if ($(this).attr('name')) d[$(this).attr('name')] = $(this).val();
            });
            // Email tab - all inputs (text, email, password, number, range, textarea, checkbox)
            $('#tab-email input[type="email"], #tab-email input[type="text"], #tab-email input[type="password"], #tab-email input[type="number"], #tab-email input[type="range"], #tab-email textarea').each(function () {
                if ($(this).attr('name')) d[$(this).attr('name')] = $(this).val();
            });
            $('#tab-email input[type="checkbox"]').each(function () {
                if ($(this).attr('name')) d[$(this).attr('name')] = $(this).is(':checked') ? 1 : 0;
            });

            // Layout tab — sliders, selects, radios, checkboxes
            $('#tab-layout input[type="range"], #tab-layout input[type="number"], #tab-layout input[type="text"], #tab-layout select').each(function () {
                if ($(this).attr('name')) d[$(this).attr('name')] = $(this).val();
            });
            // bg_type radio
            var bgTypeChecked = $('#tab-layout input[name="bg_type"]:checked');
            if (bgTypeChecked.length) d.bg_type = bgTypeChecked.val();
            // bg_overlay checkbox
            d.bg_overlay = $('#scf-bg-overlay').is(':checked') ? 1 : 0;
            // colorpickers in layout tab (bg_color, gradient colors — already caught by .scf-colorpicker above)

            // Info panel toggle
            d.show_info_panel = $('#scf-info-toggle').is(':checked') ? 1 : 0;

            // Fields
            d.fields = [];
            $('#scf-fields-list .scf-field-row').each(function () {
                var row  = $(this);
                var type = row.data('type');
                var f = {
                    id:          row.data('id') || ('field_' + Date.now()),
                    type:        type,
                    label:       row.find('.scf-fld-label').val()       || row.find('.scf-field-row-label').text() || '',
                    placeholder: row.find('.scf-fld-placeholder').val() || '',
                    required:    row.find('.scf-fld-required').is(':checked') ? 1 : 0,
                    halfWidth:   row.find('.scf-fld-half').is(':checked') ? 1 : 0
                };
                if (type === 'select') {
                    f.options = [];
                    row.find('.scf-opt-row').each(function () {
                        f.options.push({
                            label:    $(this).find('.scf-opt-label').val()    || '',
                            redirect: $(this).find('.scf-opt-redirect').val() || ''
                        });
                    });
                }
                d.fields.push(f);
            });

            return d;
        },

        /* ── Collect design/info only (for live preview) ──────────────────── */
        collectPreviewData: function (useDB) {
            var d = { fields: [] };

            $('.scf-colorpicker').each(function () {
                d[$(this).attr('name')] = $(this).val() || $(this).data('current-color');
            });
            $('[name="font_family"]').each(function () { d.font_family = $(this).val(); });
            $('[name="font_size"]').each(function () { d.font_size = parseInt($(this).val()) || 15; });
            $('[name="bg_image"]').each(function () { d.bg_image = $(this).val(); });

            // Layout tab fields for live preview
            $('[name="form_max_width"]').each(function () { d.form_max_width = parseInt($(this).val()) || 960; });
            $('[name="form_min_height"]').each(function () { d.form_min_height = parseInt($(this).val()) || 0; });
            $('[name="form_padding"]').each(function () { d.form_padding = parseInt($(this).val()) || 60; });
            var bgTypeEl = $('input[name="bg_type"]:checked');
            d.bg_type         = bgTypeEl.length ? bgTypeEl.val() : 'color';
            $('[name="bg_gradient_from"]').each(function () { d.bg_gradient_from = $(this).val(); });
            $('[name="bg_gradient_to"]').each(function () { d.bg_gradient_to   = $(this).val(); });
            $('[name="bg_gradient_dir"]').each(function () { d.bg_gradient_dir  = $(this).val(); });
            $('[name="bg_image_pos"]').each(function () { d.bg_image_pos  = $(this).val(); });
            $('[name="bg_image_size"]').each(function () { d.bg_image_size = $(this).val(); });
            d.bg_overlay = $('#scf-bg-overlay').is(':checked') ? 1 : 0;
            $('[name="company_name"]').each(function () { d.company_name = $(this).val(); });
            $('[name="company_tagline"]').each(function () { d.company_tagline = $(this).val(); });
            $('[name="address"]').each(function () { d.address = $(this).val(); });
            $('[name="phone"]').each(function () { d.phone = $(this).val(); });
            $('[name="email_display"]').each(function () { d.email_display = $(this).val(); });
            $('[name="form_title"]').each(function () { d.form_title = $(this).val(); });
            $('[name="button_text"]').each(function () { d.button_text = $(this).val(); });
            d.show_info_panel = $('#scf-info-toggle').is(':checked') ? 1 : 0;

            if (useDB && scfAdmin && scfAdmin.settings && scfAdmin.settings.fields) {
                // Use saved DB data for accurate initial render (halfWidth, options etc.)
                d.fields = scfAdmin.settings.fields;
            } else {
                $('#scf-fields-list .scf-field-row').each(function () {
                    var row  = $(this);
                    var type = row.data('type');
                    var f = {
                        type:         type,
                        label:        row.find('.scf-fld-label').val() || row.find('.scf-field-row-label').text() || '',
                        placeholder:  row.find('.scf-fld-placeholder').val() || '',
                        required:     row.find('.scf-fld-required').is(':checked'),
                        halfWidth:    row.find('.scf-fld-half').is(':checked'),
                        headingStyle: row.find('.scf-fld-heading-style').val() || 'h3',
                        options:      []
                    };
                    if (type === 'select') {
                        row.find('.scf-opt-row').each(function () {
                            f.options.push({
                                label:    $(this).find('.scf-opt-label').val() || '',
                                redirect: $(this).find('.scf-opt-redirect').val() || ''
                            });
                        });
                    }
                    d.fields.push(f);
                });
            }
            return d;
        },

        /* ── Build field row HTML ─────────────────────────────────────────── */
        buildFieldRowHTML: function (type) {
            var typeColors = { text: '#3b82f6', email: '#10b981', phone: '#f59e0b', select: '#8b5cf6', textarea: '#06b6d4', checkbox: '#ec4899', heading: '#64748b' };
            var color      = typeColors[type] || '#64748b';
            var id         = 'new_field_' + (++this.fieldIdx) + '_' + Date.now();
            var typeLabel  = type.toUpperCase();
            var defaultLabel = { text: 'Text Field', email: 'Email', phone: 'Phone', select: 'Selector', textarea: 'Message', checkbox: 'Checkbox', heading: 'Section Title' }[type] || type;

            var selectOpts = '';
            if (type === 'select') {
                selectOpts = '<div class="scf-opts-wrap">' +
                    '<div class="scf-opts-header"><span>Label</span><span>Redirect URL (Optional)</span><span></span></div>' +
                    '<div class="scf-opts-list">' + this.buildOptionRowHTML() + '</div>' +
                    '<button type="button" class="scf-opt-add-btn"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg> Add Option</button>' +
                    '</div>';
            }

            var fieldBody;
            if (type === 'heading') {
                fieldBody =
                    '<div class="scf-field"><label>Heading Text</label><input type="text" class="scf-fld-label" value="Section Title"></div>' +
                    '<div class="scf-field" style="margin-top:8px;"><label>Style</label><select class="scf-fld-heading-style">' +
                        '<option value="h2">Large (H2)</option>' +
                        '<option value="h3" selected>Medium (H3)</option>' +
                        '<option value="h4">Small (H4)</option>' +
                        '<option value="divider">Divider Line Only</option>' +
                    '</select></div>';
            } else {
                fieldBody =
                    '<div class="scf-row-2">' +
                        '<div class="scf-field"><label>Label</label><input type="text" class="scf-fld-label" value="' + defaultLabel + '"></div>' +
                        '<div class="scf-field"><label>Placeholder</label><input type="text" class="scf-fld-placeholder" value=""></div>' +
                    '</div>' +
                    '<div class="scf-checks-row">' +
                        '<label class="scf-check-label"><input type="checkbox" class="scf-fld-required"> Required</label>' +
                        '<label class="scf-check-label"><input type="checkbox" class="scf-fld-half"> Half Width</label>' +
                    '</div>' +
                    selectOpts;
            }

            return '<div class="scf-field-row scf-editing" data-id="' + id + '" data-type="' + type + '">' +
                '<div class="scf-field-row-head">' +
                    '<span class="scf-drag-handle"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="5" r="1.5"/><circle cx="15" cy="5" r="1.5"/><circle cx="9" cy="12" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="15" cy="19" r="1.5"/></svg></span>' +
                    '<span class="scf-field-badge" style="background:' + color + '18;color:' + color + ';border-color:' + color + '30;">' + typeLabel + '</span>' +
                    '<span class="scf-field-row-label">' + defaultLabel + '</span>' +
                    '<button class="scf-field-edit-btn" title="Edit"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>' +
                    '<button class="scf-field-remove-btn" title="Remove"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg></button>' +
                '</div>' +
                '<div class="scf-field-row-body">' + fieldBody + '</div>' +
            '</div>';
        },

        buildOptionRowHTML: function () {
            return '<div class="scf-opt-row">' +
                '<input type="text" class="scf-opt-label"    placeholder="Option label">' +
                '<input type="text" class="scf-opt-redirect" placeholder="https://...">' +
                '<button class="scf-opt-remove" type="button"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6L6 18M6 6l12 12"/></svg></button>' +
            '</div>';
        },

        /* ── Render live preview ──────────────────────────────────────────── */
        renderPreview: function (initial) {
            var d  = this.collectPreviewData(initial);
            var pc = d.primary_color     || '#1e3a5f';
            var sc = d.secondary_color   || '#2563eb';
            var bc = d.button_color      || '#1e3a5f';
            var bt = d.button_text_color || '#ffffff';
            var bg = d.bg_color          || '#f1f5f9';
            var tc = d.text_color        || '#64748b';
            var hc = d.heading_color     || '#1e293b';
            var ff = d.font_family       || 'Inter';
            var fs = parseInt(d.font_size || 15);
            var bgImg = d.bg_image ? "url('" + d.bg_image + "')" : 'none';

            // Info panel left side
            var leftInfo = '';
            if (d.address)       leftInfo += SCF._infoRow(pc, tc, 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z', 'Address', d.address);
            if (d.phone)         leftInfo += SCF._infoRow(pc, tc, 'M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z', 'Phone', d.phone);
            if (d.email_display) leftInfo += SCF._infoRow(pc, tc, 'M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z', 'Email', d.email_display);

            // Build field rows (handle half-width pairing)
            var rows = [], i = 0, fields = d.fields || [];
            while (i < fields.length) {
                var f = fields[i];
                if (f.type === 'heading') {
                    rows.push({ heading: true, field: f });
                    i++;
                } else if (f.halfWidth && fields[i+1] && fields[i+1].halfWidth && fields[i+1].type !== 'heading') {
                    rows.push([f, fields[i+1]]);
                    i += 2;
                } else {
                    rows.push([f]);
                    i++;
                }
            }

            // Styles matching actual frontend output
            var inputS = 'width:100%;padding:9px 12px;background:#fff;border:1px solid #cbd5e1;border-radius:6px;font-size:' + (fs * 0.9) + 'px;color:' + hc + ';font-family:' + ff + ',sans-serif;box-sizing:border-box;outline:none;';
            var labelS = 'display:block;font-size:' + (fs * 0.85) + 'px;font-weight:600;color:' + tc + ';margin-bottom:4px;';

            var formFields = '';
            rows.forEach(function (row) {
                if (row.heading) {
                    formFields += SCF.renderPreviewField(row.field, labelS, inputS, tc, hc, pc);
                } else {
                    var cols = row.length === 2 ? '1fr 1fr' : '1fr';
                    formFields += '<div style="display:grid;grid-template-columns:' + cols + ';gap:14px;margin-bottom:16px;">';
                    row.forEach(function (f) { formFields += SCF.renderPreviewField(f, labelS, inputS, tc, hc, pc); });
                    formFields += '</div>';
                }
            });

            var showInfo = d.show_info_panel !== 0 && d.show_info_panel !== '0';
            var maxWidth = showInfo ? '860px' : '640px';

            var leftPanel = showInfo
                ? '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:32px 24px;">' +
                    '<div style="width:40px;height:4px;background:linear-gradient(90deg,' + pc + ',' + sc + ');border-radius:2px;margin-bottom:18px;"></div>' +
                    '<h2 style="color:' + hc + ';font-size:' + (fs * 1.4) + 'px;font-weight:700;margin:0 0 10px;line-height:1.2;font-family:' + ff + ',sans-serif;">' + this.esc(d.company_name || '') + '</h2>' +
                    '<p style="color:' + tc + ';font-size:' + (fs * 0.9) + 'px;line-height:1.7;margin:0 0 24px;font-family:' + ff + ',sans-serif;">' + this.esc(d.company_tagline || '') + '</p>' +
                    leftInfo +
                  '</div>'
                : '';

            var formCard =
                '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:32px 28px;">' +
                    '<h3 style="color:' + hc + ';font-size:' + (fs * 1.1) + 'px;font-weight:700;margin:0 0 20px;font-family:' + ff + ',sans-serif;">' + this.esc(d.form_title || 'Send us a Message') + '</h3>' +
                    formFields +
                    '<button style="width:100%;padding:13px 20px;background:' + bc + ';color:' + bt + ';border:none;border-radius:8px;font-size:' + (fs * 0.85) + 'px;font-weight:700;cursor:default;letter-spacing:.8px;text-transform:uppercase;font-family:' + ff + ',sans-serif;margin-top:4px;">' + this.esc(d.button_text || 'SEND') + '</button>' +
                '</div>';

            var grid = showInfo
                ? '<div style="display:grid;grid-template-columns:1fr 1.35fr;gap:28px;align-items:start;">' + leftPanel + formCard + '</div>'
                : formCard;

            var html =
                '<div style="background:' + bg + ';' + (bgImg !== 'none' ? 'background-image:' + bgImg + ';background-size:cover;background-position:center;' : '') + 'font-family:' + ff + ',sans-serif;font-size:' + fs + 'px;padding:40px 24px;min-height:100%;box-sizing:border-box;">' +
                    '<div style="max-width:' + maxWidth + ';margin:0 auto;">' + grid + '</div>' +
                '</div>';

            $('#scf-preview-inner').html(html);
        },

        _infoRow: function(pc, tc, path, label, value) {
            return '<div style="display:flex;gap:10px;align-items:flex-start;margin-bottom:14px;">' +
                '<div style="width:34px;height:34px;background:' + pc + '15;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">' +
                '<svg width="14" height="14" fill="' + pc + '" viewBox="0 0 24 24"><path d="' + path + '"/></svg></div>' +
                '<div><div style="font-size:.72em;font-weight:700;color:' + pc + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:.5px;">' + label + '</div>' +
                '<div style="font-size:.85em;color:' + tc + ';">' + SCF.esc(value) + '</div></div></div>';
        },

        renderPreviewField: function (f, labelS, inputS, tc, hc, pc) {
            var req   = f.required ? ' <span style="color:#ef4444;margin-left:2px;">*</span>' : '';
            var label = f.type !== 'checkbox'
                ? '<label style="' + labelS + '">' + this.esc(f.label) + req + '</label>'
                : '';
            var ph = this.esc(f.placeholder || f.label);

            switch (f.type) {
                case 'text': case 'email': case 'phone':
                    return '<div>' + label + '<input style="' + inputS + '" placeholder="' + ph + '" disabled></div>';
                case 'textarea':
                    return '<div>' + label + '<textarea style="' + inputS + 'min-height:110px;resize:vertical;" rows="4" placeholder="' + ph + '" disabled></textarea></div>';
                case 'select':
                    var arrowSvg = "url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2212%22 height=%2212%22 viewBox=%220 0 24 24%22 fill=%22%2364748b%22%3E%3Cpath d=%22M7 10l5 5 5-5z%22/%3E%3C/svg%3E')";
                    var selStyle = inputS + 'appearance:none;-webkit-appearance:none;cursor:pointer;background-image:' + arrowSvg + ';background-repeat:no-repeat;background-position:right 13px center;padding-right:36px;';
                    var opts = '<option>— ' + this.esc(f.label) + ' —</option>';
                    (f.options || []).forEach(function(o) { opts += '<option>' + SCF.esc(o.label) + '</option>'; });
                    return '<div>' + label + '<select style="' + selStyle + '" disabled>' + opts + '</select></div>';
                case 'checkbox':
                    return '<div style="display:flex;align-items:flex-start;gap:10px;">' +
                        '<div style="flex-shrink:0;width:18px;height:18px;margin-top:2px;border:1.5px solid #e2e8f0;border-radius:5px;background:#fff;"></div>' +
                        '<span style="font-size:13px;color:' + tc + ';line-height:1.55;">' + this.esc(f.label) + (f.required ? ' <span style="color:#ef4444;">*</span>' : '') + '</span>' +
                        '</div>';
                case 'heading':
                    var hs = f.headingStyle || 'h3';
                    if (hs === 'divider') {
                        return '<div style="margin:8px 0 18px;border-bottom:2px solid ' + pc + '30;"></div>';
                    }
                    var sizes = { h2: '1.3em', h3: '1.05em', h4: '.9em' };
                    var sz = sizes[hs] || '1.05em';
                    return '<div style="margin:6px 0 14px;padding-bottom:8px;border-bottom:2px solid ' + pc + '22;">' +
                        '<span style="font-size:' + sz + ';font-weight:700;color:' + hc + ';letter-spacing:.01em;">' + this.esc(f.label) + '</span>' +
                        '</div>';
                default:
                    return '';
            }
        },

        /* ── Copy shortcode ──────────────────────────────────────────────────── */
        bindCopyShortcode: function () {
            var btn = document.getElementById('scf-copy-shortcode');
            if (!btn) return;
            btn.addEventListener('click', function () {
                var text = '[smart_contact_form]';
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(text).then(function () {
                        btn.classList.add('copied');
                        var code = btn.querySelector('code');
                        var orig = code ? code.textContent : text;
                        if (code) code.textContent = 'Copied!';
                        setTimeout(function () {
                            btn.classList.remove('copied');
                            if (code) code.textContent = orig;
                        }, 1800);
                    });
                } else {
                    var ta = document.createElement('textarea');
                    ta.value = text; document.body.appendChild(ta);
                    ta.select(); document.execCommand('copy');
                    document.body.removeChild(ta);
                    btn.classList.add('copied');
                    setTimeout(function () { btn.classList.remove('copied'); }, 1800);
                }
            });
        },

        esc: function (str) {
            if (!str) return '';
            var d = document.createElement('div');
            d.textContent = String(str);
            return d.innerHTML;
        }
    };

    $(document).ready(function () {
        // Delete submission — runs on ALL pages (submissions page + builder)
        $(document).on('click', '.scf-delete-sub', function () {
            if (!confirm(scfAdmin.strings.confirmDel)) return;
            var btn = $(this);
            var id  = parseInt(btn.data('id'), 10);
            btn.prop('disabled', true).css('opacity', '0.5');
            $.post(scfAdmin.ajaxUrl, {
                action: 'scf_delete_submission',
                nonce:  scfAdmin.nonce,
                id:     id
            }, function (res) {
                if (res && res.success) {
                    btn.closest('tr').fadeOut(250, function () { $(this).remove(); });
                } else {
                    btn.prop('disabled', false).css('opacity', '1');
                    alert('Delete failed. Please try again.');
                }
            }).fail(function () {
                btn.prop('disabled', false).css('opacity', '1');
                alert('Network error.');
            });
        });

        // Fix fullscreen on ALL plugin pages
        (function fixPos() {
            var bar  = document.getElementById('wpadminbar');
            var menu = document.getElementById('adminmenuwrap');
            var el   = document.querySelector('.scf-wrap') || document.querySelector('.scf-fl');
            if (!el) return;
            el.style.setProperty('top',  (bar  ? bar.getBoundingClientRect().height : 32) + 'px', 'important');
            el.style.setProperty('left', (menu ? menu.getBoundingClientRect().width  : 0)  + 'px', 'important');
        })();

        // Only init builder on builder page
        if ( document.getElementById('scf-save-btn') && document.getElementById('scf-form-id') ) {
            SCF.init();
        }
    });

}(jQuery));
