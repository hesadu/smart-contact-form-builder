<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<style>
/* Hide WP chrome */
#wpcontent,#wpbody-content{padding:0!important;float:none!important;width:100%!important;}
#wpbody-content>.wrap{margin:0!important;padding:0!important;max-width:none!important;}
#wpbody-content>.notice,#wpbody-content>.updated,#wpbody-content>.update-nag,#wpbody-content>.error{display:none!important;}
#wpbody{padding-top:0!important;}
/* Full screen — left:0 default, JS sets correct value after menu measures */
.scf-fl{
    position:fixed!important;
    top:32px!important;
    left:0!important;
    right:0!important;
    bottom:0!important;
    overflow-y:auto!important;
    z-index:9990!important;
    font-family:-apple-system,BlinkMacSystemFont,'Inter',sans-serif;
    background:#f1f5f9;
}
.scf-fl-bar{display:flex;align-items:center;justify-content:space-between;background:#1e3a5f;padding:0 24px;height:52px;gap:12px;}
.scf-fl-logo{display:flex;align-items:center;gap:10px;flex-shrink:0;}
.scf-fl-logo-icon{width:32px;height:32px;background:linear-gradient(135deg,#3b82f6,#8b5cf6);border-radius:8px;display:flex;align-items:center;justify-content:center;}
.scf-fl-title{color:#fff;font-size:15px;font-weight:700;}
.scf-fl-newbtn{display:inline-flex;align-items:center;gap:7px;padding:8px 18px;background:#2563eb;color:#fff!important;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;text-decoration:none;transition:background .15s;flex-shrink:0;}
.scf-fl-newbtn:hover{background:#1d4ed8;}
.scf-fl-body{max-width:1100px;margin:0 auto;padding:32px 24px;}
.scf-fl-head{margin-bottom:24px;}
.scf-fl-head h1{font-size:22px;font-weight:800;color:#1e293b;margin:0 0 4px;}
.scf-fl-head p{color:#64748b;font-size:14px;margin:0;}
.scf-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;}
.scf-card{background:#fff;border-radius:12px;border:1.5px solid #e2e8f0;padding:20px;display:flex;flex-direction:column;gap:12px;transition:border-color .15s,box-shadow .15s;}
.scf-card:hover{border-color:#2563eb;box-shadow:0 4px 20px rgba(37,99,235,.1);}
.scf-card-head{display:flex;align-items:flex-start;gap:10px;}
.scf-card-icon{width:40px;height:40px;background:linear-gradient(135deg,#eff6ff,#dbeafe);border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.scf-card-info{flex:1;min-width:0;}
.scf-card-name{font-size:15px;font-weight:700;color:#1e293b;margin:0;word-break:break-word;line-height:1.3;}
.scf-card-date{font-size:11px;color:#94a3b8;margin-top:2px;}
.scf-badge{display:inline-flex;align-items:center;justify-content:center;background:#f0f9ff;color:#0369a1;border:1px solid #bae6fd;border-radius:20px;padding:2px 8px;font-size:11px;font-weight:700;flex-shrink:0;}
.scf-sc-tag{display:flex;align-items:center;gap:6px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:7px 10px;font-family:monospace;font-size:12px;color:#475569;cursor:pointer;transition:background .15s;user-select:none;}
.scf-sc-tag:hover{background:#e2e8f0;}
.scf-sc-tag svg{flex-shrink:0;}
.scf-card-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center;}
.scf-btn-edit{display:inline-flex;align-items:center;gap:5px;padding:7px 14px;background:#2563eb;color:#fff!important;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;text-decoration:none;transition:background .15s;}
.scf-btn-edit:hover{background:#1d4ed8;}
.scf-btn-sub{display:inline-flex;align-items:center;gap:5px;padding:7px 12px;background:#f1f5f9;color:#475569!important;border:1px solid #e2e8f0;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;text-decoration:none;transition:all .15s;}
.scf-btn-sub:hover{background:#e2e8f0;color:#1e293b!important;}
.scf-btn-dup{display:inline-flex;align-items:center;gap:5px;padding:7px 10px;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;border:none;transition:all .15s;}
.scf-btn-dup:hover{background:#dcfce7;}
.scf-btn-dup:disabled{opacity:.5;cursor:not-allowed;}
.scf-btn-del{display:inline-flex;align-items:center;padding:7px 10px;background:#fff5f5;color:#dc2626;border:1px solid #fecaca;border-radius:7px;cursor:pointer;transition:all .15s;margin-left:auto;}
.scf-btn-del:hover{background:#fee2e2;}
.scf-empty{text-align:center;padding:64px 24px;color:#94a3b8;grid-column:1/-1;}
.scf-empty svg{opacity:.25;margin-bottom:16px;}
.scf-empty h2{font-size:18px;font-weight:700;color:#475569;margin:0 0 8px;}
.scf-empty p{font-size:14px;margin:0 0 20px;}
.scf-fl-footer{text-align:center;padding:24px;font-size:11px;color:#94a3b8;}
</style>

<div class="scf-fl">
    <div class="scf-fl-bar">
        <div class="scf-fl-logo">
            <div class="scf-fl-logo-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
            </div>
            <span class="scf-fl-title">Smart Contact Form Builder</span>
        </div>
        <a href="#" class="scf-fl-newbtn" id="scf-new-form">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <?php esc_html_e( 'New Form', 'smart-contact-form-builder' ); ?>
        </a>
    </div>

    <div class="scf-fl-body">
        <div class="scf-fl-head">
            <h1><?php esc_html_e( 'All Forms', 'smart-contact-form-builder' ); ?></h1>
            <p><?php printf( esc_html__( '%d form(s) · Embed with shortcodes anywhere on your site', 'smart-contact-form-builder' ), count( $forms ) ); ?></p>
        </div>

        <div class="scf-grid" id="scf-grid">
            <?php if ( empty( $forms ) ) : ?>
            <div class="scf-empty">
                <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" display="block" style="margin:0 auto 16px"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                <h2><?php esc_html_e( 'No forms yet', 'smart-contact-form-builder' ); ?></h2>
                <p><?php esc_html_e( 'Create your first contact form to get started.', 'smart-contact-form-builder' ); ?></p>
                <a href="#" class="scf-fl-newbtn" id="scf-new-form-2"><?php esc_html_e( '+ Create First Form', 'smart-contact-form-builder' ); ?></a>
            </div>
            <?php else : ?>
            <?php foreach ( $forms as $f ) :
                $fid      = (int) $f['id'];
                $edit_url = admin_url( 'admin.php?page=scf-builder&form_id=' . $fid );
                $sub_url  = admin_url( 'admin.php?page=scf-submissions&form_id=' . $fid );
                $sc       = '[smart_contact_form id=' . $fid . ']';
            ?>
            <div class="scf-card">
                <div class="scf-card-head">
                    <div class="scf-card-icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                    </div>
                    <div class="scf-card-info">
                        <p class="scf-card-name"><?php echo esc_html( $f['name'] ); ?></p>
                        <p class="scf-card-date"><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $f['updated_at'] ) ) ); ?></p>
                    </div>
                    <span class="scf-badge"><?php echo (int) $f['submission_count']; ?></span>
                </div>

                <div class="scf-sc-tag" data-sc="<?php echo esc_attr( $sc ); ?>">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                    <?php echo esc_html( $sc ); ?>
                </div>

                <div class="scf-card-actions">
                    <a href="<?php echo esc_url( $edit_url ); ?>" class="scf-btn-edit">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        <?php esc_html_e( 'Edit', 'smart-contact-form-builder' ); ?>
                    </a>
                    <a href="<?php echo esc_url( $sub_url ); ?>" class="scf-btn-sub">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        <?php echo (int) $f['submission_count']; ?> <?php esc_html_e( 'Submissions', 'smart-contact-form-builder' ); ?>
                    </a>
                    <button class="scf-btn-dup" data-id="<?php echo $fid; ?>">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                        <?php esc_html_e( 'Duplicate', 'smart-contact-form-builder' ); ?>
                    </button>
                    <button class="scf-btn-del" data-id="<?php echo $fid; ?>">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="scf-fl-footer">⚡ Smart Contact Form Builder · <strong>Hesadu Creatives</strong> · v<?php echo esc_html( SCF_VERSION ); ?></div>
</div>

<script>
(function($){
    var NONCE   = '<?php echo wp_create_nonce( "scf_admin_nonce" ); ?>';
    var AJAX    = '<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>';
    var BUILDER = '<?php echo esc_js( admin_url( "admin.php?page=scf-builder&form_id=" ) ); ?>';
    var busy    = false; // global lock — prevent any double action

    /* ── Create form ── */
    function doCreate() {
        if ( busy ) return;
        var name = prompt('<?php esc_html_e( "Form name:", "smart-contact-form" ); ?>', 'New Contact Form');
        if ( ! name || ! name.trim() ) return;
        busy = true;
        $.post( AJAX, { action: 'scf_create_form', nonce: NONCE, name: name.trim() } )
            .done(function(r){
                if ( r && r.success && r.data && r.data.id ) {
                    window.location.href = BUILDER + r.data.id;
                } else {
                    alert('Error: ' + (r && r.data && r.data.message ? r.data.message : 'Unknown error'));
                    busy = false;
                }
            })
            .fail(function(){ alert('Network error.'); busy = false; });
    }
    $(document).on('click', '#scf-new-form, #scf-new-form-2', function(e){ e.preventDefault(); doCreate(); });

    /* ── Duplicate form ── */
    $(document).on('click', '.scf-btn-dup', function(){
        if ( busy ) return;
        var id   = parseInt( $(this).data('id'), 10 );
        var $btn = $(this).prop('disabled', true).text('...');
        busy = true;
        $.post( AJAX, { action: 'scf_duplicate_form', nonce: NONCE, id: id } )
            .done(function(r){
                if ( r && r.success && r.data && r.data.id ) {
                    window.location.href = BUILDER + r.data.id;
                } else {
                    $btn.prop('disabled', false).text('Duplicate');
                    busy = false;
                }
            })
            .fail(function(){ $btn.prop('disabled', false).text('Duplicate'); busy = false; });
    });

    /* ── Delete form ── */
    $(document).on('click', '.scf-btn-del', function(){
        if ( busy ) return;
        if ( ! confirm('<?php esc_html_e( "Delete this form and ALL its submissions? This cannot be undone.", "smart-contact-form" ); ?>') ) return;
        var id    = parseInt( $(this).data('id'), 10 );
        var $card = $(this).closest('.scf-card');
        busy = true;
        $.post( AJAX, { action: 'scf_delete_form', nonce: NONCE, id: id } )
            .done(function(r){
                if ( r && r.success ) { $card.fadeOut(250, function(){ $(this).remove(); }); }
                busy = false;
            })
            .fail(function(){ busy = false; });
    });

    /* ── Copy shortcode ── */
    $(document).on('click', '.scf-sc-tag', function(){
        var sc   = $(this).data('sc');
        var $el  = $(this);
        try {
            navigator.clipboard.writeText(sc).then(function(){
                var orig = $el.html();
                $el.html('<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Copied!');
                setTimeout(function(){ $el.html(orig); }, 1500);
            });
        } catch(e){}
    });
}(jQuery));

// Fix fullscreen position based on WP admin bar + menu actual size
(function(){
    function fixPos(){
        var bar  = document.getElementById('wpadminbar');
        var menu = document.getElementById('adminmenuwrap');
        var el   = document.querySelector('.scf-fl');
        if (!el) return;
        var top  = bar  ? bar.getBoundingClientRect().height  : 32;
        var left = menu ? menu.getBoundingClientRect().width  : 0;
        el.style.setProperty('top',  top  + 'px', 'important');
        el.style.setProperty('left', left + 'px', 'important');
    }
    // Run immediately (sync), then after paint, then after WP JS finishes
    fixPos();
    requestAnimationFrame(fixPos);
    setTimeout(fixPos, 200);
    setTimeout(fixPos, 600);
    window.addEventListener('resize', fixPos);
    // Also watch for WP menu fold/unfold
    var obs = window.MutationObserver && new MutationObserver(fixPos);
    var menuEl = document.getElementById('adminmenuwrap');
    if (obs && menuEl) obs.observe(menuEl, {attributes:true, subtree:false});
})();
</script>
