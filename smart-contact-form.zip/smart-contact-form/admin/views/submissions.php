<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<style>
#wpcontent,#wpbody-content{padding:0!important;float:none!important;width:100%!important;}
#wpbody-content>.wrap{margin:0!important;padding:0!important;max-width:none!important;}
#wpbody-content>.notice,#wpbody-content>.updated,#wpbody-content>.update-nag,#wpbody-content>.error{display:none!important;}
#wpbody{padding-top:0!important;}
</style>
<div class="scf-wrap">



    <!-- SUBMISSIONS BODY -->
    <div class="scf-sub-body">

        <?php if ( empty( $submissions ) ) : ?>
        <div class="scf-empty">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            <p><?php esc_html_e( 'No submissions yet. Add the shortcode [smart_contact_form] to a page.', 'smart-contact-form-builder' ); ?></p>
        </div>

        <?php else : ?>
        <table class="scf-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php esc_html_e( 'Submission Data', 'smart-contact-form-builder' ); ?></th>
                    <th><?php esc_html_e( 'IP', 'smart-contact-form-builder' ); ?></th>
                    <th><?php esc_html_e( 'Date', 'smart-contact-form-builder' ); ?></th>
                    <th><?php esc_html_e( 'Actions', 'smart-contact-form-builder' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $submissions as $sub ) :
                    $data    = json_decode( $sub['form_data'], true );
                    $preview = '';
                    if ( is_array( $data ) ) {
                        $parts = array();
                        foreach ( $data as $k => $v ) {
                            if ( $v === '' || $v === null ) continue;
                            $parts[] = '<strong>' . esc_html( ucfirst( $k ) ) . ':</strong> ' . esc_html( $v );
                        }
                        $preview = implode( ' &bull; ', $parts );
                    }
                ?>
                <tr>
                    <td class="scf-id-col">#<?php echo (int) $sub['id']; ?></td>
                    <td class="scf-preview-col"><?php echo wp_kses( $preview, array( 'strong' => array() ) ); ?></td>
                    <td><?php echo esc_html( $sub['ip_address'] ); ?></td>
                    <td><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $sub['created_at'] ) ) ); ?></td>
                    <td>
                        <button class="scf-btn scf-btn-danger scf-btn-sm scf-delete-sub" data-id="<?php echo (int) $sub['id']; ?>">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>
                            <?php esc_html_e( 'Delete', 'smart-contact-form-builder' ); ?>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php
        $pages = ceil( $total / $per_page );
        if ( $pages > 1 ) :
        ?>
        <div class="scf-pagination">
            <?php for ( $p = 1; $p <= $pages; $p++ ) : ?>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=scf-submissions&paged=' . $p ) ); ?>"
               class="scf-btn <?php echo $p === $page ? 'scf-btn-primary' : 'scf-btn-secondary'; ?>">
                <?php echo (int) $p; ?>
            </a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>

    </div><!-- /scf-sub-body -->


    <!-- SLIM TOPBAR -->
    <div class="scf-topbar">
        <div class="scf-topbar-left">
            <div class="scf-logo-icon">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
            </div>
            <span class="scf-topbar-title"><?php esc_html_e( 'Submissions', 'smart-contact-form-builder' ); ?></span>
            <span class="scf-sub-count-pill"><?php echo (int) $total; ?> <?php esc_html_e( 'total', 'smart-contact-form-builder' ); ?></span>
        </div>
        <div class="scf-topbar-right">
            <a href="<?php echo $form_id ? esc_url(admin_url('admin.php?page=scf-builder&form_id='.$form_id)) : esc_url(admin_url('admin.php?page=smart-contact-form')); ?>" class="scf-btn scf-btn-ghost">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
                <?php esc_html_e( 'Back to Builder', 'smart-contact-form-builder' ); ?>
            </a>
        </div>
    </div>
</div><!-- /scf-wrap -->

<script>
(function(){
    // Fix fullscreen position — runs immediately before paint
    function fixPos(){
        var bar  = document.getElementById('wpadminbar');
        var menu = document.getElementById('adminmenuwrap');
        var el   = document.querySelector('.scf-wrap');
        if (!el) return;
        el.style.setProperty('top',  (bar  ? bar.getBoundingClientRect().height : 32) + 'px', 'important');
        el.style.setProperty('left', (menu ? menu.getBoundingClientRect().width  : 0)  + 'px', 'important');
    }
    fixPos();
    requestAnimationFrame(fixPos);
    setTimeout(fixPos, 300);
    window.addEventListener('resize', fixPos);
    var menuEl = document.getElementById('adminmenuwrap');
    if (window.MutationObserver && menuEl) {
        new MutationObserver(fixPos).observe(menuEl, {attributes: true});
    }
})();
// Delete handled by admin.js global handler
</script>
