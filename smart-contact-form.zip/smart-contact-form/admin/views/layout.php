<?php if ( ! defined( 'ABSPATH' ) ) exit;
// Variables: $all_forms, $form_id, $settings (from page_layout())
$bg_type = $settings['bg_type'] ?? 'color';
$dirs    = array('to right'=>'→ Right','to bottom'=>'↓ Down','to bottom right'=>'↘ Diagonal','135deg'=>'↙ Diagonal (inv)','to top'=>'↑ Up');
$pos_opt = array('center center'=>'Center','top center'=>'Top','bottom center'=>'Bottom','left center'=>'Left','right center'=>'Right');
$sz_opt  = array('cover'=>'Cover','contain'=>'Contain','auto'=>'Original');
$cur_dir = $settings['bg_gradient_dir'] ?? 'to bottom right';
$cur_pos = $settings['bg_image_pos']    ?? 'center center';
$cur_sz  = $settings['bg_image_size']   ?? 'cover';
$save_nonce    = wp_create_nonce('scf_layout_save');
$preview_nonce = wp_create_nonce('scf_layout_preview');
$preview_base  = admin_url('admin-ajax.php') . '?action=scf_layout_preview&nonce=' . $preview_nonce . '&form_id=' . $form_id;
?>
<style>
/* ── Layout Page ── */
.scf-lp-wrap{display:flex;flex-direction:column;position:fixed;top:32px;left:160px;right:0;bottom:0;background:#f1f5f9;z-index:1;}
@media(max-width:782px){.scf-lp-wrap{left:0;top:46px;}}
.scf-lp-topbar{display:flex;align-items:center;gap:10px;padding:0 18px;height:50px;background:#1e3a5f;flex-shrink:0;box-shadow:0 2px 8px rgba(0,0,0,.2);}
.scf-lp-title{color:#fff;font-size:13px;font-weight:800;letter-spacing:.3px;display:flex;align-items:center;gap:7px;margin-right:auto;}
.scf-lp-sep{color:rgba(255,255,255,.25);font-size:16px;margin:0 2px;}
.scf-lp-select{padding:6px 10px;border-radius:7px;border:1.5px solid rgba(255,255,255,.2);background:rgba(255,255,255,.1);color:#fff;font-size:12px;font-weight:600;min-width:160px;cursor:pointer;outline:none;}
.scf-lp-select option{background:#1e3a5f;color:#fff;}
.scf-lp-btn{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;border:none;white-space:nowrap;transition:all .15s;}
.scf-lp-btn-save{background:#2563eb;color:#fff;}
.scf-lp-btn-save:hover{background:#1d4ed8;}
.scf-lp-btn-save:disabled{opacity:.6;cursor:default;}
.scf-lp-btn-restore{background:rgba(255,255,255,.1);color:#fff;border:1.5px solid rgba(255,255,255,.18);}
.scf-lp-btn-restore:hover{background:rgba(255,255,255,.18);}
.scf-lp-notice{font-size:11px;font-weight:700;padding:4px 12px;border-radius:6px;display:none;}
.scf-lp-notice.ok{background:#dcfce7;color:#15803d;}
.scf-lp-notice.err{background:#fee2e2;color:#b91c1c;}
/* ── body ── */
.scf-lp-body{display:flex;flex:1;overflow:hidden;}
/* ── sidebar ── */
.scf-lp-sidebar{width:270px;flex-shrink:0;background:#fff;border-right:1px solid #e2e8f0;overflow-y:auto;padding:0;}
.scf-lp-section{padding:16px 16px 0;}
.scf-lp-section+.scf-lp-section{border-top:1px solid #f1f5f9;}
.scf-lp-section-hd{font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.8px;color:#94a3b8;margin-bottom:12px;padding-bottom:7px;border-bottom:1px solid #f1f5f9;}
.scf-lp-lbl{font-size:11px;font-weight:700;color:#475569;display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;}
.scf-lp-lbl b{font-size:11px;font-weight:800;color:#1e3a5f;background:#eff6ff;padding:2px 8px;border-radius:5px;}
.scf-lp-slider{-webkit-appearance:none;appearance:none;width:100%;height:3px;background:#e2e8f0;border-radius:3px;outline:none;cursor:pointer;margin-bottom:14px;display:block;}
.scf-lp-slider::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;background:#2563eb;cursor:pointer;box-shadow:0 1px 4px rgba(37,99,235,.35);}
.scf-lp-slider::-moz-range-thumb{width:16px;height:16px;border-radius:50%;background:#2563eb;cursor:pointer;border:none;}
/* BG type */
.scf-lp-type-row{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:14px;}
.scf-lp-type-btn{padding:5px 12px;border:1.5px solid #e2e8f0;border-radius:7px;font-size:11px;font-weight:700;color:#64748b;cursor:pointer;background:#fff;user-select:none;transition:all .15s;}
.scf-lp-type-btn.active{border-color:#2563eb;background:#2563eb;color:#fff;}
/* BG panels */
.scf-lp-panel{display:none;padding-bottom:14px;}
.scf-lp-panel.show{display:block;}
.scf-lp-2col{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;}
.scf-lp-color-lbl{font-size:10px;color:#64748b;text-align:center;margin-top:4px;}
.scf-lp-sel{width:100%;padding:6px 9px;border:1.5px solid #e2e8f0;border-radius:7px;font-size:12px;color:#334155;margin-bottom:10px;outline:none;background:#fff;}
.scf-lp-media-row{display:flex;gap:6px;margin-bottom:8px;}
.scf-lp-media-row input[type=text]{flex:1;padding:6px 10px;border:1.5px solid #e2e8f0;border-radius:7px;font-size:12px;color:#334155;outline:none;}
.scf-lp-upload-btn{padding:6px 11px;background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;color:#475569;white-space:nowrap;}
.scf-lp-upload-btn:hover{background:#f1f5f9;}
.scf-lp-img-preview{width:100%;height:64px;object-fit:cover;border-radius:6px;margin-bottom:8px;display:none;}
.scf-lp-toggle-row{display:flex;align-items:center;justify-content:space-between;font-size:11px;font-weight:600;color:#475569;margin-bottom:12px;}
/* ── preview ── */
.scf-lp-preview-area{flex:1;display:flex;flex-direction:column;overflow:hidden;background:#e2e8f0;}
.scf-lp-preview-bar{display:flex;align-items:center;gap:8px;padding:0 14px;height:38px;background:#fff;border-bottom:1px solid #e2e8f0;flex-shrink:0;}
.scf-lp-preview-label{font-size:10.5px;font-weight:800;text-transform:uppercase;letter-spacing:.6px;color:#94a3b8;display:flex;align-items:center;gap:5px;}
.scf-lp-vp-btns{display:flex;gap:4px;margin-left:auto;}
.scf-lp-vp-btn{padding:3px 10px;border-radius:5px;font-size:11px;font-weight:700;border:1.5px solid #e2e8f0;background:#fff;color:#64748b;cursor:pointer;}
.scf-lp-vp-btn.active{border-color:#2563eb;color:#2563eb;background:#eff6ff;}
.scf-lp-preview-scroll{flex:1;overflow:auto;padding:20px;display:flex;justify-content:center;}
.scf-lp-preview-frame{width:100%;max-width:1200px;transition:max-width .3s;}
.scf-lp-iframe-box{border-radius:10px;overflow:hidden;box-shadow:0 8px 28px rgba(0,0,0,.1);background:#fff;position:relative;}
.scf-lp-spinner{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:11px;color:#94a3b8;font-weight:600;}
#scf-lp-iframe{width:100%;border:none;display:block;min-height:400px;transition:height .2s;}
/* ── restore modal ── */
.scf-lp-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99999;align-items:center;justify-content:center;}
.scf-lp-overlay.open{display:flex;}
.scf-lp-modal{background:#fff;border-radius:14px;padding:26px;max-width:360px;width:90%;box-shadow:0 20px 50px rgba(0,0,0,.2);}
.scf-lp-modal h3{margin:0 0 8px;font-size:15px;color:#1e293b;}
.scf-lp-modal p{color:#64748b;font-size:13px;margin:0 0 20px;line-height:1.5;}
.scf-lp-modal-btns{display:flex;gap:8px;justify-content:flex-end;}
.scf-lp-modal-btns button{padding:7px 16px;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;border:none;}
.btn-cancel-restore{background:#f1f5f9;color:#475569;}
.btn-do-restore{background:#ef4444;color:#fff;}
</style>

<div class="scf-lp-wrap">

    <!-- Top bar -->
    <div class="scf-lp-topbar">
        <div class="scf-lp-title">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
            Layout Editor
        </div>
        <span class="scf-lp-sep">|</span>

        <select class="scf-lp-select" id="scf-lp-form-sel">
            <?php foreach ($all_forms as $f): ?>
            <option value="<?php echo esc_attr($f['id']); ?>" <?php selected($form_id, $f['id']); ?>>
                <?php echo esc_html($f['name']); ?>
            </option>
            <?php endforeach; ?>
        </select>

        <div id="scf-lp-notice" class="scf-lp-notice"></div>

        <button class="scf-lp-btn scf-lp-btn-restore" id="scf-lp-restore-btn">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/></svg>
            Reset
        </button>

        <button class="scf-lp-btn scf-lp-btn-save" id="scf-lp-save-btn">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/></svg>
            Save
        </button>
    </div>

    <!-- Body -->
    <div class="scf-lp-body">

        <!-- Sidebar controls -->
        <div class="scf-lp-sidebar">

            <!-- SIZE -->
            <div class="scf-lp-section" style="padding-top:18px;">
                <div class="scf-lp-section-hd">Size</div>

                <div class="scf-lp-lbl">Form Width <b id="lp-w-val"><?php echo esc_html($settings['form_max_width'] ?? 960); ?>px</b></div>
                <input type="range" class="scf-lp-slider" id="lp-width" min="300" max="1800" step="10" value="<?php echo esc_attr($settings['form_max_width'] ?? 960); ?>">

                <div class="scf-lp-lbl">Min. Height <b id="lp-h-val"><?php echo ($settings['form_min_height'] ?? 0) == 0 ? 'Auto' : esc_html($settings['form_min_height']).'px'; ?></b></div>
                <input type="range" class="scf-lp-slider" id="lp-minheight" min="0" max="900" step="10" value="<?php echo esc_attr($settings['form_min_height'] ?? 0); ?>">

                <div class="scf-lp-lbl">Padding <b id="lp-p-val"><?php echo esc_html($settings['form_padding'] ?? 60); ?>px</b></div>
                <input type="range" class="scf-lp-slider" id="lp-padding" min="0" max="120" step="4" value="<?php echo esc_attr($settings['form_padding'] ?? 60); ?>">
            </div>

            <!-- BACKGROUND -->
            <div class="scf-lp-section" style="padding-top:16px;padding-bottom:6px;">
                <div class="scf-lp-section-hd">Background</div>

                <div class="scf-lp-type-row">
                    <?php foreach (['color'=>'Color','gradient'=>'Gradient','image'=>'Image','none'=>'None'] as $bv=>$bl): ?>
                    <div class="scf-lp-type-btn <?php echo $bg_type===$bv?'active':''; ?>" data-bg="<?php echo esc_attr($bv); ?>"><?php echo esc_html($bl); ?></div>
                    <?php endforeach; ?>
                </div>

                <!-- Color -->
                <div id="lp-panel-color" class="scf-lp-panel <?php echo $bg_type==='color'?'show':''; ?>">
                    <div class="scf-color-item">
                        <input type="text" class="scf-colorpicker" id="lp-bg-color" value="<?php echo esc_attr($settings['bg_color'] ?? '#f8fafc'); ?>">
                    </div>
                </div>

                <!-- Gradient -->
                <div id="lp-panel-gradient" class="scf-lp-panel <?php echo $bg_type==='gradient'?'show':''; ?>">
                    <div class="scf-lp-2col">
                        <div>
                            <input type="text" class="scf-colorpicker" id="lp-grad-from" value="<?php echo esc_attr($settings['bg_gradient_from'] ?? '#1e3a5f'); ?>">
                            <div class="scf-lp-color-lbl">From</div>
                        </div>
                        <div>
                            <input type="text" class="scf-colorpicker" id="lp-grad-to" value="<?php echo esc_attr($settings['bg_gradient_to'] ?? '#2563eb'); ?>">
                            <div class="scf-lp-color-lbl">To</div>
                        </div>
                    </div>
                    <select class="scf-lp-sel" id="lp-grad-dir">
                        <?php foreach ($dirs as $v=>$l): ?>
                        <option value="<?php echo esc_attr($v); ?>" <?php selected($cur_dir,$v); ?>><?php echo esc_html($l); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Image -->
                <div id="lp-panel-image" class="scf-lp-panel <?php echo $bg_type==='image'?'show':''; ?>">
                    <div class="scf-lp-media-row">
                        <input type="text" id="lp-bg-image" placeholder="https://..." value="<?php echo esc_attr($settings['bg_image'] ?? ''); ?>">
                        <button class="scf-lp-upload-btn" id="lp-upload-btn">Upload</button>
                    </div>
                    <img id="lp-img-preview" class="scf-lp-img-preview" src="<?php echo esc_url($settings['bg_image'] ?? ''); ?>" <?php echo !empty($settings['bg_image']) ? 'style="display:block"' : ''; ?>>
                    <select class="scf-lp-sel" id="lp-img-pos">
                        <?php foreach ($pos_opt as $v=>$l): ?>
                        <option value="<?php echo esc_attr($v); ?>" <?php selected($cur_pos,$v); ?>><?php echo esc_html($l); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select class="scf-lp-sel" id="lp-img-size">
                        <?php foreach ($sz_opt as $v=>$l): ?>
                        <option value="<?php echo esc_attr($v); ?>" <?php selected($cur_sz,$v); ?>><?php echo esc_html($l); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="scf-lp-toggle-row">
                        <span>Dark Overlay</span>
                        <label class="scf-toggle">
                            <input type="checkbox" id="lp-overlay" value="1" <?php checked(!empty($settings['bg_overlay'])); ?>>
                            <span class="scf-toggle-track"></span>
                        </label>
                    </div>
                </div>

                <!-- None -->
                <div id="lp-panel-none" class="scf-lp-panel <?php echo $bg_type==='none'?'show':''; ?>">
                    <p style="color:#94a3b8;font-size:12px;margin:0 0 14px;">No background — transparent.</p>
                </div>

            </div><!-- /bg section -->

        </div><!-- /sidebar -->

        <!-- Preview -->
        <div class="scf-lp-preview-area">
            <div class="scf-lp-preview-bar">
                <span class="scf-lp-preview-label">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    Live Preview
                </span>
                <div class="scf-lp-vp-btns">
                    <button class="scf-lp-vp-btn active" data-vp="100%">Desktop</button>
                    <button class="scf-lp-vp-btn" data-vp="768px">Tablet</button>
                    <button class="scf-lp-vp-btn" data-vp="390px">Mobile</button>
                </div>
            </div>
            <div class="scf-lp-preview-scroll">
                <div class="scf-lp-preview-frame" id="lp-frame">
                    <div class="scf-lp-iframe-box">
                        <div class="scf-lp-spinner" id="lp-spinner">Loading…</div>
                        <iframe id="scf-lp-iframe" src="<?php echo esc_url($preview_base); ?>" scrolling="no"></iframe>
                    </div>
                </div>
            </div>
        </div>

    </div><!-- /body -->
</div><!-- /wrap -->

<!-- Restore modal -->
<div class="scf-lp-overlay" id="lp-modal">
    <div class="scf-lp-modal">
        <h3>⚠ Reset Layout?</h3>
        <p>All layout settings will be restored to their default values. This action cannot be undone.</p>
        <div class="scf-lp-modal-btns">
            <button class="btn-cancel-restore" id="lp-modal-cancel">Cancel</button>
            <button class="btn-do-restore" id="lp-modal-confirm">Reset</button>
        </div>
    </div>
</div>

<script>
(function($){
    var AJAX      = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
    var FORM_ID   = <?php echo (int)$form_id; ?>;
    var SAVE_N    = '<?php echo esc_js($save_nonce); ?>';
    var PREV_N    = '<?php echo esc_js($preview_nonce); ?>';
    var DEFAULTS  = <?php echo json_encode([
        'form_max_width'   => 960,
        'form_min_height'  => 0,
        'form_padding'     => 60,
        'bg_type'          => 'color',
        'bg_color'         => '#f8fafc',
        'bg_gradient_from' => '#1e3a5f',
        'bg_gradient_to'   => '#2563eb',
        'bg_gradient_dir'  => 'to bottom right',
        'bg_image'         => '',
        'bg_image_pos'     => 'center center',
        'bg_image_size'    => 'cover',
        'bg_overlay'       => 0,
    ]); ?>;

    /* ── helpers ── */
    function getLayout() {
        return {
            form_max_width:   +$('#lp-width').val(),
            form_min_height:  +$('#lp-minheight').val(),
            form_padding:     +$('#lp-padding').val(),
            bg_type:          $('.scf-lp-type-btn.active').data('bg') || 'color',
            bg_color:         getColor('#lp-bg-color'),
            bg_gradient_from: getColor('#lp-grad-from'),
            bg_gradient_to:   getColor('#lp-grad-to'),
            bg_gradient_dir:  $('#lp-grad-dir').val(),
            bg_image:         $('#lp-bg-image').val() || '',
            bg_image_pos:     $('#lp-img-pos').val(),
            bg_image_size:    $('#lp-img-size').val(),
            bg_overlay:       $('#lp-overlay').is(':checked') ? 1 : 0,
        };
    }
    function getColor(sel) {
        var el = $(sel);
        return (el.wpColorPicker && el.wpColorPicker('color')) || el.val() || '';
    }
    function showNotice(type, msg) {
        $('#scf-lp-notice').attr('class','scf-lp-notice '+type).text(msg).fadeIn(150);
        setTimeout(function(){ $('#scf-lp-notice').fadeOut(400); }, 2800);
    }

    /* ── Preview refresh ── */
    var prevTimer;
    function refreshPreview() {
        clearTimeout(prevTimer);
        prevTimer = setTimeout(doRefresh, 350);
    }
    function doRefresh() {
        $('#lp-spinner').show();
        var layout = getLayout();
        var url    = AJAX + '?action=scf_layout_preview&nonce=' + PREV_N + '&form_id=' + FORM_ID + '&layout=' + encodeURIComponent(JSON.stringify(layout));
        var iframe = document.getElementById('scf-lp-iframe');
        iframe.onload = function(){
            try {
                var h = iframe.contentWindow.document.body.scrollHeight;
                iframe.style.height = Math.max(h + 30, 300) + 'px';
            } catch(e){}
            $('#lp-spinner').hide();
        };
        iframe.src = url;
    }

    /* ── Sliders ── */
    $('#lp-width').on('input', function(){
        $('#lp-w-val').text(this.value + 'px');
        refreshPreview();
    });
    $('#lp-minheight').on('input', function(){
        $('#lp-h-val').text(+this.value === 0 ? 'Auto' : this.value + 'px');
        refreshPreview();
    });
    $('#lp-padding').on('input', function(){
        $('#lp-p-val').text(this.value + 'px');
        refreshPreview();
    });

    /* ── BG type ── */
    $(document).on('click', '.scf-lp-type-btn', function(){
        $('.scf-lp-type-btn').removeClass('active');
        $(this).addClass('active');
        $('.scf-lp-panel').removeClass('show');
        $('#lp-panel-' + $(this).data('bg')).addClass('show');
        refreshPreview();
    });

    /* ── Color pickers ── */
    $(document).on('irischange wpcolorpickerchange change', '.scf-colorpicker', refreshPreview);

    /* ── Selects, toggles ── */
    $('#lp-grad-dir, #lp-img-pos, #lp-img-size').on('change', refreshPreview);
    $('#lp-overlay').on('change', refreshPreview);
    $('#lp-bg-image').on('input', function(){
        var url = $(this).val();
        var img = $('#lp-img-preview');
        url ? img.attr('src', url).show() : img.hide();
        refreshPreview();
    });

    /* ── Upload ── */
    $('#lp-upload-btn').on('click', function(){
        if(typeof wp === 'undefined' || !wp.media){ alert('Media library not available'); return; }
        var frame = wp.media({ title:'Background Image', button:{text:'Select'}, multiple:false });
        frame.on('select', function(){
            var url = frame.state().get('selection').first().toJSON().url;
            $('#lp-bg-image').val(url).trigger('input');
        });
        frame.open();
    });

    /* ── Viewport ── */
    $(document).on('click', '.scf-lp-vp-btn', function(){
        $('.scf-lp-vp-btn').removeClass('active');
        $(this).addClass('active');
        var vp = $(this).data('vp');
        $('#lp-frame').css('max-width', vp === '100%' ? '100%' : vp);
    });

    /* ── Form selector ── */
    $('#scf-lp-form-sel').on('change', function(){
        window.location.href = '<?php echo esc_js(admin_url("admin.php?page=scf-layout&form_id=")); ?>' + $(this).val();
    });

    /* ── Save ── */
    $('#scf-lp-save-btn').on('click', function(){
        var btn = $(this).prop('disabled', true).text('Saving…');
        $.post(AJAX, {
            action:  'scf_layout_save',
            nonce:   SAVE_N,
            form_id: FORM_ID,
            layout:  JSON.stringify(getLayout())
        }, function(res){
            btn.prop('disabled', false).html('<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/></svg> Save');
            showNotice(res.success ? 'ok' : 'err', res.success ? '✓ Saved!' : '✗ ' + (res.data && res.data.message || 'Error'));
        }).fail(function(){ btn.prop('disabled',false).text('Save'); showNotice('err','✗ Network error'); });
    });

    /* ── Restore ── */
    $('#scf-lp-restore-btn').on('click', function(){ $('#lp-modal').addClass('open'); });
    $('#lp-modal-cancel').on('click', function(){ $('#lp-modal').removeClass('open'); });
    $('#lp-modal-confirm').on('click', function(){
        $('#lp-modal').removeClass('open');
        applyLayout(DEFAULTS);
        setTimeout(refreshPreview, 200);
        showNotice('ok', '✓ Reset to defaults');
    });

    function applyLayout(d) {
        $('#lp-width').val(d.form_max_width);    $('#lp-w-val').text(d.form_max_width + 'px');
        $('#lp-minheight').val(d.form_min_height); $('#lp-h-val').text(d.form_min_height === 0 ? 'Auto' : d.form_min_height + 'px');
        $('#lp-padding').val(d.form_padding);    $('#lp-p-val').text(d.form_padding + 'px');
        $('.scf-lp-type-btn').removeClass('active');
        $('.scf-lp-type-btn[data-bg="'+d.bg_type+'"]').addClass('active');
        $('.scf-lp-panel').removeClass('show');
        $('#lp-panel-'+d.bg_type).addClass('show');
        setColor('#lp-bg-color',    d.bg_color);
        setColor('#lp-grad-from',   d.bg_gradient_from);
        setColor('#lp-grad-to',     d.bg_gradient_to);
        $('#lp-grad-dir').val(d.bg_gradient_dir);
        $('#lp-bg-image').val(d.bg_image);
        d.bg_image ? $('#lp-img-preview').attr('src',d.bg_image).show() : $('#lp-img-preview').hide();
        $('#lp-img-pos').val(d.bg_image_pos);
        $('#lp-img-size').val(d.bg_image_size);
        $('#lp-overlay').prop('checked', !!d.bg_overlay);
    }
    function setColor(sel, val) {
        var el = $(sel);
        try { el.wpColorPicker('color', val); } catch(e) { el.val(val); }
    }

    /* ── Init ── */
    $(function(){
        // Init color pickers
        if (typeof $.fn.wpColorPicker !== 'undefined') {
            $('.scf-colorpicker').each(function(){
                $(this).wpColorPicker({ change: function(){ setTimeout(refreshPreview, 100); } });
            });
        }
        // First preview load
        var iframe = document.getElementById('scf-lp-iframe');
        iframe.onload = function(){
            try {
                var h = iframe.contentWindow.document.body.scrollHeight;
                iframe.style.height = Math.max(h + 30, 300) + 'px';
            } catch(e){}
            $('#lp-spinner').hide();
        };
    });
})(jQuery);
</script>
