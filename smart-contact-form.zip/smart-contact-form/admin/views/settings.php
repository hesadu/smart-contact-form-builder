<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<style>
/* SCF: WP Layout Reset */
#wpcontent,#wpbody-content{padding:0!important;float:none!important;width:100%!important;}
#wpbody-content>.wrap{margin:0!important;padding:0!important;max-width:none!important;}
#wpbody-content>.notice,#wpbody-content>.updated,#wpbody-content>.update-nag,#wpbody-content>.error{display:none!important;}
#wpbody{padding-top:0!important;}

/* Tab panes */
.scf-tab-pane{display:none!important;}
.scf-tab-pane.active{display:block!important;}

/* Tabs */
.scf-htabs{display:flex!important;flex-direction:row!important;background:#fff!important;border-bottom:1px solid #e2e8f0!important;flex-shrink:0!important;padding:0!important;overflow-x:auto!important;scrollbar-width:none!important;}
.scf-htabs::-webkit-scrollbar{display:none!important;}
.scf-htab{display:inline-flex!important;align-items:center!important;gap:5px!important;padding:10px 11px!important;border-bottom:2px solid transparent!important;margin-bottom:-1px!important;font-size:10.5px!important;font-weight:700!important;text-transform:uppercase!important;letter-spacing:.5px!important;color:#94a3b8!important;cursor:pointer!important;white-space:nowrap!important;line-height:1!important;user-select:none!important;float:none!important;transition:color .15s,border-color .15s!important;}
.scf-htab:hover{color:#475569!important;}
.scf-htab.active{color:#2563eb!important;border-bottom-color:#2563eb!important;}
.scf-htab svg{flex-shrink:0!important;display:inline-block!important;vertical-align:middle!important;pointer-events:none!important;}
</style>

<div class="scf-wrap" data-form-id="<?php echo (int)($settings['_form_id'] ?? 0); ?>">
<input type="hidden" id="scf-form-id" value="<?php echo (int)($settings['_form_id'] ?? 0); ?>">

    <!-- MAIN LAYOUT (fills all space above bottom bar) -->
    <div class="scf-layout">

        <!-- LEFT SIDEBAR -->
        <div class="scf-sidebar">

            <!-- Tabs -->
            <div class="scf-htabs">
                <div class="scf-htab active" data-tab="design">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93A10 10 0 115 19"/></svg>
                    <?php esc_html_e( 'Design', 'smart-contact-form-builder' ); ?>
                </div>
                <div class="scf-htab" data-tab="info">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <?php esc_html_e( 'Info', 'smart-contact-form-builder' ); ?>
                </div>
                <div class="scf-htab" data-tab="builder">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 12h8M12 8v8"/></svg>
                    <?php esc_html_e( 'Builder', 'smart-contact-form-builder' ); ?>
                </div>
                <div class="scf-htab" data-tab="email">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <?php esc_html_e( 'Email', 'smart-contact-form-builder' ); ?>
                </div>
                <div class="scf-htab" data-tab="layout">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                    <?php esc_html_e( 'Layout', 'smart-contact-form-builder' ); ?>
                </div>
            </div>

            <!-- Tab Content -->
            <div class="scf-sidebar-body">

                <!-- DESIGN TAB -->
                <div class="scf-tab-pane active" id="tab-design">
                    <div class="scf-group-label"><?php esc_html_e( 'Theme Colors', 'smart-contact-form-builder' ); ?></div>
                    <div class="scf-color-grid">
                        <?php
                        $color_fields = array(
                            'primary_color'     => __( 'Primary',    'smart-contact-form-builder' ),
                            'secondary_color'   => __( 'Secondary',  'smart-contact-form-builder' ),
                            'button_color'      => __( 'Button',     'smart-contact-form-builder' ),
                            'button_text_color' => __( 'Btn Text',   'smart-contact-form-builder' ),
                            'bg_color'          => __( 'Background', 'smart-contact-form-builder' ),
                            'text_color'        => __( 'Body Text',  'smart-contact-form-builder' ),
                            'heading_color'     => __( 'Headings',   'smart-contact-form-builder' ),
                        );
                        foreach ( $color_fields as $name => $label ) : ?>
                            <div class="scf-color-item">
                                <input type="text" class="scf-colorpicker" id="<?php echo 'scf-color-' . esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $settings[ $name ] ); ?>">
                                <span class="scf-color-label"><?php echo esc_html( $label ); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="scf-group-label" style="margin-top:18px;"><?php esc_html_e( 'Typography', 'smart-contact-form-builder' ); ?></div>
                    <div class="scf-row-2">
                        <div class="scf-field">
                            <label><?php esc_html_e( 'Font Family', 'smart-contact-form-builder' ); ?></label>
                            <select name="font_family" id="scf-font-family">
                                <?php
                                $fonts = array( 'Inter', 'Roboto', 'Open Sans', 'Lato', 'Poppins', 'Nunito', 'Montserrat', 'Raleway', 'DM Sans', 'Jost', 'Playfair Display', 'Georgia' );
                                foreach ( $fonts as $f ) {
                                    printf( '<option value="%1$s" %2$s>%1$s</option>', esc_attr( $f ), selected( $settings['font_family'], $f, false ) );
                                }
                                ?>
                            </select>
                        </div>
                        <div class="scf-field">
                            <label><?php esc_html_e( 'Font Size (px)', 'smart-contact-form-builder' ); ?></label>
                            <input type="number" id="scf-font-size" name="font_size" value="<?php echo esc_attr( $settings['font_size'] ); ?>" min="12" max="22">
                        </div>
                    </div>

                    <div class="scf-group-label" style="margin-top:18px;"><?php esc_html_e( 'Background Image', 'smart-contact-form-builder' ); ?></div>
                    <div class="scf-field">
                        <div class="scf-media-row">
                            <input type="text" name="bg_image" id="scf-bg-image" value="<?php echo esc_attr( $settings['bg_image'] ); ?>" placeholder="https://...">
                            <button type="button" class="scf-btn scf-btn-secondary scf-btn-sm" id="scf-media-btn"><?php esc_html_e( 'Upload', 'smart-contact-form-builder' ); ?></button>
                        </div>
                    </div>
                </div>

                <!-- INFO TAB -->
                <div class="scf-tab-pane" id="tab-info">
                    <div class="scf-toggle-row" style="margin-bottom:14px;">
                        <span style="font-weight:600;font-size:13px;"><?php esc_html_e( 'Show Contact Info Panel', 'smart-contact-form-builder' ); ?></span>
                        <label class="scf-toggle">
                            <input type="checkbox" name="show_info_panel" value="1" id="scf-info-toggle" <?php checked( !empty($settings['show_info_panel']) || !isset($settings['show_info_panel']), true ); ?>>
                            <span class="scf-toggle-track"></span>
                        </label>
                    </div>
                    <div id="scf-info-fields">
                    <div class="scf-group-label"><?php esc_html_e( 'Contact Panel Text', 'smart-contact-form-builder' ); ?></div>
                    <div class="scf-field">
                        <label><?php esc_html_e( 'Heading', 'smart-contact-form-builder' ); ?></label>
                        <input type="text" id="scf-company-name" name="company_name" value="<?php echo esc_attr( $settings['company_name'] ); ?>">
                    </div>
                    <div class="scf-field">
                        <label><?php esc_html_e( 'Tagline', 'smart-contact-form-builder' ); ?></label>
                        <textarea id="scf-company-tagline" name="company_tagline" rows="3"><?php echo esc_textarea( $settings['company_tagline'] ); ?></textarea>
                    </div>
                    <div class="scf-group-label" style="margin-top:14px;"><?php esc_html_e( 'Contact Details', 'smart-contact-form-builder' ); ?></div>
                    <div class="scf-field">
                        <label><?php esc_html_e( 'Address', 'smart-contact-form-builder' ); ?></label>
                        <input type="text" id="scf-address" name="address" value="<?php echo esc_attr( $settings['address'] ); ?>">
                    </div>
                    <div class="scf-row-2">
                        <div class="scf-field">
                            <label><?php esc_html_e( 'Phone', 'smart-contact-form-builder' ); ?></label>
                            <input type="text" id="scf-phone" name="phone" value="<?php echo esc_attr( $settings['phone'] ); ?>">
                        </div>
                        <div class="scf-field">
                            <label><?php esc_html_e( 'Display Email', 'smart-contact-form-builder' ); ?></label>
                            <input type="text" id="scf-email-display" name="email_display" value="<?php echo esc_attr( $settings['email_display'] ); ?>">
                        </div>
                    </div>
                    </div><!-- /scf-info-fields -->
                </div>

                <!-- BUILDER TAB -->
                <div class="scf-tab-pane" id="tab-builder">
                    <div class="scf-group-label" style="display:flex;align-items:center;justify-content:space-between;">
                        <span><?php esc_html_e( 'Form Fields', 'smart-contact-form-builder' ); ?></span>
                        <span class="scf-drag-hint"><?php esc_html_e( '⠿ drag to reorder', 'smart-contact-form-builder' ); ?></span>
                    </div>

                    <!-- Field list (rendered by PHP on load, updated by JS) -->
                    <div id="scf-fields-list">
                        <?php
                        foreach ( $settings['fields'] as $idx => $field ) {
                            scf_render_field_row( $field, $idx );
                        }
                        ?>
                    </div>

                    <!-- Add field buttons -->
                    <div class="scf-add-field-btns">
                        <span class="scf-add-label"><?php esc_html_e( 'Add:', 'smart-contact-form-builder' ); ?></span>
                        <?php
                        $add_types = array(
                            'text'     => 'Text',
                            'email'    => 'Email',
                            'phone'    => 'Phone',
                            'select'   => 'Select',
                            'textarea' => 'Textarea',
                            'checkbox' => 'Checkbox',
                            'heading'  => 'Heading',
                        );
                        foreach ( $add_types as $t => $l ) {
                            printf( '<button type="button" class="scf-add-field-btn" data-type="%s">+ %s</button>', esc_attr( $t ), esc_html( $l ) );
                        }
                        ?>
                    </div>
                </div>

                <!-- EMAIL TAB -->
                <div class="scf-tab-pane" id="tab-email">
                    <div class="scf-group-label">Form Display</div>
                    <div class="scf-field">
                        <label>Form Title</label>
                        <input type="text" id="scf-form-title" name="form_title" value="<?php echo esc_attr( $settings['form_title'] ?? 'Schreiben Sie uns' ); ?>">
                    </div>
                    <div class="scf-field">
                        <label>Button Text</label>
                        <input type="text" id="scf-button-text" name="button_text" value="<?php echo esc_attr( $settings['button_text'] ?? 'JETZT KONTAKTIEREN' ); ?>">
                    </div>
                    <div class="scf-group-label" style="margin-top:14px;">Email Notifications</div>
                    <div class="scf-toggle-row">
                        <span><?php esc_html_e( 'Send email on submission', 'smart-contact-form-builder' ); ?></span>
                        <label class="scf-toggle"><input type="checkbox" id="scf-send-email" name="send_email" value="1" <?php checked( $settings['send_email'], 1 ); ?>><span class="scf-toggle-track"></span></label>
                    </div>
                    <div class="scf-field">
                        <label><?php esc_html_e( 'Recipient Email', 'smart-contact-form-builder' ); ?></label>
                        <input type="email" id="scf-admin-email" name="admin_email" value="<?php echo esc_attr( $settings['admin_email'] ); ?>">
                        <button type="button" id="scf-test-email-btn" style="margin-top:6px;padding:5px 12px;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">
                            ✉ <?php esc_html_e('Send Test Email','smart-contact-form-builder'); ?>
                        </button>
                        <span id="scf-test-email-result" style="display:none;margin-top:6px;font-size:12px;padding:6px 10px;border-radius:6px;"></span>
                    </div>
                    <div class="scf-field">
                        <label><?php esc_html_e( 'Email Subject', 'smart-contact-form-builder' ); ?></label>
                        <input type="text" id="scf-email-subject" name="email_subject" value="<?php echo esc_attr( $settings['email_subject'] ); ?>">
                    </div>
                    <div class="scf-group-label" style="margin-top:14px;"><?php esc_html_e( 'Submissions', 'smart-contact-form-builder' ); ?></div>
                    <div class="scf-toggle-row">
                        <span><?php esc_html_e( 'Save to database', 'smart-contact-form-builder' ); ?></span>
                        <label class="scf-toggle"><input type="checkbox" id="scf-save-submissions" name="save_submissions" value="1" <?php checked( $settings['save_submissions'], 1 ); ?>><span class="scf-toggle-track"></span></label>
                    </div>
                    <div class="scf-group-label" style="margin-top:14px;"><?php esc_html_e( 'Success Message', 'smart-contact-form-builder' ); ?></div>
                    <div class="scf-field">
                        <textarea id="scf-success-message" name="success_message" rows="3"><?php echo esc_textarea( $settings['success_message'] ); ?></textarea>
                    </div>

                    <!-- ── SECURITY & SPAM PROTECTION SECTION ── -->
                    <div class="scf-group-label" style="margin-top:18px;">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="vertical-align:middle;margin-right:4px;"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>
                        <?php esc_html_e( 'Security & Spam Protection', 'smart-contact-form-builder' ); ?>
                    </div>

                    <!-- Status banner -->
                    <div class="scf-spam-status">
                        <div class="scf-spam-status-dot <?php echo (!empty($settings['rate_limit_enabled']) || !empty($settings['recaptcha_enabled'])) ? 'active' : 'inactive'; ?>"></div>
                        <span><?php echo (!empty($settings['rate_limit_enabled']) || !empty($settings['recaptcha_enabled'])) ? esc_html__('Protection Active', 'smart-contact-form-builder') : esc_html__('No Protection Enabled', 'smart-contact-form-builder'); ?></span>
                    </div>

                    <!-- Rate Limiting -->
                    <div class="scf-spam-card">
                        <div class="scf-spam-card-head">
                            <div>
                                <strong><?php esc_html_e( 'Rate Limiting', 'smart-contact-form-builder' ); ?></strong>
                                <span class="scf-spam-badge scf-badge-green"><?php esc_html_e( 'No API Key', 'smart-contact-form-builder' ); ?></span>
                            </div>
                            <label class="scf-toggle">
                                <input type="checkbox" name="rate_limit_enabled" value="1" id="scf-rl-enabled" <?php checked( !empty($settings['rate_limit_enabled']), true ); ?>>
                                <span class="scf-toggle-track"></span>
                            </label>
                        </div>
                        <p class="scf-spam-desc"><?php esc_html_e( 'Block repeated submissions from the same IP address within a time window.', 'smart-contact-form-builder' ); ?></p>
                        <div class="scf-spam-fields" id="scf-rl-fields">
                            <div class="scf-row-2">
                                <div class="scf-field">
                                    <label><?php esc_html_e( 'Max Attempts', 'smart-contact-form-builder' ); ?></label>
                                    <input type="number" id="scf-rate-limit-attempts" name="rate_limit_attempts" value="<?php echo esc_attr( $settings['rate_limit_attempts'] ); ?>" min="1" max="20">
                                </div>
                                <div class="scf-field">
                                    <label><?php esc_html_e( 'Window (seconds)', 'smart-contact-form-builder' ); ?></label>
                                    <input type="number" id="scf-rate-limit-window" name="rate_limit_window" value="<?php echo esc_attr( $settings['rate_limit_window'] ); ?>" min="60" max="86400">
                                </div>
                            </div>
                            <p class="scf-spam-hint">
                                <?php printf(
                                    esc_html__( 'e.g. %d attempts within %d min = blocked for the remainder.', 'smart-contact-form-builder' ),
                                    (int) $settings['rate_limit_attempts'],
                                    (int) round( $settings['rate_limit_window'] / 60 )
                                ); ?>
                            </p>
                        </div>
                    </div>

                    <!-- reCAPTCHA v3 -->
                    <div class="scf-spam-card" style="margin-top:10px;">
                        <div class="scf-spam-card-head">
                            <div>
                                <strong><?php esc_html_e( 'Google reCAPTCHA v3', 'smart-contact-form-builder' ); ?></strong>
                                <span class="scf-spam-badge scf-badge-blue"><?php esc_html_e( 'Invisible', 'smart-contact-form-builder' ); ?></span>
                            </div>
                            <label class="scf-toggle">
                                <input type="checkbox" name="recaptcha_enabled" value="1" id="scf-rc-enabled" <?php checked( !empty($settings['recaptcha_enabled']), true ); ?>>
                                <span class="scf-toggle-track"></span>
                            </label>
                        </div>
                        <p class="scf-spam-desc">
                            <?php esc_html_e( 'Invisible bot detection by Google. Get free API keys at', 'smart-contact-form-builder' ); ?>
                            <a href="https://www.google.com/recaptcha/admin/create" target="_blank" rel="noopener">google.com/recaptcha</a>.
                        </p>
                        <div class="scf-spam-fields" id="scf-rc-fields">
                            <div class="scf-field">
                                <label><?php esc_html_e( 'Site Key (public)', 'smart-contact-form-builder' ); ?></label>
                                <input type="text" id="scf-recaptcha-site-key" name="recaptcha_site_key" value="<?php echo esc_attr( $settings['recaptcha_site_key'] ); ?>" placeholder="6Lcxxxxxx...">
                            </div>
                            <div class="scf-field">
                                <label><?php esc_html_e( 'Secret Key (private)', 'smart-contact-form-builder' ); ?></label>
                                <input type="password" id="scf-recaptcha-secret-key" name="recaptcha_secret_key" value="<?php echo esc_attr( $settings['recaptcha_secret_key'] ); ?>" placeholder="6Lcxxxxxx...">
                            </div>
                            <div class="scf-field">
                                <label>
                                    <?php esc_html_e( 'Minimum Score', 'smart-contact-form-builder' ); ?>
                                    <span class="scf-score-val" id="scf-score-display"><?php echo esc_html( $settings['recaptcha_score'] ); ?></span>
                                </label>
                                <input type="range" name="recaptcha_score" id="scf-rc-score"
                                    value="<?php echo esc_attr( $settings['recaptcha_score'] ); ?>"
                                    min="0.1" max="0.9" step="0.1"
                                    style="width:100%;accent-color:#2563eb;">
                                <div class="scf-score-labels">
                                    <span><?php esc_html_e( '0.1 Lenient', 'smart-contact-form-builder' ); ?></span>
                                    <span style="color:#f59e0b;">0.5 <?php esc_html_e( 'Balanced ✓', 'smart-contact-form-builder' ); ?></span>
                                    <span><?php esc_html_e( '0.9 Strict', 'smart-contact-form-builder' ); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Honeypot -->
                    <div class="scf-spam-card scf-spam-card-info" style="margin-top:10px;margin-bottom:4px;">
                        <div class="scf-spam-card-head">
                            <div>
                                <strong><?php esc_html_e( 'Honeypot', 'smart-contact-form-builder' ); ?></strong>
                                <span class="scf-spam-badge scf-badge-green"><?php esc_html_e( 'Always On', 'smart-contact-form-builder' ); ?></span>
                            </div>
                        </div>
                        <p class="scf-spam-desc" style="margin:0;"><?php esc_html_e( 'A hidden field that catches automated bots. Always active — no configuration needed.', 'smart-contact-form-builder' ); ?></p>
                    </div>

                </div><!-- /tab-email -->




                <!-- LAYOUT TAB -->
                <div class="scf-tab-pane" id="tab-layout">

                    <!-- Form Width -->
                    <div class="scf-group-label">Form Width</div>
                    <div class="scf-field">
                        <div class="scf-slider-row">
                            <input type="range" id="scf-form-width" name="form_max_width"
                                min="300" max="1800" step="10"
                                value="<?php echo esc_attr( $settings['form_max_width'] ?? 960 ); ?>">
                            <span class="scf-slider-val" id="scf-form-width-val"><?php echo esc_attr( $settings['form_max_width'] ?? 960 ); ?>px</span>
                        </div>
                        <div class="scf-slider-hint">Maximum width of the form</div>
                    </div>

                    <!-- Min Height -->
                    <div class="scf-group-label" style="margin-top:18px;">Min. Height</div>
                    <div class="scf-field">
                        <div class="scf-slider-row">
                            <input type="range" id="scf-form-min-height" name="form_min_height"
                                min="0" max="900" step="10"
                                value="<?php echo esc_attr( $settings['form_min_height'] ?? 0 ); ?>">
                            <span class="scf-slider-val" id="scf-form-min-height-val"><?php echo ( ( $settings['form_min_height'] ?? 0 ) == 0 ? 'Auto' : esc_attr( $settings['form_min_height'] ) . 'px' ); ?></span>
                        </div>
                        <div class="scf-slider-hint">0 = automatic height</div>
                    </div>

                    <!-- Padding -->
                    <div class="scf-group-label" style="margin-top:18px;">Padding</div>
                    <div class="scf-field">
                        <div class="scf-slider-row">
                            <input type="range" id="scf-form-padding" name="form_padding"
                                min="0" max="120" step="4"
                                value="<?php echo esc_attr( $settings['form_padding'] ?? 60 ); ?>">
                            <span class="scf-slider-val" id="scf-form-padding-val"><?php echo esc_attr( $settings['form_padding'] ?? 60 ); ?>px</span>
                        </div>
                        <div class="scf-slider-hint">Top/Bottom padding around the form</div>
                    </div>

                    <!-- Background Type -->
                    <div class="scf-group-label" style="margin-top:18px;">Background</div>
                    <div class="scf-field">
                        <label>Background Type</label>
                        <div class="scf-bg-type-row">
                            <?php
                            $bg_type  = $settings['bg_type'] ?? 'color';
                            $bg_types = array(
                                'color'    => 'Color',
                                'gradient' => 'Gradient',
                                'image'    => 'Image',
                                'none'     => 'None',
                            );
                            foreach ( $bg_types as $bval => $blabel ) :
                            ?>
                            <label class="scf-bg-type-btn <?php echo $bg_type === $bval ? 'active' : ''; ?>">
                                <input type="radio" name="bg_type" value="<?php echo esc_attr($bval); ?>" <?php checked($bg_type,$bval); ?> style="display:none;">
                                <?php echo esc_html($blabel); ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- BG Color -->
                    <div class="scf-bg-panel" id="scf-bg-panel-color" <?php echo ($settings['bg_type'] ?? 'color') !== 'color' ? 'style="display:none"' : ''; ?>>
                        <div class="scf-color-grid" style="grid-template-columns:repeat(2,1fr);">
                            <div class="scf-color-item">
                                <input type="text" class="scf-colorpicker" name="bg_color" value="<?php echo esc_attr( $settings['bg_color'] ?? '#f8fafc' ); ?>">
                                <span class="scf-color-label">Background Color</span>
                            </div>
                        </div>
                    </div>

                    <!-- BG Gradient -->
                    <div class="scf-bg-panel" id="scf-bg-panel-gradient" <?php echo ($settings['bg_type'] ?? 'color') !== 'gradient' ? 'style="display:none"' : ''; ?>>
                        <div class="scf-color-grid" style="grid-template-columns:repeat(2,1fr);margin-bottom:10px;">
                            <div class="scf-color-item">
                                <input type="text" class="scf-colorpicker" name="bg_gradient_from" value="<?php echo esc_attr( $settings['bg_gradient_from'] ?? '#1e3a5f' ); ?>">
                                <span class="scf-color-label">From</span>
                            </div>
                            <div class="scf-color-item">
                                <input type="text" class="scf-colorpicker" name="bg_gradient_to" value="<?php echo esc_attr( $settings['bg_gradient_to'] ?? '#2563eb' ); ?>">
                                <span class="scf-color-label">To</span>
                            </div>
                        </div>
                        <div class="scf-field">
                            <label>Gradient Direction</label>
                            <select name="bg_gradient_dir" id="scf-bg-grad-dir">
                                <?php
                                $dirs    = array('to right'=>'→ Horizontal','to bottom'=>'↓ Vertical','to bottom right'=>'↘ Diagonal','135deg'=>'↙ Diagonal (inv)','to top'=>'↑ Upward');
                                $cur_dir = $settings['bg_gradient_dir'] ?? 'to bottom right';
                                foreach ( $dirs as $v => $l ) :
                                ?>
                                <option value="<?php echo esc_attr($v); ?>" <?php selected($cur_dir,$v); ?>><?php echo esc_html($l); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- BG Image -->
                    <div class="scf-bg-panel" id="scf-bg-panel-image" <?php echo ($settings['bg_type'] ?? 'color') !== 'image' ? 'style="display:none"' : ''; ?>>
                        <div class="scf-field">
                            <label>Background Image</label>
                            <div class="scf-media-row">
                                <input type="text" name="bg_image" id="scf-bg-image" value="<?php echo esc_attr( $settings['bg_image'] ?? '' ); ?>" placeholder="https://...">
                                <button type="button" class="scf-btn scf-btn-secondary scf-btn-sm" id="scf-layout-media-btn">Upload</button>
                            </div>
                            <?php if ( ! empty( $settings['bg_image'] ) ) : ?>
                            <div style="margin-top:8px;border-radius:6px;overflow:hidden;max-height:80px;">
                                <img src="<?php echo esc_url( $settings['bg_image'] ); ?>" style="width:100%;height:80px;object-fit:cover;">
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="scf-row-2">
                            <div class="scf-field">
                                <label>Position</label>
                                <select name="bg_image_pos">
                                    <?php
                                    $positions = array('center center'=>'Center','top center'=>'Top','bottom center'=>'Bottom','left center'=>'Left','right center'=>'Right');
                                    $cur_pos   = $settings['bg_image_pos'] ?? 'center center';
                                    foreach ( $positions as $v => $l ) :
                                    ?>
                                    <option value="<?php echo esc_attr($v); ?>" <?php selected($cur_pos,$v); ?>><?php echo esc_html($l); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="scf-field">
                                <label>Size</label>
                                <select name="bg_image_size">
                                    <?php
                                    $sizes    = array('cover'=>'Cover','contain'=>'Contain','auto'=>'Original');
                                    $cur_size = $settings['bg_image_size'] ?? 'cover';
                                    foreach ( $sizes as $v => $l ) :
                                    ?>
                                    <option value="<?php echo esc_attr($v); ?>" <?php selected($cur_size,$v); ?>><?php echo esc_html($l); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="scf-toggle-row">
                            <span>Dark Overlay</span>
                            <label class="scf-toggle">
                                <input type="checkbox" name="bg_overlay" value="1" id="scf-bg-overlay" <?php checked( !empty($settings['bg_overlay']), true ); ?>>
                                <span class="scf-toggle-track"></span>
                            </label>
                        </div>
                    </div>

                </div><!-- /tab-layout -->

            </div><!-- /scf-sidebar-body -->

            <div id="scf-notice" class="scf-notice" style="display:none"></div>
            <div class="scf-plugin-credit">
                <span class="scf-credit-icon">⚡</span>
                <span><?php esc_html_e( 'Built by', 'smart-contact-form-builder' ); ?> <strong>Hesadu Creatives</strong></span>
                <span class="scf-credit-sep">·</span>
                <span class="scf-credit-version">v<?php echo esc_html( SCF_VERSION ); ?></span>
            </div>
        </div><!-- /scf-sidebar -->

        <!-- RIGHT: Live Preview -->
        <div class="scf-preview-panel">
            <div class="scf-preview-topbar">
                <span class="scf-preview-label">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    <?php esc_html_e( 'Live Preview', 'smart-contact-form-builder' ); ?>
                </span>
                <div class="scf-device-btns">
                    <button class="scf-device active" data-device="desktop">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                    </button>
                    <button class="scf-device" data-device="tablet">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"/><circle cx="12" cy="18" r="1"/></svg>
                    </button>
                    <button class="scf-device" data-device="mobile">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/></svg>
                    </button>
                </div>
            </div>
            <div class="scf-preview-scroll">
                <div class="scf-preview-stage desktop" id="scf-preview-stage">
                    <div id="scf-preview-inner"></div>
                </div>
            </div>
        </div>

    </div><!-- /scf-layout -->

    <!-- BOTTOM BAR -->
    <div class="scf-topbar">
        <div class="scf-topbar-left">
            <a href="<?php echo esc_url( admin_url('admin.php?page=smart-contact-form') ); ?>" class="scf-back-btn" title="All Forms">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
            </a>
            <div class="scf-logo-icon">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="white"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
            </div>
            <span class="scf-topbar-title"><?php echo esc_html( $settings['_form_name'] ?? 'Form Builder' ); ?></span>
        </div>
        <div class="scf-topbar-right" style="display:flex!important;align-items:center!important;gap:6px!important;margin-left:auto!important;flex-shrink:0!important;padding-right:6px!important;">
            <button class="scf-shortcode-copy" id="scf-copy-shortcode" data-shortcode="<?php echo esc_attr('[smart_contact_form id='.($settings['_form_id'] ?? 1).']'); ?>" title="Copy shortcode" style="display:inline-flex!important;align-items:center!important;gap:5px!important;padding:6px 10px!important;background:rgba(255,255,255,.1)!important;color:rgba(255,255,255,.75)!important;border:1px solid rgba(255,255,255,.2)!important;border-radius:6px!important;font-size:11px!important;cursor:pointer!important;white-space:nowrap!important;flex-shrink:0!important;font-family:monospace!important;">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                [smart_contact_form id=<?php echo (int)($settings['_form_id'] ?? 1); ?>]
            </button>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=scf-submissions&form_id=' . (int)($settings['_form_id'] ?? 1) ) ); ?>" class="scf-btn scf-btn-ghost">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                <?php esc_html_e( 'Submissions', 'smart-contact-form-builder' ); ?>
            </a>
            <button id="scf-save-btn" class="scf-btn scf-btn-primary" style="display:inline-flex!important;align-items:center!important;gap:5px!important;padding:7px 14px!important;background:#2563eb!important;color:#fff!important;border:none!important;border-radius:7px!important;font-size:12px!important;font-weight:700!important;cursor:pointer!important;white-space:nowrap!important;flex-shrink:0!important;">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13"/><polyline points="7 3 7 8 15 8"/></svg>
                <span id="scf-save-text"><?php esc_html_e( 'Save Settings', 'smart-contact-form-builder' ); ?></span>
            </button>
        </div>
    </div>

</div><!-- /scf-wrap -->

<?php
function scf_render_field_row( $field, $idx ) {
    $type   = esc_attr( $field['type'] );
    $id     = esc_attr( $field['id'] );
    $label  = esc_attr( $field['label'] ?? '' );
    $ph     = esc_attr( $field['placeholder'] ?? '' );
    $req    = ! empty( $field['required'] );
    $half   = ! empty( $field['halfWidth'] );

    $type_colors = array(
        'text'     => '#3b82f6',
        'email'    => '#10b981',
        'phone'    => '#f59e0b',
        'select'   => '#8b5cf6',
        'textarea' => '#06b6d4',
        'checkbox' => '#ec4899',
        'heading'  => '#64748b',
    );
    $color = $type_colors[ $type ] ?? '#64748b';
    ?>
    <div class="scf-field-row" data-id="<?php echo $id; ?>" data-type="<?php echo $type; ?>">
        <div class="scf-field-row-head">
            <span class="scf-drag-handle" title="Drag to reorder">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="5" r="1.5"/><circle cx="15" cy="5" r="1.5"/><circle cx="9" cy="12" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="15" cy="19" r="1.5"/></svg>
            </span>
            <span class="scf-field-badge" style="background:<?php echo esc_attr( $color ); ?>18;color:<?php echo esc_attr( $color ); ?>;border-color:<?php echo esc_attr( $color ); ?>30;">
                <?php echo esc_html( strtoupper( $type ) ); ?>
            </span>
            <span class="scf-field-row-label"><?php echo esc_html( $field['label'] ); ?></span>
            <?php if ( $req )  echo '<span class="scf-badge-req">REQ</span>'; ?>
            <?php if ( $half ) echo '<span class="scf-badge-half">½</span>'; ?>
            <button class="scf-field-edit-btn" title="<?php esc_attr_e( 'Edit', 'smart-contact-form-builder' ); ?>">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="scf-field-remove-btn" title="<?php esc_attr_e( 'Remove', 'smart-contact-form-builder' ); ?>">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
            </button>
        </div>

        <!-- Edit body (hidden by default) -->
        <div class="scf-field-row-body" style="display:none;">

            <?php if ( $type === 'heading' ) : ?>
            <div class="scf-field">
                <label><?php esc_html_e( 'Heading Text', 'smart-contact-form-builder' ); ?></label>
                <input type="text" class="scf-fld-label" autocomplete="off" value="<?php echo $label; ?>">
            </div>
            <div class="scf-field" style="margin-top:8px;">
                <label><?php esc_html_e( 'Style', 'smart-contact-form-builder' ); ?></label>
                <select class="scf-fld-heading-style">
                    <?php
                    $hs = esc_attr( $field['headingStyle'] ?? 'h3' );
                    $hs_opts = array( 'h2' => 'Large (H2)', 'h3' => 'Medium (H3)', 'h4' => 'Small (H4)', 'divider' => 'Divider Line Only' );
                    foreach ( $hs_opts as $v => $l ) {
                        printf( '<option value="%s"%s>%s</option>', $v, selected( $hs, $v, false ), esc_html( $l ) );
                    }
                    ?>
                </select>
            </div>
            <?php else : ?>
            <div class="scf-row-2">
                <div class="scf-field">
                    <label><?php esc_html_e( 'Label', 'smart-contact-form-builder' ); ?></label>
                    <input type="text" class="scf-fld-label" autocomplete="off" value="<?php echo $label; ?>">
                </div>
                <div class="scf-field">
                    <label><?php esc_html_e( 'Placeholder', 'smart-contact-form-builder' ); ?></label>
                    <input type="text" class="scf-fld-placeholder" autocomplete="off" value="<?php echo $ph; ?>">
                </div>
            </div>

            <div class="scf-checks-row">
                <label class="scf-check-label">
                    <input type="checkbox" class="scf-fld-required" autocomplete="off" <?php checked( $req ); ?>>
                    <?php esc_html_e( 'Required', 'smart-contact-form-builder' ); ?>
                </label>
                <label class="scf-check-label">
                    <input type="checkbox" class="scf-fld-half" autocomplete="off" <?php checked( $half ); ?>>
                    <?php esc_html_e( 'Half Width', 'smart-contact-form-builder' ); ?>
                </label>
            </div>
            <?php endif; ?>

            <?php if ( $type === 'select' ) : ?>
            <div class="scf-opts-wrap">
                <div class="scf-opts-header">
                    <span><?php esc_html_e( 'Label', 'smart-contact-form-builder' ); ?></span>
                    <span><?php esc_html_e( 'Redirect URL (Optional)', 'smart-contact-form-builder' ); ?></span>
                    <span></span>
                </div>
                <div class="scf-opts-list">
                    <?php foreach ( $field['options'] ?? array() as $opt ) : ?>
                    <div class="scf-opt-row">
                        <input type="text" class="scf-opt-label" autocomplete="off"    value="<?php echo esc_attr( $opt['label'] ?? '' ); ?>"    placeholder="<?php esc_attr_e( 'Option label', 'smart-contact-form-builder' ); ?>">
                        <input type="text" class="scf-opt-redirect" autocomplete="off" value="<?php echo esc_attr( $opt['redirect'] ?? '' ); ?>" placeholder="https://...">
                        <button class="scf-opt-remove" type="button">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="scf-opt-add-btn">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
                    <?php esc_html_e( 'Add Option', 'smart-contact-form-builder' ); ?>
                </button>
            </div>
            <?php endif; // select ?>

        </div><!-- /body -->
    </div>
    <?php
}
?>

?>

<script>
jQuery(document).ready(function($){
    // Test Email button
    $('#scf-test-email-btn').on('click', function(){
        var $btn = $(this).prop('disabled',true).text('Sending...');
        var $res = $('#scf-test-email-result').show();
        var to   = $('#scf-admin-email').val() || '';
        $.post(scfAdmin.ajaxUrl, {
            action: 'scf_test_email',
            nonce:  scfAdmin.nonce,
            to:     to
        }, function(r){
            $btn.prop('disabled',false).html('✉ Send Test Email');
            if(r.success){
                $res.css({background:'#f0fdf4',color:'#16a34a',border:'1px solid #bbf7d0'}).text('✅ ' + r.data.message);
            } else {
                $res.css({background:'#fff5f5',color:'#dc2626',border:'1px solid #fecaca'}).text('❌ ' + r.data.message);
            }
        }).fail(function(){
            $btn.prop('disabled',false).html('✉ Send Test Email');
            $res.css({background:'#fff5f5',color:'#dc2626',border:'1px solid #fecaca'}).text('❌ Network error');
        });
    });

    // Tab switching
    $(document).on('click', '.scf-htab', function(e){
        e.preventDefault();
        var tab = $(this).data('tab');
        if(!tab) return;
        $('.scf-htab').removeClass('active');
        $(this).addClass('active');
        $('.scf-tab-pane').removeClass('active');
        $('#tab-' + tab).addClass('active');
        if(typeof SCF !== 'undefined' && SCF.renderPreview) SCF.renderPreview();
    });
});
</script>
