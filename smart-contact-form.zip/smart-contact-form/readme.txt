=== Smart Contact Form Builder ===
Contributors: smartplugins
Tags: contact form, form builder, ajax, redirect, selector
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 2.4.8
License: GPL-2.0+

Modern contact form builder with live preview, drag-and-drop fields, per-option redirect URLs, AJAX submission, and DB storage.

== Description ==

* Two-column layout: Contact info left, form right
* Live preview in admin with device toggle
* Drag & drop field reordering
* Field types: Text, Email, Phone, Select, Textarea, Checkbox
* Select fields: each option can have its own redirect URL
* Color picker for all theme colors
* Font family & size control
* Background color or image
* AJAX submit with honeypot spam protection
* Save submissions to database
* Email notification on submission
* Shortcode: [smart_contact_form]

== Installation ==

1. Upload the smart-contact-form folder to /wp-content/plugins/
2. Activate via Plugins menu
3. Go to Contact Form > Settings & Builder
4. Add [smart_contact_form] to any page

== Changelog ==

= 1.0.0 =
* Initial release
