<?php
/**
 * Plugin Name: Smart Contact Form Builder
 * Plugin URI:  https://hesaducreatives.com/smart-contact-form
 * Description: Multi-form contact form builder with live preview, AJAX, reCAPTCHA v3, rate limiting, and database storage.
 * Version:     2.4.8
 * Author:      Hesadu Creatives
 * Author URI:  https://hesaducreatives.com
 * Text Domain: smart-contact-form-builder
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SCF_VERSION',     '2.4.8' );
define( 'SCF_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'SCF_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'SCF_PLUGIN_FILE', __FILE__ );

require_once SCF_PLUGIN_DIR . 'includes/class-scf-database.php';
require_once SCF_PLUGIN_DIR . 'includes/class-scf-mailer.php';
require_once SCF_PLUGIN_DIR . 'includes/class-scf-rate-limiter.php';
require_once SCF_PLUGIN_DIR . 'includes/class-scf-recaptcha.php';
require_once SCF_PLUGIN_DIR . 'includes/class-scf-spam-guard.php';
require_once SCF_PLUGIN_DIR . 'admin/class-scf-admin.php';
require_once SCF_PLUGIN_DIR . 'frontend/class-scf-frontend.php';
require_once SCF_PLUGIN_DIR . 'includes/class-scf-shortcode.php';

// On activation: create tables + migrate
register_activation_hook( SCF_PLUGIN_FILE, array( 'SCF_Database', 'create_tables' ) );

// On every load: run DB upgrade if version changed (handles updates)
add_action( 'plugins_loaded', function() {
    if ( get_option( 'scf_db_version' ) !== SCF_VERSION ) {
        SCF_Database::create_tables();
    }
}, 1 );

add_action( 'plugins_loaded', 'scf_init' );
function scf_init() {
    if ( is_admin() ) new SCF_Admin();
    new SCF_Frontend();
    new SCF_Shortcode();
}
