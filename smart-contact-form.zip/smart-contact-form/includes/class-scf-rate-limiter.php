<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCF_Rate_Limiter {

    public static function check( $max_attempts, $window_seconds ) {
        $ip  = self::get_ip();
        $key = 'scf_rl_' . md5( $ip );

        $attempts = (int) get_transient( $key );

        if ( $attempts >= (int) $max_attempts ) {
            return false; // blocked
        }

        if ( $attempts === 0 ) {
            set_transient( $key, 1, (int) $window_seconds );
        } else {
            // Increment without resetting TTL
            $ttl = (int) ( get_option( '_transient_timeout_' . $key ) - time() );
            set_transient( $key, $attempts + 1, max( 1, $ttl ) );
        }

        return true; // allowed
    }

    private static function get_ip() {
        foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
                return explode( ',', $ip )[0];
            }
        }
        return '0.0.0.0';
    }
}
