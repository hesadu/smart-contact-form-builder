<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCF_Recaptcha {

    public static function verify( $token, $secret_key, $min_score = 0.5 ) {
        if ( empty( $token ) || empty( $secret_key ) ) {
            return false;
        }

        $response = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array(
            'body' => array(
                'secret'   => $secret_key,
                'response' => $token,
                'remoteip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
            ),
            'timeout' => 10,
        ) );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( empty( $body['success'] ) || ! $body['success'] ) {
            return false;
        }

        if ( isset( $body['score'] ) && (float) $body['score'] < (float) $min_score ) {
            return false;
        }

        return true;
    }
}
