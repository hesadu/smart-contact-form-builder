<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SCF Spam Guard
 * Handles: regex validation, disposable email blocking, time-check
 */
class SCF_Spam_Guard {

    /* ── Disposable email domains (common list) ── */
    private static $disposable_domains = array(
        'mailinator.com','yopmail.com','tempmail.com','guerrillamail.com',
        'throwam.com','sharklasers.com','guerrillamailblock.com','grr.la',
        'guerrillamail.info','guerrillamail.biz','guerrillamail.de',
        'guerrillamail.net','guerrillamail.org','spam4.me','trashmail.com',
        'trashmail.me','trashmail.net','trashmail.at','trashmail.io',
        'trashmail.xyz','dispostable.com','mailnull.com','spamgourmet.com',
        'maildrop.cc','spamgourmet.net','spamgourmet.org','discard.email',
        'fakeinbox.com','temp-mail.org','tempinbox.com','getnada.com',
        'mohmal.com','mailnesia.com','spamhereplease.com','20minutemail.com',
        'throwam.com','anonaddy.com','simplelogin.io','spamex.com',
        'binkmail.com','tempr.email','mail-temporaire.fr','wegwerfmail.de',
        'wegwerfmail.net','wegwerfmail.org','emailondeck.com','inboxkitten.com',
        'spamthisplease.com','armyspy.com','cuvox.de','dayrep.com',
        'einrot.com','fleckens.hu','gustr.com','jourrapide.com',
        'rhyta.com','superrito.com','teleworm.us','mailnull.com',
        'meltmail.com','spamgob.com','throwam.com','yep.it',
    );

    /**
     * Validate email:
     *  - proper format regex
     *  - no disposable domain
     *  - blocks obvious fakes (test@test.*, a@a.*, etc.)
     */
    public static function validate_email( $email ) {
        $email = strtolower( trim( $email ) );

        // Basic format
        if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
            return array( 'valid' => false, 'reason' => 'invalid_format' );
        }

        // Strict regex — must have real TLD 2+ chars
        if ( ! preg_match( '/^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/', $email ) ) {
            return array( 'valid' => false, 'reason' => 'invalid_format' );
        }

        $parts  = explode( '@', $email );
        $local  = $parts[0];
        $domain = $parts[1];

        // Block obvious fake local parts
        $fake_locals = array( 'test', 'asdf', 'aaa', 'abc', 'xxx', 'user', 'admin', 'noreply', 'fake', 'spam' );
        if ( in_array( $local, $fake_locals, true ) ) {
            return array( 'valid' => false, 'reason' => 'suspicious_address' );
        }

        // Block same-word domain (test@test.de, info@info.com)
        $domain_base = explode( '.', $domain )[0];
        if ( $local === $domain_base ) {
            return array( 'valid' => false, 'reason' => 'suspicious_address' );
        }

        // Block disposable domains
        if ( in_array( $domain, self::$disposable_domains, true ) ) {
            return array( 'valid' => false, 'reason' => 'disposable_email' );
        }

        return array( 'valid' => true );
    }

    /**
     * Validate phone number
     * Allows: +49 123 456789, (030) 1234567, 0800-123456, etc.
     * Blocks: 000000000, 123456789, 111111111, all same digit
     */
    public static function validate_phone( $phone ) {
        $phone = trim( $phone );
        // Strip formatting
        $digits = preg_replace( '/\D/', '', $phone );

        // Too short or too long
        if ( strlen( $digits ) < 6 || strlen( $digits ) > 15 ) {
            return array( 'valid' => false, 'reason' => 'invalid_length' );
        }

        // All same digit (000000, 111111)
        if ( preg_match( '/^(\d)\1+$/', $digits ) ) {
            return array( 'valid' => false, 'reason' => 'fake_pattern' );
        }

        // Sequential (123456789, 987654321)
        $sequential_asc  = '1234567890';
        $sequential_desc = '9876543210';
        if ( strlen( $digits ) >= 7 && ( ( false !== strpos( $sequential_asc, $digits  ) ) || ( false !== strpos( $sequential_desc, $digits  ) ) ) ) {
            return array( 'valid' => false, 'reason' => 'fake_pattern' );
        }

        // Must match phone pattern
        if ( ! preg_match( '/^[\+]?[\d\s\-\(\)\.]{6,20}$/', $phone ) ) {
            return array( 'valid' => false, 'reason' => 'invalid_format' );
        }

        return array( 'valid' => true );
    }

    /**
     * Validate name
     * Allows: "Max Mustermann", "Anna-Maria", "Jean-Pierre"
     * Blocks: "abc abc", "test test", "aaa bbb", single repeated chars
     */
    public static function validate_name( $name ) {
        $name = trim( $name );

        if ( strlen( $name ) < 2 ) {
            return array( 'valid' => false, 'reason' => 'too_short' );
        }

        // Only letters, spaces, hyphens, apostrophes (international chars ok)
        if ( ! preg_match( '/^[\p{L}\s\'\-\.]+$/u', $name ) ) {
            return array( 'valid' => false, 'reason' => 'invalid_characters' );
        }

        // Block all same character
        if ( preg_match( '/^(.)\1+$/u', str_replace( ' ', '', $name ) ) ) {
            return array( 'valid' => false, 'reason' => 'fake_pattern' );
        }

        // Block keyboard patterns (asdf, qwerty, etc.)
        $fake_names = array( 'test', 'asdf', 'qwerty', 'aaa', 'abc', 'xxx', 'foo', 'bar', 'baz', 'fake' );
        $name_lower = strtolower( preg_replace( '/\s+/', '', $name ) );
        foreach ( $fake_names as $fake ) {
            if ( ( false !== strpos( $name_lower, $fake  ) ) ) {
                return array( 'valid' => false, 'reason' => 'suspicious_name' );
            }
        }

        // Both parts same (abc abc)
        $parts = preg_split( '/\s+/', $name );
        if ( count( $parts ) >= 2 ) {
            $unique = array_unique( array_map( 'strtolower', $parts ) );
            if ( count( $unique ) === 1 ) {
                return array( 'valid' => false, 'reason' => 'fake_pattern' );
            }
        }

        return array( 'valid' => true );
    }

    /**
     * Validate time-on-page (bot check)
     * $seconds_on_page must be >= $min_seconds
     */
    public static function validate_time( $seconds_on_page, $min_seconds = 2 ) {
        $seconds_on_page = (int) $seconds_on_page;
        if ( $seconds_on_page < $min_seconds ) {
            return array( 'valid' => false, 'reason' => 'too_fast' );
        }
        return array( 'valid' => true );
    }

    /**
     * Run all checks against submitted field data.
     * $fields = array of field definitions from settings
     * $post   = $_POST data
     * Returns: array( 'passed' => bool, 'reason' => string )
     */

    /**
     * Validate German postcode (PLZ)
     * Must be exactly 5 digits, not all-same, not sequential (12345, 01234)
     */
    public static function validate_postcode( $value ) {
        $val = trim( $value );

        // Must be exactly 5 digits
        if ( ! preg_match( '/^\d{5}$/', $val ) ) {
            return array( 'valid' => false, 'reason' => 'invalid_format' );
        }

        // All same digit: 00000, 11111 ... 99999
        if ( preg_match( '/^(\d)\1{4}$/', $val ) ) {
            return array( 'valid' => false, 'reason' => 'fake_pattern' );
        }

        // Sequential ascending (01234, 12345, 23456 …)
        $seq_asc  = '0123456789';
        $seq_desc = '9876543210';
        if ( ( false !== strpos( $seq_asc,  $val ) ) ||
             ( false !== strpos( $seq_desc, $val ) ) ) {
            return array( 'valid' => false, 'reason' => 'fake_pattern' );
        }

        // First two digits 00 is invalid in Germany (no PLZ starts with 00)
        if ( substr( $val, 0, 2 ) === '00' ) {
            return array( 'valid' => false, 'reason' => 'invalid_format' );
        }

        return array( 'valid' => true );
    }

    /**
     * Validate street address
     * Blocks: Musterstraße, Teststraße, keyboard patterns (asdf, qwerty, zxcv)
     */
    public static function validate_address( $value ) {
        $val   = trim( $value );
        $lower = strtolower( $val );

        if ( strlen( $val ) < 5 ) {
            return array( 'valid' => false, 'reason' => 'too_short' );
        }

        // Known fake/test prefixes (German + English)
        $fake_prefixes = array(
            'muster', 'test', 'beispiel', 'sample', 'dummy', 'fake',
            'asdf', 'qwert', 'qwerty', 'zxcv', 'abc', 'aaa', 'xxx',
        );
        foreach ( $fake_prefixes as $fp ) {
            if ( ( false !== strpos( $lower, $fp ) ) ) {
                return array( 'valid' => false, 'reason' => 'fake_address' );
            }
        }
        // All same character repeated (aaaa, xxxxxx)
        $stripped = preg_replace( '/[\s\-\.]+/', '', $lower );
        if ( preg_match( '/^(.)\1+$/u', $stripped ) ) {
            return array( 'valid' => false, 'reason' => 'fake_pattern' );
        }

        // Must contain at least one digit (house number) OR be clearly a named place
        // Relax: just block obvious keyboard-mash (no vowels and no digit)
        $has_digit = preg_match( '/\d/', $val );
        $has_vowel = preg_match( '/[aeiouäöüAEIOUÄÖÜ]/u', $val );
        if ( ! $has_digit && ! $has_vowel ) {
            return array( 'valid' => false, 'reason' => 'fake_pattern' );
        }

        return array( 'valid' => true );
    }

    public static function check_submission( array $fields, array $post, array $settings ) {
        // 1. Time check — block only if scf_time_on_page=0 (bot, JS never set it properly)
        // -1 = field missing (old cached page) → allow through
        $time_on_page = isset( $post['scf_time_on_page'] ) ? (int) $post['scf_time_on_page'] : -1;
        if ( $time_on_page === 0 ) {
            return array( 'passed' => false, 'reason' => 'bot_too_fast' );
        }

        // 2. Field-level validation
        foreach ( $fields as $field ) {
            $type  = $field['type'] ?? '';
            $key   = sanitize_key( $field['id'] ?? '' );
            $label = $field['label'] ?? $type;
            $val   = isset( $post[$key] ) ? sanitize_text_field( wp_unslash( $post[$key] ) ) : '';

            if ( empty( $val ) ) continue; // required check handled elsewhere

            if ( $type === 'email' ) {
                $check = self::validate_email( $val );
                if ( ! $check['valid'] ) {
                    return array( 'passed' => false, 'reason' => 'invalid_email', 'field' => $label, 'detail' => $check['reason'] );
                }
            }

            if ( $type === 'phone' ) {
                $check = self::validate_phone( $val );
                if ( ! $check['valid'] ) {
                    return array( 'passed' => false, 'reason' => 'invalid_phone', 'field' => $label, 'detail' => $check['reason'] );
                }
            }

            // Name fields
            if ( $type === 'text' ) {
                $label_lower = strtolower( $label );

                if ( ( false !== strpos( $label_lower, 'name' ) ) || ( false !== strpos( $label_lower, 'naam' ) ) || ( false !== strpos( $label_lower, 'vor' ) ) || ( false !== strpos( $label_lower, 'nach' ) ) ) {
                    $check = self::validate_name( $val );
                    if ( ! $check['valid'] ) {
                        return array( 'passed' => false, 'reason' => 'invalid_name', 'field' => $label, 'detail' => $check['reason'] );
                    }
                }

                // Postcode / PLZ
                if ( ( false !== strpos( $label_lower, 'plz' ) ) ||
                     ( false !== strpos( $label_lower, 'postcode' ) ) ||
                     ( false !== strpos( $label_lower, 'postleitzahl' ) ) ||
                     ( false !== strpos( $label_lower, 'zip' ) ) ) {
                    $check = self::validate_postcode( $val );
                    if ( ! $check['valid'] ) {
                        return array( 'passed' => false, 'reason' => 'invalid_postcode', 'field' => $label, 'detail' => $check['reason'] );
                    }
                }

                // Street address
                if ( ( false !== strpos( $label_lower, 'adresse' ) ) ||
                     ( false !== strpos( $label_lower, 'address' ) ) ||
                     ( false !== strpos( $label_lower, 'straße' ) ) ||
                     ( false !== strpos( $label_lower, 'strasse' ) ) ||
                     ( false !== strpos( $label_lower, 'street' ) ) ) {
                    $check = self::validate_address( $val );
                    if ( ! $check['valid'] ) {
                        return array( 'passed' => false, 'reason' => 'invalid_address', 'field' => $label, 'detail' => $check['reason'] );
                    }
                }
            }
        }

        // 3. Cross-field checks
        $collected = array();
        foreach ( $fields as $field ) {
            $key = sanitize_key( $field['id'] ?? '' );
            $val = isset( $post[$key] ) ? strtolower( trim( sanitize_text_field( wp_unslash( $post[$key] ) ) ) ) : '';
            $lbl = strtolower( $field['label'] ?? '' );
            if ( $val ) $collected[ $lbl ] = $val;
        }

        // 3a. First name == Last name check
        $first = '';
        $last  = '';
        foreach ( $collected as $lbl => $val ) {
            if ( ( false !== strpos( $lbl, 'vorname' ) ) || ( false !== strpos( $lbl, 'first' ) ) || ( false !== strpos( $lbl, 'firstname' ) ) ) $first = $val;
            if ( ( false !== strpos( $lbl, 'nachname' ) ) || ( false !== strpos( $lbl, 'last' ) )  || ( false !== strpos( $lbl, 'lastname' ) ) ) $last  = $val;
        }
        if ( $first && $last && $first === $last ) {
            return array( 'passed' => false, 'reason' => 'same_name' );
        }

        // 3b. Message spam content check
        $message_val = '';
        foreach ( $collected as $lbl => $val ) {
            if ( ( false !== strpos( $lbl, 'message' ) ) || ( false !== strpos( $lbl, 'nachricht' ) ) || ( false !== strpos( $lbl, 'kommentar' ) ) || ( false !== strpos( $lbl, 'comment' ) ) || ( false !== strpos( $lbl, 'text' ) ) ) {
                $message_val = $val;
                break;
            }
        }
        if ( $message_val ) {
            $spam_result = self::analyze_message( $message_val );
            if ( ! $spam_result['passed'] ) {
                return array( 'passed' => false, 'reason' => $spam_result['reason'] );
            }
        }

        return array( 'passed' => true );
    }

    /**
     * Analyze message content for spam patterns
     */
    private static function analyze_message( $text ) {
        $text_lower = strtolower( $text );

        // Financial/loan spam keywords — weighted scoring
        $spam_keywords = array(
            // High weight (3pts each)
            'loan department'      => 3, 'working capital'     => 3, 'financial broker'   => 3,
            'funding solution'     => 3, 'financing for'       => 3, 'loan officer'       => 3,
            'business loan'        => 3, 'credit facility'     => 3, 'investment fund'    => 3,
            'hedge fund'           => 3, 'private equity'      => 3, 'financial authority'=> 3,
            'broker authority'     => 3, 'loan department'     => 3, 'finance department' => 3,
            'we are pleased to'    => 3, 'we are delighted to' => 3,
            'support your business growth' => 3,
            'application process'  => 3, 'funding for'         => 3,
            // Medium weight (2pts each)
            'renewable energy'     => 2, 'oil & gas'           => 2, 'oil and gas'        => 2,
            'infrastructure'       => 2, 'competitive rates'   => 2, 'fast application'   => 2,
            'kindly respond'       => 2, 'at your earliest'    => 2, 'proceed with next steps' => 2,
            'pleased to offer'     => 2, 'pleased to inform'   => 2,
            'expansion project'    => 2, 'start-up'            => 2, 'startup'            => 2,
            'seo service'          => 2, 'digital marketing'   => 2, 'web design'         => 2,
            'crypto'               => 2, 'bitcoin'             => 2, 'investment opportunit' => 2,
            'agriculture'          => 2, 'telecommunications'  => 2, 'real estate financ' => 2,
            'healthcare financ'    => 2, 'next steps'          => 2, 'earliest convenience' => 2,
            'call/w'               => 2, 'call / w'            => 2, 'whatsapp'           => 2,
            // Low weight (1pt each)
            'linkedin'             => 1, 'kind regards'        => 1, 'best regards'       => 1,
            'financial district'   => 1, 'sultanate'           => 1, 'muscat'             => 1,
            'riyadh'               => 1, 'dubai'               => 1, 'abu dhabi'          => 1,
            'saudi arabia'         => 1, 'oman'                => 1, 'dohat'              => 1,
            'al-khuwair'           => 1, 'king abdullah'       => 1,
        );

        $score = 0;
        foreach ( $spam_keywords as $kw => $pts ) {
            if ( ( false !== strpos( $text_lower, $kw  ) ) ) {
                $score += $pts;
            }
        }

        // Count URLs in message
        $url_count = preg_match_all( '/https?:\/\/|www\./i', $text );
        $score += $url_count * 2;

        // Count phone-like patterns
        $phone_count = preg_match_all( '/\+\d[\d\s\-\(\)]{7,}/', $text );
        $score += $phone_count * 2;

        // Count email addresses in message body
        $email_count = preg_match_all( '/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/', $text );
        if ( $email_count > 0 ) $score += 3; // Any email in body is suspicious

        // Multiple address lines (contains "Street", "Building", "Level", "Floor" etc.)
        $address_markers = array( 'street', 'building', 'level ', 'floor ', 'avenue', 'boulevard', 'district' );
        $addr_count = 0;
        foreach ( $address_markers as $marker ) {
            if ( ( false !== strpos( $text_lower, $marker  ) ) ) $addr_count++;
        }
        if ( $addr_count >= 2 ) $score += 4;

        // Spam threshold
        if ( $score >= 5 ) {
            error_log( '[SCF SpamGuard] Message blocked. Score=' . $score . ' text_preview=' . substr( $text, 0, 80 ) );
            return array( 'passed' => false, 'reason' => 'spam_message' );
        }

        return array( 'passed' => true );
    }
}
