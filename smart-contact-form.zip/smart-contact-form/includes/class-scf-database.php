<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCF_Database {

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $forms_table = $wpdb->prefix . 'scf_forms';
        $sub_table   = $wpdb->prefix . 'scf_submissions';

        dbDelta( "CREATE TABLE IF NOT EXISTS {$forms_table} (
            id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name       VARCHAR(255)        NOT NULL DEFAULT 'Untitled Form',
            settings   LONGTEXT            NOT NULL,
            created_at DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) {$charset};" );

        dbDelta( "CREATE TABLE IF NOT EXISTS {$sub_table} (
            id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id    BIGINT(20) UNSIGNED NOT NULL DEFAULT 1,
            form_data  LONGTEXT            NOT NULL,
            ip_address VARCHAR(45)         DEFAULT NULL,
            user_agent TEXT                DEFAULT NULL,
            status     VARCHAR(20)         NOT NULL DEFAULT 'new',
            created_at DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY form_id (form_id)
        ) {$charset};" );

        self::maybe_migrate_legacy();
        update_option( 'scf_db_version', SCF_VERSION );
    }

    /**
     * One-time migration: scf_settings option → first row in scf_forms.
     * Only runs if: table is empty AND old option exists AND not migrated yet.
     */
    private static function maybe_migrate_legacy() {
        global $wpdb;

        // Already migrated flag
        if ( get_option( 'scf_migrated_v2' ) ) return;

        $forms_table = $wpdb->prefix . 'scf_forms';
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$forms_table}`" ); // phpcs:ignore
        if ( $count > 0 ) {
            update_option( 'scf_migrated_v2', 1 );
            return;
        }

        $old = get_option( 'scf_settings', null );
        if ( ! $old ) {
            // Fresh install — no migration needed
            return;
        }

        // Migrate old settings as first form
        $settings = wp_parse_args( $old, SCF_Admin::get_default_settings() );
        // Remove internal keys that shouldn't be stored
        unset( $settings['_form_id'], $settings['_form_name'] );
        $name = ! empty( $settings['form_title'] ) ? $settings['form_title'] : 'My Contact Form';

        $wpdb->insert( $forms_table, array( // phpcs:ignore
            'name'     => sanitize_text_field( $name ),
            'settings' => wp_json_encode( $settings ),
        ), array( '%s', '%s' ) );

        if ( $wpdb->insert_id ) {
            update_option( 'scf_migrated_v2', 1 );
        }
    }

    /* ── Forms CRUD ────────────────────────────────────────────────── */

    public static function get_all_forms() {
        global $wpdb;
        $t = $wpdb->prefix . 'scf_forms';
        return $wpdb->get_results( "SELECT id, name, created_at, updated_at FROM `{$t}` ORDER BY id ASC", ARRAY_A ); // phpcs:ignore
    }

    public static function get_form( $id ) {
        global $wpdb;
        $t   = $wpdb->prefix . 'scf_forms';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$t}` WHERE id = %d LIMIT 1", (int) $id ), ARRAY_A );
        if ( ! $row ) return null;

        $settings = json_decode( $row['settings'], true );
        if ( ! is_array( $settings ) ) $settings = array();
        $settings = wp_parse_args( $settings, SCF_Admin::get_default_settings() );
        $settings['_form_id']   = (int) $row['id'];
        $settings['_form_name'] = $row['name'];
        return $settings;
    }

    /**
     * Create a new form. Returns new form ID.
     * Uses a DB-level unique token to prevent duplicate rows.
     */
    public static function create_form( $name = 'New Form' ) {
        global $wpdb;

        $name     = sanitize_text_field( $name );
        $defaults = SCF_Admin::get_default_settings();
        $defaults['form_title'] = $name;
        unset( $defaults['_form_id'], $defaults['_form_name'] );

        $wpdb->insert( // phpcs:ignore
            $wpdb->prefix . 'scf_forms',
            array(
                'name'     => $name,
                'settings' => wp_json_encode( $defaults ),
            ),
            array( '%s', '%s' )
        );
        return (int) $wpdb->insert_id;
    }

    public static function update_form( $id, $name, $settings ) {
        global $wpdb;
        unset( $settings['_form_id'], $settings['_form_name'] );
        return $wpdb->update( // phpcs:ignore
            $wpdb->prefix . 'scf_forms',
            array(
                'name'     => sanitize_text_field( $name ),
                'settings' => wp_json_encode( $settings ),
            ),
            array( 'id' => (int) $id ),
            array( '%s', '%s' ),
            array( '%d' )
        );
    }

    public static function duplicate_form( $id ) {
        global $wpdb;
        $t   = $wpdb->prefix . 'scf_forms';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$t}` WHERE id = %d LIMIT 1", (int) $id ), ARRAY_A );
        if ( ! $row ) return false;

        $wpdb->insert( $t, array( // phpcs:ignore
            'name'     => $row['name'] . ' (Copy)',
            'settings' => $row['settings'],
        ), array( '%s', '%s' ) );
        return (int) $wpdb->insert_id;
    }

    public static function delete_form( $id ) {
        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'scf_submissions', array( 'form_id' => (int) $id ), array( '%d' ) ); // phpcs:ignore
        return $wpdb->delete( $wpdb->prefix . 'scf_forms', array( 'id' => (int) $id ), array( '%d' ) ); // phpcs:ignore
    }

    /* ── Submissions ───────────────────────────────────────────────── */

    public static function save_submission( array $data, $form_id = 1 ) {
        global $wpdb;
        $wpdb->insert( // phpcs:ignore
            $wpdb->prefix . 'scf_submissions',
            array(
                'form_id'    => (int) $form_id,
                'form_data'  => wp_json_encode( $data ),
                'ip_address' => self::get_ip(),
                'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
                'status'     => 'new',
            ),
            array( '%d', '%s', '%s', '%s', '%s' )
        );
        return (int) $wpdb->insert_id;
    }

    public static function get_submissions( $per_page = 20, $page = 1, $form_id = 0 ) {
        global $wpdb;
        $t      = $wpdb->prefix . 'scf_submissions';
        $offset = ( $page - 1 ) * $per_page;
        if ( $form_id ) {
            return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$t}` WHERE form_id=%d ORDER BY created_at DESC LIMIT %d OFFSET %d", $form_id, $per_page, $offset ), ARRAY_A ); // phpcs:ignore
        }
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$t}` ORDER BY created_at DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A ); // phpcs:ignore
    }

    public static function count_submissions( $form_id = 0 ) {
        global $wpdb;
        $t = $wpdb->prefix . 'scf_submissions';
        if ( $form_id ) {
            return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$t}` WHERE form_id=%d", $form_id ) );
        }
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$t}`" ); // phpcs:ignore
    }

    public static function delete_submission( $id ) {
        global $wpdb;
        return $wpdb->delete( $wpdb->prefix . 'scf_submissions', array( 'id' => (int) $id ), array( '%d' ) ); // phpcs:ignore
    }

    private static function get_ip() {
        foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $parts = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) );
                return trim( $parts[0] );
            }
        }
        return '';
    }
}
