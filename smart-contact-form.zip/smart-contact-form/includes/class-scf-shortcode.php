<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCF_Shortcode {

    private static $loaded_forms = array();

    public function __construct() {
        add_shortcode( 'smart_contact_form', array( $this, 'render' ) );
    }

    public function render( $atts ) {
        $atts = shortcode_atts( array( 'id' => 0 ), $atts, 'smart_contact_form' );
        $form_id = absint( $atts['id'] );

        // Load form settings from DB
        if ( $form_id ) {
            $settings = SCF_Database::get_form( $form_id );
        } else {
            // Fallback: load first form
            $forms = SCF_Database::get_all_forms();
            $settings = ! empty( $forms ) ? SCF_Database::get_form( $forms[0]['id'] ) : SCF_Admin::get_default_settings();
            $form_id = ! empty( $forms ) ? (int) $forms[0]['id'] : 1;
        }

        if ( ! $settings ) return '<!-- Smart Contact Form: form not found -->';

        // Enqueue assets
        if ( ! isset( self::$loaded_forms[ $form_id ] ) ) {
            self::$loaded_forms[ $form_id ] = true;
            $frontend = new SCF_Frontend();
            $frontend->enqueue_for_form( $form_id, $settings );
        }

        ob_start();
        include SCF_PLUGIN_DIR . 'frontend/views/form.php';
        return ob_get_clean();
    }
}
