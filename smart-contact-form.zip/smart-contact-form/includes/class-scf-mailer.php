<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SCF_Mailer {

    public static function send( array $form_data, array $settings ) {
        $to      = ! empty( $settings['admin_email'] ) ? sanitize_email( $settings['admin_email'] ) : get_option( 'admin_email' );
        $subject = ! empty( $settings['email_subject'] ) ? sanitize_text_field( $settings['email_subject'] ) : __( 'New Contact Form Submission', 'smart-contact-form-builder' );

        if ( ! is_email( $to ) ) return false;

        // ── Sender: use WordPress site email (avoids spam rejection) ──
        $site_name  = get_bloginfo( 'name' );
        $site_email = get_option( 'admin_email' );
        $from_name  = $site_name ? $site_name : 'Contact Form';

        // ── Reply-To: the person who filled the form ──
        $reply_name  = '';
        $reply_email = '';
        foreach ( $form_data as $key => $val ) {
            $key_lower = strtolower( $key );
            if ( ! $reply_email && ( false !== strpos( $key_lower, 'email'  ) ) && is_email( $val ) ) {
                $reply_email = sanitize_email( $val );
            }
            if ( ! $reply_name && ( ( false !== strpos( $key_lower, 'name'  ) ) || ( false !== strpos( $key_lower, 'vor'  ) ) ) ) {
                $reply_name = sanitize_text_field( $val );
            }
        }

        // ── Headers ──
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . self::encode_name( $from_name ) . ' <' . $site_email . '>',
        );
        if ( $reply_email ) {
            $rn = $reply_name ? $reply_name : $reply_email;
            $headers[] = 'Reply-To: ' . self::encode_name( $rn ) . ' <' . $reply_email . '>';
        }

        // ── HTML Body ──
        $body = self::build_body( $subject, $form_data, $settings );

        // Hook PHPMailer to set proper From (in case WP overrides headers)
        $from_email_capture = $site_email;
        $from_name_capture  = $from_name;
        $hook = function( $phpmailer ) use ( $from_email_capture, $from_name_capture ) {
            $phpmailer->From     = $from_email_capture;
            $phpmailer->FromName = $from_name_capture;
        };
        // Log mail failures
        $mail_fail_log = function( $error ) {
            error_log( '[SCF Mailer] wp_mail_failed: ' . $error->get_error_message() );
        };
        add_action( 'wp_mail_failed', $mail_fail_log );
        add_action( 'phpmailer_init', $hook );
        $result = wp_mail( $to, $subject, $body, $headers );
        remove_action( 'phpmailer_init', $hook );
        remove_action( 'wp_mail_failed', $mail_fail_log );

        // Log failure to WP debug log
        if ( ! $result ) {
            error_log( '[SCF Mailer] wp_mail failed. To: ' . $to . ' | Subject: ' . $subject );
        }

        return $result;
    }

    private static function build_body( $subject, $form_data, $settings ) {
        $site_name = esc_html( get_bloginfo( 'name' ) );
        $date      = current_time( 'F j, Y \a\t g:i A' );

        $rows = '';
        foreach ( $form_data as $key => $value ) {
            if ( in_array( $key, array( '_nonce', '_honeypot', '_redirect', 'form_id', 'scf_time_on_page' ), true ) ) continue;
            if ( '' === $value || null === $value ) continue;
            $rows .= '<tr>';
            $rows .= '<td style="padding:13px 24px;font-weight:600;font-size:13px;color:#64748b;width:32%;border-bottom:1px solid #f1f5f9;background:#fafbfc;vertical-align:top;">' . esc_html( $key ) . '</td>';
            $rows .= '<td style="padding:13px 24px;font-size:14px;color:#1e293b;border-bottom:1px solid #f1f5f9;">' . nl2br( esc_html( $value ) ) . '</td>';
            $rows .= '</tr>';
        }

        return '<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 16px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 16px rgba(0,0,0,.08);">

  <!-- Header -->
  <tr>
    <td style="background:linear-gradient(135deg,#1e3a5f 0%,#2563eb 100%);padding:28px 32px;">
      <p style="margin:0;color:#fff;font-size:19px;font-weight:700;">' . esc_html( $subject ) . '</p>
      <p style="margin:6px 0 0;color:rgba(255,255,255,.75);font-size:12px;">' . $site_name . ' &nbsp;&bull;&nbsp; ' . $date . '</p>
    </td>
  </tr>

  <!-- Fields -->
  <tr>
    <td style="padding:8px 0;">
      <table width="100%" cellpadding="0" cellspacing="0">' . $rows . '</table>
    </td>
  </tr>

  <!-- Footer -->
  <tr>
    <td style="padding:16px 32px;background:#f8fafc;border-top:1px solid #e2e8f0;">
      <p style="margin:0;font-size:11px;color:#94a3b8;">This message was sent via the contact form on <strong>' . $site_name . '</strong>. Do not reply directly to this email — use the Reply-To address above.</p>
    </td>
  </tr>

</table>
</td></tr>
</table>
</body>
</html>';
    }

    /**
     * RFC 2047 encode display name if it has non-ASCII or special chars
     */
    private static function encode_name( $name ) {
        if ( preg_match( '/[^\x20-\x7E]/', $name ) ) {
            return '=?UTF-8?B?' . base64_encode( $name ) . '?=';
        }
        // Quote if has special chars
        if ( preg_match( '/[",;:<>()]/', $name ) ) {
            return '"' . addslashes( $name ) . '"';
        }
        return $name;
    }
}
